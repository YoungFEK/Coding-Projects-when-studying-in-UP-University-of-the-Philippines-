<?php
include 'DBConnector.php';

if (isset($_POST['orderId']) && isset($_POST['status'])) {
    $orderID = $_POST['orderId'];
    $status = $_POST['status'];

    // Use prepared statements to avoid SQL injection
    $stmt = $conn->prepare("UPDATE order_table SET status = ? WHERE order_id = ?");
    $stmt->bind_param("si", $status, $orderID);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "Updated successfully";
    } else {
        echo "No rows updated";
    }

    $stmt->close();
} else {
    echo "Missing parameters";
}

$conn->close();
?>