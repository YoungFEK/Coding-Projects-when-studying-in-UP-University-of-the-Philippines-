
function load_active_orders(){
    fetch('active_order.php')
        .then(response => response.json())
        .then(data => {
            let container = document.getElementById('order_prep');

            data.forEach(order => {
                let div1 = document.createElement('div');
                    div1.className="active_order"
                    let div2= document.createElement('div');
                        div2.className='order_Number';
                        div2.textContent=order.Order_id;
                    let div3= document.createElement('div');
                        div3.className='time_received';
                        div3.textContent=order.Order_Time;
                    let div4=document.createElement('div');
                        div4.className='mark_as_ready';
                    let button=document.createElement('button');
                        button.className='ready_button'
                        button.textContent='Mark as Ready'


                    div1.appendChild(div2);
                    div1.appendChild(div3);
                    div4.appendChild(button);
                    div1.appendChild(div4)
                    container.appendChild(div1);
            });
        })
}

function load_ready_orders(){
    fetch('ready_order.php')
        .then(response => response.json())
        .then(data => {
            let container = document.getElementsByClassName('order_prepared')[0];

            data.forEach(order => {
                let div1 = document.createElement('div');
                div1.className="active_order"
                let div2= document.createElement('div');
                div2.className='order_Number';
                div2.textContent=order.Order_id;
                let div3= document.createElement('div');
                div3.className='time_received';
                div3.textContent=order.Order_Time;
                let div4=document.createElement('div');
                div4.className='mark_as_ready';
                let button=document.createElement('button');
                button.className='ready_button'
                button.textContent='Mark as Ready'


                div1.appendChild(div2);
                div1.appendChild(div3);
                div4.appendChild(button);
                div1.appendChild(div4)
                container.appendChild(div1);
            });
        })
}


load_active_orders()
load_ready_orders()