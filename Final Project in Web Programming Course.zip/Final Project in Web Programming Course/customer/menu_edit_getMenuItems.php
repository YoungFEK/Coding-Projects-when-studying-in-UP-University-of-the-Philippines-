<?php
include 'DBConnector.php';

header('Content-Type: application/json');

// Sanitize input
$concessionaire_id = $_POST['concessionaire_id'] ?? null;
$category = $_POST['Category'] ?? null;


if (!$concessionaire_id) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Info"]);
    exit;
}
if ($category==='All') {
    $sql = "SELECT * FROM dish WHERE concessionaire_id = '$concessionaire_id'";
}else{
    $sql = "SELECT * FROM dish WHERE concessionaire_id = '$concessionaire_id' and Category = '$category'";
}


$result = $conn->query($sql);



$categories = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
}

$conn->close();

echo json_encode($categories);
?>