document.addEventListener('DOMContentLoaded', function () {
    let ID=1;
    const halfServe=document.getElementById('allowHalfServe');
    const halfServelabel=document.getElementById('halfServelabel');
    const halfServeInput=document.getElementById('halfServePinput');
    const openModal=document.getElementById('EditMenuModal');
    const cancelForm=document.getElementById('DeleteMenuItem')
    const catModal=document.getElementById('editCategory')

    function load_categories() {
        fetch('menu_edit_getCategories.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                concessionaire_id: 1
            })
        })
            .then(response => response.json())
            .then(data => {
                console.log("Received data:", data);
                let select=document.getElementById('editMenuCat')
                let select2=document.getElementById('DeleteCat')
                let container = document.getElementById('categories');
                select.innerHTML='';
                select2.innerHTML='';
                container.innerHTML = '';
                let total=0;
                let firstdiv = document.createElement('div')
                    firstdiv.className = "cat_tag selected";
                let AllcatTag=document.createElement('div');
                    AllcatTag.className='catName'
                    AllcatTag.textContent='ALL'
                let AllcatNumber=document.createElement('div');
                    AllcatNumber.className='itemsAvail'

                firstdiv.addEventListener('click', () => {
                    document.querySelectorAll('.cat_tag').forEach(tag => tag.classList.remove('selected'));
                    firstdiv.classList.add('selected');
                    load_menu_items(ID,'All')
                });

                firstdiv.appendChild(AllcatTag);
                firstdiv.appendChild(AllcatNumber);
                container.appendChild(firstdiv);


                data.forEach(item => {
                    let div1 = document.createElement('div');
                        div1.className = "cat_tag";
                    let div2=document.createElement('div');
                        div2.className='catName'
                        div2.textContent=item.category_name;
                    let div3=document.createElement('div');
                        div3.className='itemsAvail'
                        div3.textContent=`No. of items: ${item.total_items}`

                    const opt = document.createElement('option');
                        opt.value = item.category_id;
                        opt.textContent = item.category_name;
                    select.appendChild(opt);
                    const opt2 = document.createElement('option');
                    opt2.value = item.category_id;
                    opt2.textContent = item.category_name;
                    select2.appendChild(opt2);
                    total=total+parseFloat(item.total_items)
                    div1.appendChild(div2);
                    div1.appendChild(div3);
                    container.appendChild(div1);


                    div1.addEventListener('click', () => {
                        document.querySelectorAll('.cat_tag').forEach(tag => tag.classList.remove('selected'));
                        div1.classList.add('selected');
                        load_menu_items(ID,item.category_name)
                    });
                });

                AllcatNumber.textContent=total;
            })
    }

    function load_menu_items(concessioanireID,category){
        fetch('menu_edit_getMenuItems.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                concessionaire_id: concessioanireID,
                Category: category
            })
        })
            .then(response => response.json())
            .then(data => {
                console.log("Received data:", data);
                let container = document.getElementById('item_box2');

                container.innerHTML = '';

                data.forEach(item => {
                    let div1 = document.createElement('div');
                    div1.className = "item_container";
                    div1.onclick=()=>{
                        openEditForm(ID,item.Dish_ID,item.Dish_Name,item.Category,item.Whole_Serving_Price,item.Half_Serving_Price)
                    }
                    let div2=document.createElement('div');
                    div2.className='item_Name'
                    div2.textContent=item.Dish_Name;
                    let div3=document.createElement('div');
                    div3.className='items_Cat'
                    div3.textContent=item.Category;
                    let div4=document.createElement('div');
                    div4.className='Availability'
                    let toggleSwitch=document.createElement('label');
                        toggleSwitch.className='switch'
                    let toggleinput=document.createElement('input');
                        toggleinput.type='checkbox'
                        toggleinput.checked = item.Availability !== 'Available';
                        toggleinput.onchange=()=>{
                            const availability = toggleinput.checked ? 'Not Available' : 'Available';
                            setAvailability(ID, item.Dish_ID, availability);
                        }
                    let toggleslider =document.createElement('span');
                        toggleslider.className='slider_round'

                    toggleSwitch.appendChild(toggleinput)
                    toggleSwitch.appendChild(toggleslider)

                    div1.appendChild(div2);
                    div1.appendChild(div3);
                    div4.appendChild(toggleSwitch)
                    div1.appendChild(div4)
                    div4.appendChild(toggleSwitch)
                    container.appendChild(div1);
                });

            })
    }

    function setAvailability( concessioanireID,dishID,availability){
        fetch('menu_edit_setAvailability.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                concessionaire_id: concessioanireID,
                Dish_ID: dishID,
                availability: availability
            })
        })
    }

    function openAddnewItem(conID){
        const formName=document.getElementById('form_Name');
        document.getElementById('conID').value=conID;

        formName.textContent='Add New Item';
        openModal.style.display='block';
        cancelForm.style.display='none';

        document.getElementById('EditMenuForm').action='menu_edit_addItem.php'

    }
    function openEditForm(conID,DishID,Name,category,wsPrice,hsPrice){
        const formName=document.getElementById('form_Name');


        document.getElementById('conID').value=conID;
        document.getElementById('Dish_ID').value=DishID;
        document.getElementById('Item_Name').value=Name;
        document.getElementById('editMenuCat').value=category;
        document.getElementById('W_S_Price').value=wsPrice;
        if(hsPrice!==null){
            halfServe.checked=true;
            halfServelabel.style.removeProperty('display');
            halfServeInput.style.removeProperty('display');
            document.getElementById('H_S_Price').value=hsPrice;
        }else{
            halfServe.checked=false;
        }
        document.getElementById('EditMenuForm').action='menu_edit_editItems.php'
        formName.textContent='Edit Item';
        openModal.style.display='block';
        cancelForm.style.removeProperty('display');
    }

    function openAddCategoryModal(ID){
        catModal.style.display='block'
        const select=document.getElementById('DeleteCat');
        const input= document.getElementById('catADD')
        const form=document.getElementById('EditCategoryForm')
        document.getElementById('conID2').value=ID;

        select.style.display='none'
        input.style.removeProperty('display');
        form.action="menu_edit_addCategory.php"

    }

    function openDeleteCategoryModal(ID){
        catModal.style.display='block'
        const select=document.getElementById('DeleteCat');
        const input= document.getElementById('catADD')
        const form=document.getElementById('EditCategoryForm')
        document.getElementById('conID2').value=ID;

        input.style.display='none'
       select.style.removeProperty('display');
        form.action="menu_edit_deleteCategory.php"

    }


    halfServe.onchange=()=>{
        if( halfServe.checked){
            halfServelabel.style.removeProperty('display');
            halfServeInput.style.removeProperty('display');
        }else{
            halfServelabel.style.display='none';
            halfServeInput.style.display='none';
        }
    }


    document.getElementById('add_item').onclick=()=>{
        openAddnewItem(ID);
    }

    document.getElementById('add_Category').onclick=()=>{
        openAddCategoryModal(ID);
    }

    document.getElementById('delete_Category').onclick=()=>{
        openDeleteCategoryModal(ID);
    }


    document.getElementById('DeleteMenuItem').onclick=()=>{
        document.getElementById('EditMenuForm').action='menu_edit_deleteItem.php'
    };
    window.onclick = function (event) {
        if (event.target === openModal) {
            openModal.style.removeProperty('display')
        }
        if (event.target === catModal) {
            catModal.style.removeProperty('display')
        }
    }
    document.getElementById('status').onclick=()=>{
        let current=document.getElementById('current_status').textContent;
        let newstatus='';
        let newColor=''
        let num='';
        if(current==='Open'){
            newstatus='Close'
            newColor='red'
            num=0;

        }else{
            newstatus='Open'
            newColor='Green'
            num=1;
        }
        fetch('updateStoreStatus.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                Status: num
            })
        })

        document.getElementById('current_status').textContent=newstatus;
        document.getElementById('indicator').style.background=newColor;
        document.getElementById('status').textContent=current;
    }

    load_menu_items(ID,'All')
    load_categories()
})