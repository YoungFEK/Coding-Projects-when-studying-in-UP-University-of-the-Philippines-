document.addEventListener('DOMContentLoaded', function () {
    let allOrders = [];
    let lastOrderTime = null;
    const orderModal = document.getElementById('order_details');
    const dateModal = document.getElementById('dateModal');
    const openDateModal=document.getElementById('calendar_filter')
    const closeDateModal=document.getElementById('closedateModal');

    /*<--Date filters-->*/
    document.getElementById('presetToday').onclick=()=>setPreset('today');
    document.getElementById('presetYesterday').onclick=()=>setPreset('yesterday');
    document.getElementById('presetLast7').onclick=()=>setPreset('last7');
    document.getElementById('presetMonth').onclick=()=>setPreset('month');
    document.getElementById('presetLast30').onclick=()=>setPreset('last30');
    document.getElementById('resetDate').onclick=()=>resetDates();
    document.getElementById('startDate').onchange = updateDisplay;
    document.getElementById('endDate').onchange = updateDisplay;

    function get_all_orders(){
        fetch('History_loadAllOrders.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                concessionaire_id: 1
            })
        })
            .then(response => response.json())
            .then(data => {
                console.log('Checking Get orders')
                allOrders = data;
                applyFilters();
            });
    }

    function load_all_orders(orders){

                let container = document.getElementById('orderlist');
                container.innerHTML = '';
                orders.forEach(order => {
                    let div1 = document.createElement('div');
                    div1.className = "order";
                    div1.onclick = () =>  openLiveOrder(order.Order_id, order.Customer_ID, order.Order_Date, order.Order_Time,order.Comments);
                    let div2 = document.createElement('div');
                    div2.className = 'order_Number';
                    div2.textContent = order.Order_id;
                    let div3 = document.createElement('div');
                    div3.className = 'time_received';
                    div3.textContent = order.Order_Time;
                    let div4 = document.createElement('div');
                    div4.className = 'mark_as_ready';
                    let div5 = document.createElement('div');
                    div5.className = 'orderStatus';
                    div5.textContent = order.Status;
                    console.log('${order.Order_id}')

                    div1.appendChild(div2);
                    div1.appendChild(div3);
                    div4.appendChild(div5);
                    div1.appendChild(div4)
                    container.appendChild(div1);
                });
    }




    async function fetch_Customer_Info(CustomerID) {

        const response = await fetch("retrieve_Customer.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: "CustomerID=" + encodeURIComponent(CustomerID)
        });
        return await response.json();
    }

    function openLiveOrder(orderId,CustomerID,orderDate,orderTime,comment) {
        let total_price = 0;

        fetch_Customer_Info(CustomerID).then(Customer => {
            document.getElementById('order_details_CustomerName').textContent=`Customer Name : ${Customer[0].Customer_Name}`;
            document.getElementById('order_details_CustomerNumber').textContent=`Customer #: ${Customer[0].Customer_Contact_No}`;
        });

        fetch("live_order_getDetails.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: "orderId=" + encodeURIComponent(orderId)})
            .then(response => response.json())
            .then(data => {
                let container = document.getElementsByClassName('details')[0];
                container.innerHTML = '';
                data.forEach(order => {
                    let div1 = document.createElement('div');
                    div1.className = "items";
                    let div2 = document.createElement('div');
                    div2.className = 'item_Name';
                    div2.textContent = order.Dish_Name;
                    let div3 = document.createElement('div');
                    div3.className = 'item_serving';
                    div3.textContent =order.serving_label;
                    let div4 = document.createElement('div');
                    div4.className = 'item_qty';
                    div4.textContent = order.qty;
                    let div5 = document.createElement('div');
                    div5.className = 'item_price';
                    div5.textContent = order.price;
                    let div6 = document.createElement('div');
                    div6.className = 'subtotal';
                    div6.textContent = order.total_price;


                    total_price = total_price+parseFloat(order.total_price);
                    div1.appendChild(div2);
                    div1.appendChild(div3)
                    div1.appendChild(div4);
                    div1.appendChild(div5)
                    div1.appendChild(div6);
                    container.appendChild(div1);
                })
                document.getElementById('CommentBox').textContent=comment;
                document.getElementById('TotalAmount').textContent = `${total_price.toFixed(2)}`;
                document.getElementById('order_details_id').textContent=`Order ID: ${orderId}`;
                document.getElementById('order_details_time').textContent = `Order Time: ${orderDate} ${orderTime}`;
            })
        orderModal.style.display = "block";
    }

    function closeModal(modal){
        modal.style.display = "none";
    }


    function resetDates() {
        document.getElementById("startDate").value = '';
        document.getElementById("endDate").value = '';
    }

    function formatDate(date) {
        return date.toISOString().split("T")[0];
    }

    function setPreset(type) {
        const today = new Date();
        const datefilter=document.getElementById('calendar_filter')
        let start, end;

        switch (type) {
            case 'today':
                start = end = today;
                datefilter.textContent='Today'
                break;
            case 'yesterday':
                start = end = new Date(today.setDate(today.getDate() - 1));
                datefilter.textContent='Yesterday'
                break;
            case 'last7':
                end = new Date();
                start = new Date();
                start.setDate(start.getDate() - 6);
                datefilter.textContent='Last 7 Days'
                break;
            case 'month':
                start = new Date(today.getFullYear(), today.getMonth(), 2);
                end = new Date();
                datefilter.textContent='This Month'
                break;
            case 'last30':
                end = new Date();
                start = new Date();
                datefilter.textContent='Last 30 Days'
                start.setDate(start.getDate() - 29);
                break;
        }

        closeModal(dateModal)
        document.getElementById("startDate").value = formatDate(start);
        document.getElementById("endDate").value = formatDate(end);
        applyFilters()
    }

    function updateDisplay() {
        const startInput = document.getElementById("startDate");
        const endInput = document.getElementById("endDate");

        const startDate = new Date(startInput.value);
        const endDate = new Date(endInput.value);

        if (startInput.value && endInput.value) {
            if (endDate < startDate) {
                 startInput.value=endInput.value;
            }
        }
    }

    function applyFilters() {
        const searchInput = document.getElementById("searchBar");
        const query = searchInput && searchInput.value ? searchInput.value.toLowerCase() : '';
        const startDate = document.getElementById("startDate").value;
        const endDate = document.getElementById("endDate").value;

        const filtered = allOrders.filter(order => {
            const matchesSearch = order.Order_id.toLowerCase().includes(query);

            if (startDate && endDate) {
                const orderDate = order.Order_Date;
                return matchesSearch && orderDate >= startDate && orderDate <= endDate;
            }

            return matchesSearch;
        });

        load_all_orders(filtered);
    }

    function checkForNewOrders() {
        fetch('check_orders_Updates.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                concessionaire_id: 1
            })
        })
            .then(res => res.json())
            .then(data => {
                console.log("Debug:", data);
                if (lastOrderTime && data.latest !== lastOrderTime) {
                    console.log("New order detected!");
                    get_all_orders();
                }
                lastOrderTime = data.latest;
            });
    }



    openDateModal.onclick=function (e){

        dateModal.style.display='block';
    }

    closeDateModal.onclick=function (e){
        const datefilter=document.getElementById('calendar_filter')
        const startInput = document.getElementById("startDate");
        const endInput = document.getElementById("endDate");

        const todayDate=new Date();
        const today=formatDate(todayDate);
        const yesterday = formatDate(new Date(todayDate.getFullYear(), todayDate.getMonth(), todayDate.getDate() ));
        const last7Start = formatDate(new Date(todayDate.getFullYear(), todayDate.getMonth(), todayDate.getDate() - 5));
        const monthStart = formatDate(new Date(todayDate.getFullYear(), todayDate.getMonth(), 2));
        const last30Start = formatDate(new Date(todayDate.getFullYear(), todayDate.getMonth(), todayDate.getDate() - 28));


        closeModal(dateModal);
        applyFilters();
        if (startInput.value === today && endInput.value === today) {
            datefilter.textContent = 'Today';
        } else if (startInput.value === yesterday && endInput.value === yesterday) {
            datefilter.textContent = 'Yesterday';
        } else if (startInput.value === last7Start && endInput.value === today) {
            console.log(last7Start)
            datefilter.textContent = 'Last 7 Days';
        } else if (startInput.value === monthStart && endInput.value === today) {
            datefilter.textContent = 'Current Month';
        } else if (startInput.value === last30Start && endInput.value === today) {
            datefilter.textContent = 'Last 30 Days';
        } else {
            console.log(yesterday)
            datefilter.textContent = `${startInput.value} - ${endInput.value}`;
        }


    }

    window.onclick = function (event) {
        if (event.target === dateModal) {
            closeModal(dateModal);
        } else if (event.target === orderModal) {
            closeModal(orderModal);
        }
    };

    document.getElementById('closeButton').onclick=()=>closeModal(orderModal);

    document.getElementById('status').onclick=()=>{
        let current=document.getElementById('current_status').textContent;
        let newstatus='';
        let newColor=''
        let num='';
        if(current==='Open'){
            newstatus='Close'
            newColor='red'
            num=0;

        }else{
            newstatus='Open'
            newColor='Green'
            num=1;
        }
        fetch('updateStoreStatus.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                Status: num
            })
        })

        document.getElementById('current_status').textContent=newstatus;
        document.getElementById('indicator').style.background=newColor;
        document.getElementById('status').textContent=current;
    }

    setPreset('today')


    get_all_orders()
    setInterval(checkForNewOrders,5000)
    document.getElementById('searchBar').onchange=applyFilters;





});