var cart = [];


function addtocart(dish_id, dish_name, serving_type, serving_price) {
  orderDetail_object = {
    dish_id: dish_id,
    dish_name:dish_name,
    serving_type: serving_type,
    quantity: 1,
    serving_price: serving_price,
    total_price: serving_price
  };

  let exist = false;

  cart.forEach((prev_object) =>{
    if((prev_object.dish_id ==  orderDetail_object.dish_id) && (prev_object.serving_type ==  orderDetail_object.serving_type)){
      exist = true;
      return;
    }
  });

  if(exist == false){
    cart.push(orderDetail_object);
  }

  displaycart();
  compute_checkout_total();
}



function delElement(a) {
  cart.splice(a, 1);
  displaycart();
  compute_checkout_total();
}




function updateObjectQuantity(inputElement, index){
  cart[index].quantity = inputElement.value;
  cart[index].total_price = cart[index].quantity * cart[index].serving_price;
  displaycart();
  compute_checkout_total();
}




function compute_checkout_total(){
  var checkout_total = 0;

  cart.forEach((orderDetail_object) => {
    checkout_total += orderDetail_object.total_price;
  })

  document.getElementById("chk_out_amount").innerHTML = `${checkout_total}`;
}




function displaycart() {
  document.getElementById("item_list").innerHTML = cart.map((orderDetail_object, index) => {
    return `
      <div class="item_table_cell_sizes">
          <h3>           </h3>
          <h3>                          </h3>
          <h3>                         </h3>
          <h3>               </h3>
      </div>
      <div class="cart_item">
          <input class="cart_itm_qty" type="number" min="1" max="10" step="1" value=${orderDetail_object.quantity} onchange="updateObjectQuantity(this, ${index})">
          <p class="cart_itm_serving">${orderDetail_object.serving_type}</p>
          <p class="cart_itm_Name">${orderDetail_object.dish_name}</p>
          <p class="cart_itm_price">P ${orderDetail_object.total_price}</p>
      </div>
      <div class="remove_button_area">
          <button class="cart_itm_delete" onclick="delElement(${index})">REMOVE</button>
      </div>
    `;

  }).join('');
}


//imports promise-version of mysql12
// const mysql = require('mysql2/promise');

// async function submitData(){
//   //accessing elements
//   var comment = document.getElementById('noteInput').value;
//   var mode = document.querySelector('input[name="destination"]:checked').value;
//   var modeValue = mode === "1" ? 'DINE-IN' : 'TAKE-OUT';


//   fetch('push_order.php', {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/x-www-form-urlencoded',
//             },
//             body: new URLSearchParams({
//                 customer_comment: comment,
//                 mode_of_pickup: modeValue,
//             })
//   })
// }




async function submitData(){
  //accessing elements
  var comment = document.getElementById('noteInput').value;
  var mode = document.querySelector('input[name="destination"]:checked').value;
  var modeValue = mode === "1" ? 'DINE-IN' : 'TAKE-OUT';

  const data = {
    customer_comment: comment,
    mode_of_pickup: modeValue,
    order_details: cart
  };
  fetch('push_order2.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: JSON.stringify(data)
  })
  .then(response => response.json())

  cart = [];
  displaycart();
  document.getElementById("chk_out_amount").innerHTML = ``;
  document.getElementById('red').checked = false


}
