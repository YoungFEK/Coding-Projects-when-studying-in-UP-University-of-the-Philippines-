<?php
include 'DBConnector.php';


$sql = "SELECT *
        FROM order_table
        where status='ready'";

$result = $conn->query($sql);

$order = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $order[] = $row;
    }
}

header('Content-Type: application/json');
echo json_encode($order);

$conn->close();
?>