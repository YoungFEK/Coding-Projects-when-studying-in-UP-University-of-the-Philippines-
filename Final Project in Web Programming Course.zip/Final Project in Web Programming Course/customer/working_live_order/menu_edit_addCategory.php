<?php
include 'DBConnector.php';

header('Content-Type: application/json');

// Sanitize input
$concessionaire_id = $_POST['concessionaire_id'] ?? null;
$CategoryName = $_POST['CategoryAdd'] ?? null;




if (!$concessionaire_id) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Info"]);
    exit;
}

$sql = " INSERT INTO `category`( `category_name`, `concessionaire_id`, `total_items`) 
            VALUES('$CategoryName', '$concessionaire_id', 0)";


$result = $conn->query($sql);





$conn->close();

echo json_encode($result);
?>


