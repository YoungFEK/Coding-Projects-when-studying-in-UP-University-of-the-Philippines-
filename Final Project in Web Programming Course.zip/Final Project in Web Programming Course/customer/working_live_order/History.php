<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Website Name | Live Orders</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="concessionaire.css">
    <script src="History.js"></script>
</head>
<body>
<main>
    <aside class="sidebar">
        <h2 class="logo"><img src="logo.png"></h2>
        <nav class="nav_bar">
            <a class="">Live Order</a>
            <a class="active">Order History</a>
            <a>Menu</a>
            <button>Logout</button>
        </nav>
    </aside>
</main>
<section>
    <div class="top_bar">
        <h1>Order History</h1>
        <div class="status"> <div class="indicator"></div><div class="current_status">Open</div></div>
    </div>

    <div class="History">
        <h2>Preparation</h2>
        <div class="filters">
            <div class="calendar_filter" id="calendar_filter">
                Today
            </div>
            <div class="search">
                <input type="text" id="searchBar" placeholder="Order id" />
            </div>
        </div>

        <div class="orderlist" id="orderlist">

        </div>
    </div>
</section>
<div class="backscreen" id="order_details">
    <div class="order_details">
        <button id="closeButton" class="closeButton">&times;</button>
        <div class="order_Number" id="order_details_id"> </div>
        <h2>Order details</h2>
        <div class="details">
            <div class="items">
                <div class="item_Name"></div>
                <div class="item_serving"></div>
                <div class="item_qty"></div>
                <div class="item_price"></div>
                <div class="subtotal"></div>
            </div>
        </div>
        <div class="Total">
            <div class="Total_Text">Total</div>
            <div id="TotalAmount"></div>
        </div>
        <div class="Order_details_Footer">
            <div id="order_details_CustomerName"></div>
            <div id="order_details_CustomerNumber"></div>
            <div id="order_details_time"></div>
        </div>
    </div>
</div>
<div id="dateModal" class="datemodal">
    <div class="modal-content">
        <h2>Select a Date Range</h2>
        <div class="presets">
            <button id="presetToday" >Today</button>
            <button id="presetYesterday" >Yesterday</button>
            <button id="presetLast7" >Last 7 days</button>
            <button id="presetMonth">Current month</button>
            <button id="presetLast30">Last 30 days</button>
        </div>
        <div class="calendar-container" id="calendars"></div>

        <div class="calendar">
            <input type="date" id="startDate">
            <input type="date" id="endDate">
        </div>

        <div class="actions">
            <button class="reset" id="resetDate">Reset</button>
            <button class="close" id="closedateModal">Close</button>
        </div>
    </div>
</div>
</body>
</html>

<?php
