<?php
include 'DBConnector.php';

header('Content-Type: application/json');

// Sanitize input
$concessionaire_id = $_POST['concessionaire_id'] ?? null;
$Dish_ID = $_POST['Dish_ID'] ?? null;
$Dish_Name = $_POST['Dish_Name'] ?? null;
$category = $_POST['Category'] ?? null;
$WSPrice = $_POST['WSPrice'] ?? null;
$HSPrice = $_POST['HSPrice'] ?? null;


if (!$concessionaire_id) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Info"]);
    exit;
}

$sql = "INSERT INTO `dish`(`Dish_Name`, `concessionaire_id`, `Whole_Serving_Price`, `Half_Serving_Price`, `Category`, `Availability`) 
        VALUES ( '$Dish_Name','$concessionaire_id','$WSPrice','$HSPrice','$category','Available')";


$result = $conn->query($sql);

if ($result) {
    $update = "UPDATE `category` SET `total_items` = `total_items` + 1 WHERE `category_name` = '$category'";
    $conn->query($update);
}





$conn->close();

echo json_encode($result);
?>