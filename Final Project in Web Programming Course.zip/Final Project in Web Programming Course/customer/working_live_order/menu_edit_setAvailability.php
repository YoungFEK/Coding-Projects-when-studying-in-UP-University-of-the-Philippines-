<?php
include 'DBConnector.php';

header('Content-Type: application/json');

// Sanitize input
$concessionaire_id = $_POST['concessionaire_id'] ?? null;
$Dish_ID = $_POST['Dish_ID'] ?? null;
$availability = $_POST['availability'] ?? null;

if (!$concessionaire_id) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Info"]);
    exit;
}

$sql = "UPDATE dish SET Availability = '$availability' WHERE concessionaire_id = '$concessionaire_id' and Dish_ID = '$Dish_ID'";

$result = $conn->query($sql);





$conn->close();

echo json_encode($result);
?>