<?php
include 'DBConnector.php';

header('Content-Type: application/json');

// Sanitize input
$concessionaire_id = $_POST['concessionaire_id'] ?? null;
$CategoryName = $_POST['Category'] ?? null;




if (!$concessionaire_id) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Info"]);
    exit;
}

$sql = "DELETE FROM `category` WHERE category_name='$CategoryName'";


$result = $conn->query($sql);

if ($result) {
    $update = "UPDATE `category` SET `total_items` = `total_items` + 1 WHERE `category_name` = '$category'";
    $conn->query($update);
}





$conn->close();

echo json_encode($result);
?>


