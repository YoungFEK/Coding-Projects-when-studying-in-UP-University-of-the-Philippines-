
document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('live_order_details');
    let lastOrderTime=null;
    function load_active_orders() {
        fetch('live_order_activeOrders.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                concessionaire_id: 1
            })
        })
            .then(response => response.json())
            .then(data => {
                let container = document.getElementById('order_prep');
                container.innerHTML = '';
                data.forEach(order => {
                    let div1 = document.createElement('div');
                    div1.className = "order";
                    div1.onclick = () => openLiveOrder(order.Order_id, order.Customer_ID, order.Order_Date, order.Order_Time);

                    let div2 = document.createElement('div');
                    div2.className = 'order_Number';
                    div2.textContent = order.Order_id;

                    let div3 = document.createElement('div');
                    div3.className = 'time_received';
                    div3.textContent = order.Order_Time;

                    let div4 = document.createElement('div');
                    div4.className = 'mark_as_ready';

                    let button = document.createElement('button');
                    button.className = 'ready_button';
                    button.textContent = 'Mark as Ready';
                    button.onclick = function (event) {
                        event.stopPropagation();
                        change_order_status(order.Order_id, 'Ready');
                    };

                    div4.appendChild(button);
                    div1.appendChild(div2);
                    div1.appendChild(div3);
                    div1.appendChild(div4);
                    container.appendChild(div1);
                });
            })
            .catch(error => {
                console.error('Error loading active orders:', error);
            });
    }

    function load_ready_orders() {
        fetch('live_order_readyOrders.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                concessionaire_id: 1
            })
        })
            .then(response => response.json())
            .then(data => {
                let container = document.getElementsByClassName('order_prepared')[0];
                container.innerHTML = '';
                data.forEach(order => {
                    let div1 = document.createElement('div');
                    div1.className = "order";
                    div1.onclick = () => openLiveOrder(order.Order_id,order.Customer_ID);;
                    let div2 = document.createElement('div');
                    div2.className = 'order_Number';
                    div2.textContent = order.Order_id;
                    let div3 = document.createElement('div');
                    div3.className = 'time_received';
                    div3.textContent = order.Order_Time;
                    let div4 = document.createElement('div');
                    div4.className = 'mark_as_ready';
                    let button = document.createElement('button');
                    button.className = 'ready_button'
                    button.textContent = 'Mark as Claimed'
                    button.onclick=function (event){
                        event.stopPropagation()
                        change_order_status(order.Order_id,'Completed')
                    };


                    div1.appendChild(div2);
                    div1.appendChild(div3);
                    div4.appendChild(button);
                    div1.appendChild(div4)
                    container.appendChild(div1);
                });
            })
    }
    function change_order_status(orderid,status){

        fetch('live_order_updateorderStatus.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                orderId: orderid,
                status: status
            })
        })

    }


    async function fetch_Customer_Info(CustomerID) {

        const response = await fetch("retrieve_Customer.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: "CustomerID=" + encodeURIComponent(CustomerID)
        });
        return await response.json();
    }

    function openLiveOrder(orderId,CustomerID,orderDate,orderTime) {
        let total_price = 0;

        fetch_Customer_Info(CustomerID).then(Customer => {
            document.getElementById('order_details_CustomerName').textContent=`Customer Name : ${Customer[0].Customer_Name}`;
            document.getElementById('order_details_CustomerNumber').textContent=`Customer #: ${Customer[0].Customer_Contact_No}`;
        });

        fetch("live_order_getDetails.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: "orderId=" + encodeURIComponent(orderId)})
            .then(response => response.json())
            .then(data => {
                let container = document.getElementsByClassName('details')[0];
                container.innerHTML = '';
                data.forEach(order => {
                    let div1 = document.createElement('div');
                        div1.className = "items";
                    let div2 = document.createElement('div');
                        div2.className = 'item_Name';
                        div2.textContent = order.Dish_Name;
                    let div3 = document.createElement('div');
                        div3.className = 'item_serving';
                        div3.textContent =order.serving_label;
                    let div4 = document.createElement('div');
                        div4.className = 'item_qty';
                        div4.textContent = order.qty;
                    let div5 = document.createElement('div');
                        div5.className = 'item_price';
                        div5.textContent = order.price;
                    let div6 = document.createElement('div');
                        div6.className = 'subtotal';
                        div6.textContent = order.total_price;


                    total_price = total_price+parseFloat(order.total_price);
                    div1.appendChild(div2);
                    div1.appendChild(div3)
                    div1.appendChild(div4);
                    div1.appendChild(div5)
                    div1.appendChild(div6);
                    container.appendChild(div1);
                })
                document.getElementById('TotalAmount').textContent = `${total_price.toFixed(2)}`;
                document.getElementById('order_details_id').textContent=`Order ID: ${orderId}`;
                document.getElementById('order_details_time').textContent = `Order Time: ${orderDate} ${orderTime}`;
            })
        modal.style.display = "block";
    }


    function closeModal(){
        modal.style.display = "none";
    }

    function checkForNewOrders() {
        fetch('check_orders_Updates.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ concessionaire_id: 1 })
        })
            .then(res => res.json())
            .then(data => {
                console.log("Debug:", data);
                if (lastOrderTime && data.latest !== lastOrderTime) {
                    console.log("New order detected!");
                    load_active_orders();
                    load_ready_orders();
                }
                lastOrderTime = data.latest;
            });
    }

    window.onclick = function (event) {
        if (event.target === modal) {
            closeModal()
        }
    }

    document.getElementById('closeButton').onclick=closeModal;

    load_active_orders()
    load_ready_orders()
    setInterval(checkForNewOrders,5000)

});