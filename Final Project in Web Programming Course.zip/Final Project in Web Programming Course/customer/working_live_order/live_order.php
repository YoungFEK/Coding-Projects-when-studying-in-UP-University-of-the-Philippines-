<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Website Name | Live Orders</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="concessionaire.css">
    <script src="live_order.js"></script>
</head>
<body>
    <main>
        <aside class="sidebar">
            <h2 class="logo"><img src="logo.png"></h2>
            <nav class="nav_bar">
                <a class="active">Live Order</a>
                <a>Order History</a>
                <a>Menu</a>
                <button>Logout</button>
            </nav>
        </aside>
    </main>
    <section>
        <div class="top_bar">
            <h1>Live Orders</h1>
            <div class="status"> <div class="indicator"></div><div class="current_status">Open</div></div>
        </div>

        <div class="prep">
            <h2>Preparation</h2>
            <div class="order_prep" id="order_prep">
                <div class="order">
                    <div class="order_Number">
                        a
                    </div>
                    <div class="time_received">
                        b
                    </div>
                    <div class="mark_as_ready">
                        <button class="ready_button">Mark as Ready</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="ready">
            <h2>Prepared Order</h2>
            <div class="order_prepared">

            </div>
        </div>
    </section>
    <div class="backscreen" id="live_order_details">

        <div class="order_details">
            <button id="closeButton" class="closeButton">&times;</button>
            <div class="order_Number" id="order_details_id"> </div>
            <h2>Order details</h2>
            <div class="details">
                <div class="items">
                    <div class="item_Name"></div>
                    <div class="item_serving"></div>
                    <div class="item_qty"></div>
                    <div class="item_price"></div>
                    <div class="subtotal"></div>
                </div>
            </div>
            <div class="Total">
                <div class="Total_Text">Total</div>
                <div id="TotalAmount"></div>
            </div>
            <div class="Order_details_Footer">
                <div id="order_details_CustomerName"></div>
                <div id="order_details_CustomerNumber"></div>
                <div id="order_details_time"></div>
            </div>
        </div>
    </div>
</body>
</html>

<?php
