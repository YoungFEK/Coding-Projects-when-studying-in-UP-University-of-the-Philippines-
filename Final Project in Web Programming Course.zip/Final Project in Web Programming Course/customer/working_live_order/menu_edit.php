<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Website Name | Live Orders</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="concessionaire.css">
    <script src="menu_edit.js"></script>
</head>
<body>
<main>
    <aside class="sidebar">
        <h2 class="logo"><img src="logo.png"></h2>
        <nav class="nav_bar">
            <a>Live Order</a>
            <a>Order History</a>
            <a class="active">Menu</a>
            <button>Logout</button>
        </nav>
    </aside>
</main>
<section>
    <div class="top_bar">
        <h1>Menu Edit</h1>
        <div class="status"> <div class="indicator"></div><div class="current_status">Open</div></div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">Add New</button>
        <div class="dropdown-content">
            <div class="dropOption" id="add_item">Add New Item</div>
            <div class="dropOption" id="add_Category">Add New Category</div>
            <div class="dropOption" id="delete_Category">Delete Category</div>
        </div>
    </div>


    <div class="menu_edit">
        <div class="category_bar">
            <h2>Category</h2>
            <div class="categories" id="categories">
                <div class="cat_tag">

                </div>

            </div>
        </div>

        <div class="item_box">
            <h2>Menu Items</h2>
            <div class="item_box2" id="item_box2">
                <label class="switch" id="switch">
                    <input type="checkbox" checked>
                    <span class="slider_round"></span>
                </label>
            </div>
        </div>
    </div>


</section>
<div class="backscreen" id="EditMenuModal">
    <div class="EditMenuPage" id="EditMenuPage">
        <h2 id="closeEditModal" class="closeEditModal">←</h2>
        <h2 id="form_Name">Edit Menu</h2>
        <div class="Form">
            <form class="EditMenuForm" id="EditMenuForm" action="" method="post" >
                <table>
                    <input type="text" name="concessionaire_id" id="conID" style="display: none">
                    <input type="text" name="Dish_ID" id="Dish_ID" style="display: none">
                    <tr>
                        <td class="editMenulabel">Item Name</td>
                        <td class="editMenuInput"><input type="text" name="Dish_Name" id="Item_Name"></td>
                    </tr>
                    <tr>
                        <td class="editMenulabel">Category</td>
                        <td class="editMenuInput">
                            <select name="Category" id="editMenuCat"></select></td>
                    </tr>
                    <tr>
                        <td class="editMenulabel">Whole Serve Price</td>
                        <td class="editMenuInput"><input type="number" name="WSPrice" id="W_S_Price"></td>
                    </tr>
                    <tr>
                        <td class="editMenulabel"> </td>
                        <td class="editMenuInput"><input id="allowHalfServe" type="checkbox" name="allowHalfServe" > Allow Half Serve</td>
                    </tr>
                    <tr>
                        <td class="editMenulabel" id="halfServelabel" style="display:none">Half Serve Price</td>
                        <td class="editMenuInput" id="halfServePinput" style="display:none"><input type="number" name="HSPrice" id="H_S_Price"></td>
                    </tr>
                </table>
                <input type="submit" class="submitForm">
            </form>
        </div>
        <div class="Delete" id="DeleteMenuItem">
            <h3 id="closeForm">Delete</h3>
        </div>
    </div>
</div>
<div class="backscreen" id="editCategory">
    <div class="EditCategory" id="EditCategory">
        <h2 id="closeCategoryModal" class="closeEditModal">←</h2>
        <h2 id="form_Name">Edit Menu</h2>
        <div class="Form">
            <form class="EditMenuForm" id="EditCategoryForm" action="" method="post">
                <input type="text" name="concessionaire_id" id="conID2" style="display: none">
                <div class="editCategory">Input Category</div>
                <div class="editCategory"><select name="Category" id="DeleteCat"></select></div>
                <div class="editCategory"><input type="text" name="CategoryAdd" id="catADD"></div>
                <div class="submitbutn"><input type="submit" class="submitCategory"></div>
            </form>
        </div>
    </div>
</div>




</body>


</html>

<?php
