<?php
include 'DBConnector.php';

$Serving_type = $_POST["Serving_type"];
$Dish_Name = $_POST["Dish_Name"];
$Dish_ID = $_POST["Dish_ID"];
$Quantity = 1;
$Price = 0;
$Total_price = 0;

$addOrderDetails = "INSERT INTO order_details (orderDetailID, Dish_ID, Dish_Name, serving_type, qty, price, total_price) VALUES 
(, $Dish_ID, $Dish_Name, $Serving_type, $Quantity, $Price, $Total_price);";




$getOrderDetail = "SELECT * FROM order_details;";
$OrderDetailResult = $conn->query($getOrderDetail);

if ($OrderDetailResult->num_rows > 0) {
    while($OrderDetailRow = $OrderDetailResult->fetch_assoc()) {
        
        echo '
        <div class="item_table_cell_sizes">
            <!-- <h3>QTY.   </h3> -->
            <h3>           </h3>
            <!-- <h3>SERVING          </h3> -->
            <h3>                          </h3>
            <!-- <h3>DISH-NAME     </h3> -->
            <h3>                         </h3>
            <!-- <h3>TOTAL   </h3> -->
            <h3>               </h3>
        </div>
        <div class="cart_item">
            <input class="cart_itm_qty" type="number" min="1" max="10" step="1" value="1">
            <p class="cart_itm_serving">'.$Serving_type.'</p>
            <p class="cart_itm_Name">'.$Dish_ID.'</p>
            <p class="cart_itm_price">P XXX.XX</p>
        </div>
        <div class="remove_button_area">
            <button class="cart_itm_delete" onclick="">REMOVE</button>
        </div>
        ';
        

    }



} else {
    echo "0 results";
}


$conn->close();
?>
