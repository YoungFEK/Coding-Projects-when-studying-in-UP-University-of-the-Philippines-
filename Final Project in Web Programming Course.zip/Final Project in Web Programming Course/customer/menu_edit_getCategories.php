<?php
include 'DBConnector.php';

header('Content-Type: application/json');

// Sanitize input
$concessionaire_id = $_POST['concessionaire_id'] ?? null;

if (!$concessionaire_id) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Missing concessionaire_id"]);
    exit;
}

$sql = "SELECT * FROM category WHERE concessionaire_id = '$concessionaire_id'";
$result = $conn->query($sql);



$categories = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
}

$conn->close();

echo json_encode($categories);
?>