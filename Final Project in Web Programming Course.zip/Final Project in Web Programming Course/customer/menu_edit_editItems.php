<?php
include 'DBConnector.php';

header('Content-Type: application/json');

// Sanitize input
$concessionaire_id = $_POST['concessionaire_id'] ?? null;
$Dish_ID = $_POST['Dish_ID'] ?? null;
$Dish_Name = $_POST['Dish_Name'] ?? null;
$category = $_POST['Category'] ?? null;
$WSPrice = $_POST['WSPrice'] ?? null;
$HSPrice = $_POST['HSPrice'] ?? null;


if (!$concessionaire_id) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Info"]);
    exit;
}

$sql = "UPDATE `dish` 
        SET `Dish_Name`='$Dish_Name',`Whole_Serving_Price`='$WSPrice',`Half_Serving_Price`='$HSPrice',`Category`='$category' WHERE `Dish_ID`='$Dish_ID' and `concessionaire_id`='$concessionaire_id'";



$result = $conn->query($sql);




header("Location: menu_edit.php");
$conn->close();

echo json_encode($result);
?>