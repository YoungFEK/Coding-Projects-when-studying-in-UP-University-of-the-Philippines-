<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CUSTOMER MENU</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="menu.css">
    <!-- wheres the file -->
    <script src="menu.js"></script>
</head>
<body>

<header>
    <div class="navbar">
        <h1>Website Name</h1>
        <!-- ASK  about button 1 and 2 and why are they necessary -->
        <div class="navbutton1">
            <button class="login" onclick="openLoginForm()">Log In</button>
            <button class="signup" onclick="openSignUpForm()">Sign up</button>
        </div>
        <div class="navbutton2">
            <p>&#9776;</p>
            <button class="logout" onclick="">&#9776;</button>
        </div>
    </div>
</header>


<main>
    <div class="info_Section">
        <div class="info">
            <div class="info_image">
                <img src="MenuImage.jpg"  alt="Photo">
            </div>
            <div class="info_name">
                <p class="name">Concessionaire Name</p>
            </div>
        </div>
    </div>

    <div class="main_Section">
        <div class="menu">
            <?php
                include 'showMenuV.php';
            ?>
        </div>
    
        
        <div class="cart">
            <!-- height: 400 -->
            <div class="item_list"> 
                <div class="item_list_header">
                    <h3>QTY.   </h3>
                    <h3>SERVING          </h3>
                    <h3>DISH-NAME     </h3>
                    <h3>TOTAL   </h3>
                </div>
                <div id ="item_list"></div>
            </div>

           
            <div class="total_price_section">
                <div class="total_price_subsection">
                    <table>
                        <tr>
                            <td class="chk_out_total">Total </td>
                            <td class="chk_out_amount" id="chk_out_amount"></td>
                        </tr>
                    </table>
                </div>
            </div>


            <div class="checkout">
                <tr class ="comment_section">
                    <td class="tlabel">NOTE: </td>
                    <td><input type="text" name="name" id="noteInput"></td>
                </tr>

                <!-- <div class ="comment_section">
                    <td class="tlabel">NOTE: </td>
                    <td><input type="text" name="name"></td>
                </div> -->

                <div class = "mode">
                    <input type = "radio" name = "destination" value = "1">Dine-IN<br>
                    <input type = "radio" name = "destination" value = "2">Take-Out<br>
                </div>
                <div class="chk_out_buttn">
                    <button class="chk_out_button" onclick="submitData()">checkout</button>
                </div>
            </div>
            

        </div>

    </div>



</main>
<script src="menu.js"></script>


</body>
</html>
