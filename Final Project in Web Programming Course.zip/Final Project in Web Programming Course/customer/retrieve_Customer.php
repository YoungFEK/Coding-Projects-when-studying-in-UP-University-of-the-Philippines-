<?php
include 'DBConnector.php';

header('Content-Type: application/json');

// Sanitize input
$CustomerID = $_POST['CustomerID'] ?? null;

if (!$CustomerID) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Missing CustomerID"]);
    exit;
}

// Use prepared statement to avoid SQL injection
$sql = "SELECT Customer_Name, Customer_Email, Customer_Contact_No FROM Customer WHERE Customer_ID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $CustomerID); // assuming CustomerID is a string

$stmt->execute();
$result = $stmt->get_result();

$customer = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $customer[] = $row;
    }
}

$stmt->close();
$conn->close();

echo json_encode($customer);
?>