-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2025 at 05:22 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `126testdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `concessionaire`
--

CREATE TABLE `concessionaire` (
  `concessionaire_id` int(11) NOT NULL,
  `Concessionaire_Name` varchar(100) NOT NULL,
  `Concessionaire_Email` varchar(100) DEFAULT NULL,
  `Concessionaire_Password` varchar(100) DEFAULT NULL,
  `Concessionaire_Contact_No` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `concessionaire`
--

INSERT INTO `concessionaire` (`concessionaire_id`, `Concessionaire_Name`, `Concessionaire_Email`, `Concessionaire_Password`, `Concessionaire_Contact_No`) VALUES
(0, 'Tasty Bites', 'tastybites@example.com', 'securepass', '09219876543');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_ID` int(11) NOT NULL,
  `Customer_Name` varchar(100) DEFAULT NULL,
  `Customer_Email` varchar(100) DEFAULT NULL,
  `Customer_Password` varchar(100) DEFAULT NULL,
  `Customer_Contact_No` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_ID`, `Customer_Name`, `Customer_Email`, `Customer_Password`, `Customer_Contact_No`) VALUES
(1, 'John Doe', 'john.doe@example.com', 'password123', '09171234567'),
(2, 'Jane Smith', 'jane.smith@example.com', 'mypassword456', '09179876543'),
(3, 'Carlos Reyes', 'carlos.reyes@example.com', 'carlospass', '09175556667'),
(4, 'Maria Santos', 'maria.santos@example.com', 'mariaspass', '09172345678'),
(5, 'John Doe', 'john@example.com', 'password123', '09171234567');

-- --------------------------------------------------------

--
-- Table structure for table `dish`
--

CREATE TABLE `dish` (
  `Dish_ID` int(11) NOT NULL,
  `Dish_Name` varchar(100) DEFAULT NULL,
  `Concessionaire_Name` varchar(100) DEFAULT NULL,
  `Whole_Serving_Price` decimal(10,2) DEFAULT NULL,
  `Half_Serving_Price` decimal(10,2) DEFAULT NULL,
  `Category` varchar(50) DEFAULT NULL,
  `Availability` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `orderDetailID` int(11) NOT NULL,
  `Dish_ID` int(11) DEFAULT NULL,
  `serving_type` varchar(10) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `total_price` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_table`
--

CREATE TABLE `order_table` (
  `Order_id` int(11) NOT NULL,
  `Order_Date_and_Time` datetime DEFAULT NULL,
  `Customer_ID` int(11) DEFAULT NULL,
  `concessionaire_id` int(11) NOT NULL,
  `Mode` varchar(20) DEFAULT NULL,
  `Comments` text DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `concessionaire`
--
ALTER TABLE `concessionaire`
  ADD PRIMARY KEY (`concessionaire_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_ID`),
  ADD UNIQUE KEY `Customer_Email` (`Customer_Email`);

--
-- Indexes for table `dish`
--
ALTER TABLE `dish`
  ADD PRIMARY KEY (`Dish_ID`),
  ADD KEY `Concessionaire_Name` (`Concessionaire_Name`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`orderDetailID`),
  ADD KEY `Dish_ID` (`Dish_ID`);

--
-- Indexes for table `order_table`
--
ALTER TABLE `order_table`
  ADD PRIMARY KEY (`Order_id`),
  ADD KEY `Customer_ID` (`Customer_ID`),
  ADD KEY `fk_concessionaire` (`concessionaire_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dish`
--
ALTER TABLE `dish`
  ADD CONSTRAINT `dish_ibfk_1` FOREIGN KEY (`Concessionaire_Name`) REFERENCES `concessionaire` (`Concessionaire_Name`);

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`Dish_ID`) REFERENCES `dish` (`Dish_ID`);

--
-- Constraints for table `order_table`
--
ALTER TABLE `order_table`
  ADD CONSTRAINT `fk_concessionaire` FOREIGN KEY (`concessionaire_id`) REFERENCES `concessionaire` (`concessionaire_id`),
  ADD CONSTRAINT `order_table_ibfk_1` FOREIGN KEY (`Customer_ID`) REFERENCES `customer` (`Customer_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
