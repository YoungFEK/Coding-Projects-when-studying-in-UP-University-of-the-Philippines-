<?php
$servername = "localhost";
$username="root";
$password="";
$dbname="126testdbv2";

$conn = new mysqli($servername, $username, $password, $dbname);



?>