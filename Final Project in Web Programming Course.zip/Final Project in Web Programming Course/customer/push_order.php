<?php
include 'DBConnector.php';

header('Content-Type: application/json');

$customer_comment = $_POST['customer_comment'] ?? null;
$mode = $_POST['mode_of_pickup'] ?? null;
$order_date = date('Y-m-d');
$order_time = date('H:i:s');

// $push = "INSERT INTO `order_table` (`Order_id`,`Order_Date`, `Order_Time`, `Customer_ID`, `concessionaire_id`, `Mode`, `Comments`, `Status`) VALUES 
// ( ,$order_date, $order_time, 123, 456, '$mode', '$customer_comment', 'Pending');";

$push = "INSERT INTO `order_table` (`Order_Date`, `Order_Time`, `Customer_ID`, `concessionaire_id`, `Mode`, `Comments`, `Status`) 
        VALUES ('$order_date', '$order_time', 123, 456, '$mode', '$customer_comment', 'Pending');";
$conn->query($push);

$conn->close();

// echo json_encode($result);

?>