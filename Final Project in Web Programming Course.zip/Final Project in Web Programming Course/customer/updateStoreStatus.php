<?php
include 'DBConnector.php';

if (isset($_POST['Status'])) {
    $status = $_POST['Status'];
}

    $sql="UPDATE concessionaire SET status = $status WHERE concessionaire_id = 1";
    $result = $conn->query($sql);


$conn->close();
?>