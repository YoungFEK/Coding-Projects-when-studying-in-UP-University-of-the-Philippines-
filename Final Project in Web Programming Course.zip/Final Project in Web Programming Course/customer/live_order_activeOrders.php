<?php
include 'DBConnector.php';

header('Content-Type: application/json');

$concessionaire_id = $_POST['concessionaire_id'] ?? null;



$sql = "SELECT * FROM order_table where status='Preparation' and concessionaire_id = $concessionaire_id and order_Date = current_date()";
$result = $conn->query($sql);



$orders = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
}

$conn->close();
echo json_encode($orders);
?>