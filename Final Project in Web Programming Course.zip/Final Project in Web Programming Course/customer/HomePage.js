function openLoginForm() {
  document.getElementById("LoginForm").style.display = "block";
}

function closeLoginForm() {
  document.getElementById("LoginForm").style.display = "none";
}


function openSignUpForm() {
  document.getElementById("SignUpForm").style.display = "block";
}

function closeSignUpForm() {
  document.getElementById("SignUpForm").style.display = "none";
}