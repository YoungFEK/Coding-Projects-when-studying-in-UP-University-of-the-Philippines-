<?php
include 'DBConnector.php';

if (!isset($_POST['orderId'])) {
    http_response_code(400); // Bad Request
    echo json_encode(["error" => "Missing orderId"]);
    exit;
}

$orderID = $_POST['orderId'];


$sql = $conn->prepare(
    "SELECT 
        od.Dish_ID,
        d.Dish_Name,
        od.qty,
        CASE 
            WHEN od.serving_type = 1 THEN 'Half Serving'
            WHEN od.serving_type = 2 THEN 'Whole Serving'
            ELSE 'Unknown'
        END AS serving_label,
        CASE 
            WHEN od.serving_type = 1 THEN d.Half_Serving_Price
            WHEN od.serving_type = 2 THEN d.Whole_Serving_Price
            ELSE NULL
        END AS price,
        od.qty * 
        CASE 
            WHEN od.serving_type = 1 THEN d.Half_Serving_Price
            WHEN od.serving_type = 2 THEN d.Whole_Serving_Price
            ELSE 0
        END AS total_price
    FROM 
        order_details od
        JOIN dish d ON od.Dish_ID = d.Dish_ID
    WHERE 
        od.Order_id = ?"
);

$sql->bind_param("i", $orderID);
$sql->execute();
$result = $sql->get_result();

$order = [];

while ($row = $result->fetch_assoc()) {
    $order[] = $row;
}

header('Content-Type: application/json');
echo json_encode($order);

$sql->close();
$conn->close();
?>