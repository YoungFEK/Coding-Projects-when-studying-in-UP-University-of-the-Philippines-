<?php
include 'DBConnector.php';

$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Access the data
$customer_comment = $data['customer_comment'];
$mode_of_pickup = $data['mode_of_pickup'];
$order_details = $data['order_details']; // This will be your array of objects
$order_date = date('Y-m-d');
$order_time = date('H:i:s');

$push = "INSERT INTO `order_table` (`Order_Date`, `Order_Time`, `Customer_ID`, `concessionaire_id`, `Mode`, `Comments`, `Status`) 
        VALUES ('$order_date', '$order_time', 123, 1, '$mode_of_pickup', '$customer_comment', 'Preparation');";

$conn->query($push);

$order_id = $conn->insert_id;

// Process the order items
foreach ($order_details as $array) {
    $dish_id = $array['dish_id'];
    $dish_name = $array['dish_name'];
    $serving_type = $array['serving_type'];
    $quantity = $array['quantity'];
    $serving_price = $array['serving_price'];
    $total_price = $array['total_price'];

    $push = "INSERT INTO `order_details` (`Order_id`, `Dish_ID`, `serving_type`, `qty`, `price`, `total_price`)
    VALUES ('$order_id', '$dish_id', '$serving_type', '$quantity', '$serving_price', '$total_price');";

    $conn->query($push);

}


// echo json_encode($result);
$conn->close();

?>