<?php
include 'DBConnector.php';

// Example department ID
// $getDish = "SELECT * FROM dish";

$getDish = "SELECT * 
            FROM dish
            WHERE concessionaire_id = 2
            ORDER BY 
                CASE Category
                WHEN 'Main Course' THEN 1
                WHEN 'Pasta' THEN 2
                WHEN 'Snack' THEN 3
                ELSE 4
            END";

$dishResult = $conn->query($getDish);

if ($dishResult->num_rows > 0) {

    $dishCategory = "";

    while($dishRow = $dishResult->fetch_assoc()) {
        
        if($dishCategory != $dishRow["Category"]){
            $dishCategory = $dishRow["Category"];
            echo '<h2>'.$dishRow["Category"]. '</h2>';
        }


        echo '
        <div class="menu_card">
            <h3>' .$dishRow["Dish_Name"]. '</h3>
            <div class="servings">
                    <div class="half_serve">
                        <p class = "serve_label">HALF-SERVE:</p>    
                        <p class="half_serving_price">P'.$dishRow["Half_Serving_Price"]. '</p>
                        <button class = "add_serving" onclick = "addtocart('.$dishRow["Dish_ID"].',\''.$dishRow["Dish_Name"].'\',\'HALF-SERVE\','.$dishRow["Half_Serving_Price"].')">Add</button>
                    </div>
                    <div class="whole_serve"> 
                        <p class = "serve_label" style="width:1">WHOLE-SERVE:</p>
                        <p class="whole_serving_price">P'.$dishRow["Whole_Serving_Price"]. '</p>
                        <input type="text" style="display:none;" name="EmpID" value='.$dishRow["Dish_Name"].'>
                        <input type="text" style="display:none;" name="EmpID" value="HALF-SERVE">
                        <button class = "add_serving" onclick = "addtocart('.$dishRow["Dish_ID"].',\''.$dishRow["Dish_Name"].'\',\'WHOLE-SERVE\','.$dishRow["Whole_Serving_Price"].')">Add</button>
                    </div>
            </div>
            


        </div>
        ';
    }



} else {
    echo "0 results";
}

$conn->close();
?>
