<?php
include 'DBConnector.php';

$Serving_type = $_POST["Serving_type"];
$Dish_Name = $_POST["Dish_Name"];
$Dish_ID = $_POST["Dish_ID"];


$conn->close();
?>
