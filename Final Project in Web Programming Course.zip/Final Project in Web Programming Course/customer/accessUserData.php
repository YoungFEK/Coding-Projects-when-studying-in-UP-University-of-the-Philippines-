<?php

session_start();

require 'DBConnector.php'
$CustomerEmail = $_POST['email'];
$UserPassword = $_POST['psw'];

// Basic query to check credentials
$sql = "SELECT * FROM customers WHERE Customer_Email = '$CustomerEmail' AND Customer_Password = '$UserPassword'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    // Successful login
    $customer = $result->fetch_assoc();

    $_SESSION['Customer_ID'] = $customer['Customer_ID'];
    $_SESSION['Customer_Name'] = $customer['Customer_Name']; 
    $_SESSION['Customer_Email'] = $customer['Customer_Email'];
    $_SESSION['Customer_Password'] = $customer['Customer_Password']; 
    $_SESSION['Customer_Contact_No'] = $customer['Customer_Contact_No'];
    

    $conn->close();

    header("Location: homepage.html");
    exit();
} else {
    header("Location: login.php?error=1"); // Redirect with error
    exit();
}

$conn->close();
?>