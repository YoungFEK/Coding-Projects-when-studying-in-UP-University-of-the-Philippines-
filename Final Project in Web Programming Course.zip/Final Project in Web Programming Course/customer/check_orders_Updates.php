<?php
include 'DBConnector.php';

header('Content-Type: application/json');

$concessionaire_id = $_POST['concessionaire_id'] ?? null;


$sql = "SELECT MAX(Order_Time) AS latest FROM order_table WHERE concessionaire_id = $concessionaire_id and order_Date = current_date()";

$result = mysqli_query($conn, $sql);

if ($result && mysqli_num_rows($result) > 0) {
    $order = mysqli_fetch_assoc($result);
    echo json_encode(['latest' => $order['latest'] ?? null]);
} else {
    echo json_encode(['latest' => null]);
}
?>