<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>NAME OF WEBSITE</title>
    <link rel="stylesheet" type="text/css" href="homePage.css">
</head>

<body>
<header>
    <div class="navbar">
        <!-- <h1><img src="logo.png" class = "logo"></h1> -->
        <h1>UPV PREORDER WEBSITE</h1>
        <!-- ASK  about button 1 and 2 and why are they necessary -->
        <div class="navbutton1" id ="register_buttons">
            <button class="login" id="login" onclick="openLoginForm()">Log In</button>
            <button class="signup"id="signup" onclick="openSignUpForm()">Sign up</button>
        </div>
        <div class="navbutton2">
            <p>&#9776;</p>
            <button class="logout" onclick="">&#9776;</button>
        </div>
    </div>
</header>

<div class="search-section">
    <h2>Where do you want to order?</h2>
    <input type="text" placeholder="Enter concessioner">
    <button>Show Menu</button>
</div>

<div class="card-container">
    <div class="card">
        <img src="ManangBetchLogo.jpg">
        <div class="card-content">
            <h3>Manang Betch</h3>
            <a href="MenuMB.php" class="btn">View Menu</a>
            <!-- <button class="btn">View Menu</button> -->
        </div>
    </div>

    <div class="card">
        <img src="VineyardLogo.jpg">
        <div class="card-content">
            <h3>Vineyard</h3>
            <a href="MenuV.php" class="btn">View Menu</a>
            <!-- <button class="btn">View Menu</button> -->
        </div>
    </div>
</div>

<div class="form-popup" id="LoginForm">
    <form action="accessUserData.php" class="form-container" method=post>
        <h1>Log in to Website Name</h1>
        <input type="text" placeholder="Email" name="email" required>

        <input type="password" placeholder="Password" name="psw" required>

        <button type="submit" class="btn" onclick="refreshPage(event)">Login</button>
        <button type="button" class="btn cancel" onclick="closeLoginForm()">Close</button>
    </form>
</div>


<div class="form-popup" id="SignUpForm">
    <form action="addUserData.php" class="form-container" method=post>
        <h1>Sign up to Website Name</h1>

        <input type="text" placeholder="Name" name="name" required>
        <input type="text" placeholder="Email" name="email" required>
        <input type="text" placeholder="Contact no." name="contactNumber" required>
        <input type="password" placeholder="Password" name="psw" required>

        <button type="submit" class="btn" onclick="refreshPage(event)">Login</button>
        <button type="button" class="btn cancel" onclick="closeSignUpForm()">Close</button>
    </form>
</div>

<script src="HomePage.js"></script>
</body>
</html>
