<?php
include 'DBConnector.php';

header('Content-Type: application/json');

// Sanitize input
$concessionaire_id = $_POST['concessionaire_id'] ?? null;
$CategoryID = $_POST['Category'] ?? null;




if (!$concessionaire_id) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Info"]);
    exit;
}


$getName="SELECT category_name FROM category WHERE category_id = '$CategoryID'";
if ($getName->num_rows > 0) {
$row = $result->fetch_assoc();
$categoryName = $row['category_name'];}
$sql = "DELETE FROM `category` WHERE category_id='$CategoryID'";

$result = $conn->query($sql);

if ($result) {
    $update = "UPDATE `dish` SET `Category` = NULL WHERE 'Category' = '$categoryName'";
    $conn->query($update);
}


header("Location: menu_edit.php");


$conn->close();

echo json_encode($result);
?>


