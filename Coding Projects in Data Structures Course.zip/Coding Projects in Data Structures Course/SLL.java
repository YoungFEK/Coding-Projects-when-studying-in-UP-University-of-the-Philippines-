public class SLL {
    // Attributes
    private int size;
    private SLLNode head;
    private SLLNode tail;

    public SLL() {
        this.size = 0;
        this.head = null;
        this.tail = null;
    }

    // Getters
    public int getSize() {
        return this.size;
    }

    public boolean isEmpty() {
        return this.size == 0;
    }

    public SLLNode getHead() {
        return this.head;
    }

    public SLLNode getTail() {
        return this.tail;
    }

    // Set head method
    public void setHead(SLLNode node) {
        // if (this.head == null) {
        //     this.head = node;
        //     this.tail = node;
        // } else {
            // node.setNext(this.head);
            // this.head = node;
        // }
        // this.size++;
        this.head = node;
    }

    // Set tail method
    public void setTail(SLLNode node) {
        // if (this.tail == null) {
        //     this.head = node;
        //     this.tail = node;
        // } else {
        //     this.tail.setNext(node);
        //     this.tail = node;
        // }
        // this.size++;
        this.tail = node;
    }

    // Add node (usually at the tail)
    public void addNode(String value) {
        SLLNode newNode = new SLLNode(value);
        // setTail(newNode);   // add at the tail

        if (this.tail == null) {
            setHead(newNode);
            setTail(newNode);
        } else {
            // this.tail.setNext(newNode);          //code for adding the node at the tail if list is not empty
            // setTail(newNode);
            newNode.setNext(this.head);
            setHead(newNode);
        }
        this.size++;
    }

    // Remove node by value
    public SLLNode removeNode(String value) {
        if (this.head == null) {
            return null;  // list is empty
        }

        SLLNode rem = this.head;
        SLLNode prev = null;

        while (rem != null && !rem.getValue().equals(value)) {  // correct access to value
            prev = rem;
            rem = rem.getNext();
        }

        if (rem == null) {
            return null;  // value not found
        }

        if (rem == this.head) {
            this.head = rem.getNext();
            if (this.head == null) {
                this.tail = null;  // empty list after removal
            }
        } else if (rem == this.tail) {
            this.tail = prev;
            prev.setNext(null);
        } else {
            prev.setNext(rem.getNext());
        }

        rem.setNext(null);  // clean up the removed node
        this.size--;
        return rem;  // returning the node instead of value
    }


    // NOTE: Add the incrementSize() and decrementSize() methods to the "SLL" class
    public void incrementSize(){
        this.size +=1;
    }

    public void decrementSize(){
        this.size -=1;
    }
}
