// LABORATORY EXERCISE NO. 4 TESTER
// from Sir Jayvee's LAB 3 Tester, Altered by: Keith Ashly M. Domingo

// !!! W A R N I N G !!!
// DO NOT EDIT THE CONTENTS OF THIS FILE UNLESS PROMPTED TO DO SO
// ANY UNSOLICITED MODIFICATIONS TO THIS FILE WILL RESULT TO A SCORE OF '0' IN THIS EXERCISE

import java.util.Scanner;
import java.util.Random;

public class Lab4Tester{

	public static String randomString(){
		Random rng = new Random();
		int length = 25;
		String allChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvwxyz" + "0123456789" + "!@#$%^&*+-/=?,.";
	    char[] text = new char[length];
	    for (int i = 0; i < length; i++){
	        text[i] = allChars.charAt(rng.nextInt(allChars.length()));
	    }
	    return new String(text);
	}

	// Circular Queue Tester
	public static void CircularQueueTest() throws NullPointerException{
		int score = 0;
		int TOTAL = 50;
		CircularQueue testArray = new CircularQueue(5);
		
		// Initial Test for 'size'
		try{
			if (testArray.isEmpty()){
				score+=2;
			}
		}catch(Exception e){
			System.out.println("ERROR: Problem initializing queue!" + e);
			return;
		}

		String[] randStrings = new String[10];
		// Initial Test for 'enqueue()'
		try{
			for (int i=0; i<5; i++){
				randStrings[i] = randomString();
				testArray.enqueue(randStrings[i]);
			}
		}catch(Exception e){
			System.out.println("ERROR: enqueue() is not enqueueing! " + e);
			return;
		}

		try{
			int testArraySize = testArray.getSize();
			for (int i=0; i<testArraySize; i++){
				if ((testArray.getContents()[i]).getValue() == randStrings[i]){
					score+=1;
				}
			}
		}catch(Exception e){
			System.out.println("ERROR: enqueue() not working properly! " + e);
			return;
		}

		// Initial Test for 'wrapAround()'
		try{
			for (int i=0; i<3; i++){
				testArray.dequeue();
				testArray.enqueue(randStrings[i]);
			}
			String front = testArray.front().getValue();

			for (int i=5; i<10; i++){
				randStrings[i] = randomString();
				testArray.enqueue(randStrings[i]);
			}

			if (testArray.front().getValue() == front){
				score+=2;
			}

			if (testArray.getSize() == 10){
				score+=2;
			}
		}catch(Exception e){
			System.out.println("ERROR: wrapAround() is not wrapping around! " + e);
			return;
		}

		for (int i=0; i<10; i++){
			testArray.dequeue();
		}

		randStrings = new String[10];
		for (int i=0; i<10; i++){
			randStrings[i] = randomString();
			testArray.enqueue(randStrings[i]);
		}

		int testArraySize = testArray.getSize();
		
		for (int i=0; i<testArraySize; i++){
			if ((testArray.getContents()[i].getValue()) == randStrings[i]){
				score+=2;
			}
		}
		System.out.println();
	
		for (int i=0; i<5; i++){
			int prevSize = testArray.getSize();
			String dequeued = testArray.front().getValue();
			String removed = testArray.dequeue().getValue();
			
			try {
				if (testArray.getSize() == (prevSize - 1)){
					score+=1;
				}
				if (dequeued == removed){
					score+=1;
				}
				if (randStrings[i] == removed){
					score+=1;
				}
			}catch(Exception e){
				System.out.println("ERROR: dequeue() not working properly! " + e);
			}
		}

		String back = testArray.rear().getValue();
		if (testArray.getContents()[testArray.getCapacity()-1].getValue() == back){
			score+=2;
		}

		for (int i=5; i<10; i++){
			testArray.dequeue();
		}

		if (testArray.isEmpty()){
			score+=2;
		}

		System.out.println("Your TOTAL SCORE is " + score + "/" + TOTAL + ".");
		System.out.println("Percentage: " + (score*100/TOTAL) + "%");
		if (score == TOTAL){
			System.out.println("PERFECT SCORE!!!");
		}	
	}

	// DLLDeque Tester
	public static void DLLDequeTest() throws NullPointerException{
		float score = 0;
		int TOTAL = 50;
		DLLDeque testDLL = new DLLDeque();
		
		if (testDLL.isEmpty()){
			score+=2;
		}

		try {
			String first = testDLL.first().getValue();
		} catch (NullPointerException exception){
			score+=2;
		}

		try {
			String last = testDLL.last().getValue();
		} catch (NullPointerException exception){
			score+=2;
		}

		String[] randStrings1 = new String[10];
		for (int i=4; i>=0; i--){
			randStrings1[i] = randomString();
			testDLL.insertFirst(randStrings1[i]);
		}
		for (int i=5; i<10; i++){
			randStrings1[i] = randomString();
			testDLL.insertLast(randStrings1[i]);
		}
		
		if (testDLL.getSize() == 10){
			score+=3;
		}

		int i = 0;
		DLLNode current = testDLL.first();
		if (current.getValue() == randStrings1[i]){
			while (current != null){
				if (current.getValue() == randStrings1[i]){
					score+=1;
				}
				current = current.getNext();
				i+=1;
			}
		}
		
		i = 9;
		randStrings1 = new String[10];
		current = testDLL.last();

		while (current != null){
			randStrings1[i] = randomString();
			current.setValue(randStrings1[i]);
			current = current.getPrev();
			i-=1;
		}

		i = 9;
		current = testDLL.last();
		while (current != null){
			if (current.getValue() == randStrings1[i]){
				score+=1;
				current = current.getPrev();
				i-=1;
			}
		}
		
		for (i=0; i<5; i++){
			int prevSize = testDLL.getSize();
			DLLNode removed = testDLL.removeFirst();
	
			if (testDLL.first() != null){
				if (removed.getValue() == randStrings1[i]){
					score+=1;
				}
				if (removed.getNext() == null){
					score+=0.5;
				}
				if (testDLL.first().getValue() != randStrings1[i]){
					score+=1;
				}
				if (testDLL.getSize() == (prevSize - 1)){
					score+=0.5;
				}
			}
		}

		for (i=5; i<10; i++){
			testDLL.removeLast();
		}

		if (testDLL.isEmpty()){
			score+=2;
		}

		try {
			String first = testDLL.first().getValue();
		} catch (NullPointerException exception){
			score+=2;
		}

		try {
			String last = testDLL.last().getValue();
		} catch (NullPointerException exception){
			score+=2;
		}
		
		System.out.println("Your TOTAL SCORE is " + score + "/" + TOTAL + ".");
		System.out.println("Percentage: " + (score*100/TOTAL) + "%");
		if (score == TOTAL){
			System.out.println("PERFECT SCORE!!!");
		}
	}

	// Main
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("LABORATORY EXERCISE #4 TESTER\nOptions:\n1 - Circular Queue\n2 - DLL Deque\n* - Exit");
		System.out.print("Choice:");
		int choice = scanner.nextInt();

		if (choice == 1){
			CircularQueueTest();
		}
		else if (choice == 2){
			DLLDequeTest();
		}
		else{
			System.exit(0);
		}
	}
}