public class Element{
	// insert attributes
	private String value;
	private int index;


	// public Element(String value1, int index1){
	// 	// constructor
	// 	this.value = value1;
	// 	this.index = index1;
	// }

	// implemented changes because of lab5---------------------------
	public Element(int index1, String value1){
		// constructor
		this.index = index1;
		this.value = value1;
	}

//Methods
	public void setValue(String setValue){
		this.value = setValue;
	}

	public String getValue(){
		return this.value;
	}

	public void setIndex(int setIndex) {
		this.index = setIndex;
    }

	public int getIndex() {
        return this.index;
    }
}
