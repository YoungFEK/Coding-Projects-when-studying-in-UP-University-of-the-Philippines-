// LABORATORY EXERCISE NO. 6 TESTER
// Created by: Jayvee B. Castañeda

// !!! W A R N I N G !!!
// DO NOT EDIT THE CONTENTS OF THIS FILE UNLESS PROMPTED TO DO SO
// ANY UNSOLICITED MODIFICATIONS TO THIS FILE WILL RESULT TO A SCORE OF '0' IN THIS EXERCISE

import java.util.Random;
import java.util.Scanner;

public class Lab6Tester{

	public static String randomString(){
		Random rng = new Random();
		int length = 25;
		String allChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvwxyz" + "0123456789" + "!@#$%^&*+-/=?,.";
	    char[] text = new char[length];
	    for (int i = 0; i < length; i++){
	        text[i] = allChars.charAt(rng.nextInt(allChars.length()));
	    }
	    return new String(text);
	}

	public void UnsortedPQTest(){
		UnsortedPQ testPQ = new UnsortedPQ();
		
		// Initial Test for 'size'
		try{
			if (testPQ.isEmpty()) System.out.println("Unsorted Priority Queue initialized successfully");
		}catch(Exception e){
			System.out.println("Error: Problem initializing Unsorted Priority Queue");
		}

		testPQ.insert(new Entry(10,"wholly"));
		testPQ.insert(new Entry(2,"wand"));
		testPQ.insert(new Entry(11,"nice"));
		testPQ.insert(new Entry(5,"ease"));
		testPQ.insert(new Entry(8,"silent"));
		testPQ.insert(new Entry(1,"eye"));
		testPQ.insert(new Entry(13,"knew"));
		testPQ.insert(new Entry(4,"kurisumasu"));
		testPQ.insert(new Entry(0,"all"));
		testPQ.insert(new Entry(15,"!!!"));
		testPQ.insert(new Entry(7,"bay bee"));
		testPQ.insert(new Entry(14,"here"));
		testPQ.insert(new Entry(3,"four"));
		testPQ.insert(new Entry(9,"knight"));
		testPQ.insert(new Entry(6,"ewe"));
		testPQ.insert(new Entry(12,"happee"));

		try{
			// Size Test
			if (testPQ.getSize() == 16) System.out.println("Entry() instantiation, insert(), and/or getSize() working properly");
		}catch(Exception e){
			System.out.println("Error: Entry() instantiation, insert(), and/or getSize() not working properly");
		}
		
		// Print Unsorted PQ
		System.out.println("=== Unsorted Priority Queue ===");
		String str = "";
		DLLEntryNode current = testPQ.getHead();
		while (current != null){
			str += (current.getEntry().getValue() + " ");
			current = current.getNext();
		}
		System.out.println(str);
		System.out.println("=== <$$$> ===\n");

		try{
			while (testPQ.getSize()>4){
				int minKey = testPQ.min().getKey();
				System.out.println("Minimum Key: " + minKey);
				int minKey2 = testPQ.remove_min().getKey();
				if (minKey != minKey2){
					return;
				}
			}
		}catch(Exception e){
			System.out.println("Error: min() or remove_min() not working properly");
		}

		try{
			testPQ.insert(new Entry(0,"We Wish You A Merry Christmas"));
			testPQ.insert(new Entry(0,"White Christmas"));
			testPQ.insert(new Entry(-1,"Santa Claus is Coming to Town"));
			testPQ.insert(new Entry(0,"Rockin' Around the Christmas Tree"));
			testPQ.insert(new Entry(1,"Jingle Bells"));
			testPQ.insert(new Entry(2,"Fa La La"));
			testPQ.insert(new Entry(3,"Little Drummer Boy"));
			testPQ.insert(new Entry(-1,"Deck the Halls"));
			testPQ.insert(new Entry(1,"Christmas In Our Hearts"));

			System.out.println("=== After Insertion Of New Entries ===");
			str = "";
			current = testPQ.getHead();
			while (current != null){
				str += "| "+ (current.getEntry().getValue() + " |");
				current = current.getNext();
			}
			System.out.println(str);
			System.out.println("=== <$$$> ===\n");

		}catch(Exception e){
			System.out.println("Error: inserting with existing keys should overwrite the values");
		}

		while (!testPQ.isEmpty()){
			testPQ.remove_min();
		}

		try{
			if (testPQ.min() != null){
				System.out.println("Error: Unsorted Priority Queue does not allow min() if empty");
			}	
			if (testPQ.remove_min() != null){
				System.out.println("Error: Unsorted Priority Queue does not allow remove_min() if empty");
			}
		}catch(Exception e){
		}
	}

	// Sorted Priority Queue Tester
	public void SortedPQTest(){
		SortedPQ testPQ = new SortedPQ();
		
		// Initial Test for 'size'
		try{
			if (testPQ.isEmpty()) System.out.println("Sorted Priority Queue initialization Successful");
		}catch(Exception e){
			System.out.println("Error: Problem initializing Sorted Priority Queue");
		}

		testPQ.insert(new Entry(10,"wholly"));
		testPQ.insert(new Entry(2,"wand"));
		testPQ.insert(new Entry(11,"nice"));
		testPQ.insert(new Entry(5,"ease"));
		testPQ.insert(new Entry(8,"silent"));
		testPQ.insert(new Entry(1,"eye"));
		testPQ.insert(new Entry(13,"knew"));
		testPQ.insert(new Entry(4,"kurisumasu"));
		testPQ.insert(new Entry(0,"all"));
		testPQ.insert(new Entry(15,"!!!"));
		testPQ.insert(new Entry(7,"bay bee"));
		testPQ.insert(new Entry(14,"here"));
		testPQ.insert(new Entry(3,"four"));
		testPQ.insert(new Entry(9,"knight"));
		testPQ.insert(new Entry(6,"ewe"));
		testPQ.insert(new Entry(12,"happee"));

		try{
			// Size Test
			if (testPQ.getSize() == 16) System.out.println("Entry() instantiation, insert(), and/or getSize() is working properly");
		}catch(Exception e){
			System.out.println("Error: Entry() instantiation, insert(), and/or getSize() not working properly");
		}
		
		// Print Sorted PQ
		System.out.println("=== Sorted Priority Queue ===");
		String str = "";
		DLLEntryNode current = testPQ.getHead();
		while (current != null){
			str += (current.getEntry().getValue() + " ");
			current = current.getNext();
		}
		System.out.println(str);
		System.out.println("=== <$$$> ===\n");

		try{
			while (testPQ.getSize()>4){
				int minKey = testPQ.min().getKey();
				System.out.println("Minimum Key: " + minKey);
				int minKey2 = testPQ.remove_min().getKey();
				if (minKey != minKey2){
					return;
				}
			}
		}catch(Exception e){
			System.out.println("Error: min() or remove_min() not working properly");
		}

		try{
			testPQ.insert(new Entry(0,"We Wish You A Merry Christmas"));
			testPQ.insert(new Entry(0,"White Christmas"));
			testPQ.insert(new Entry(-1,"Santa Claus is Coming to Town"));
			testPQ.insert(new Entry(0,"Rockin' Around the Christmas Tree"));
			testPQ.insert(new Entry(1,"Jingle Bells"));
			testPQ.insert(new Entry(2,"Fa La La"));
			testPQ.insert(new Entry(3,"Little Drummer Boy"));
			testPQ.insert(new Entry(-1,"Deck the Halls"));
			testPQ.insert(new Entry(1,"Christmas In Our Hearts"));

			System.out.println("=== After Insertion Of New Entries ===");
			str = "";
			current = testPQ.getHead();
			while (current != null){
				str += "| "+ (current.getEntry().getValue() + " |");
				current = current.getNext();
			}
			System.out.println(str);
			System.out.println("=== <$$$> ===\n");

		}catch(Exception e){
			System.out.println("Error: inserting with existing keys should overwrite the values");
		}

		while (!testPQ.isEmpty()){
			testPQ.remove_min();
		}

		try{
			if (testPQ.min() != null){
				System.out.println("Error: Sorted Priority Queue does not allow min() if empty");
			}	
			if (testPQ.remove_min() != null){
				System.out.println("Error: Sorted Priority Queue does not allow remove_min() if empty");
			}
		}catch(Exception e){
		}
	}

	// Main
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("LABORATORY EXERCISE #6 TESTER\nOptions:\n1 - Unsorted Priority Queue\n2 - Sorted Priority Queue\n* - Exit");
		System.out.print("Choice:");
		int choice = scanner.nextInt();

		Lab6Tester tester = new Lab6Tester();

		if (choice == 1){
			tester.UnsortedPQTest();
		}
		else if (choice == 2){
			tester.SortedPQTest();
		}
		else{
			System.exit(0);
		}
	}
}