public class DLLNode{
    //Attributes
    private String value;
    private DLLNode prev;
    private DLLNode next;

    //constructor with initialization of values
    public DLLNode(String value) {
        this.value = value;
        this.prev = null;
        this.next = null;
    }


    //setter and getter methods

    //methods for the value of the indiv node
    public void setValue(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }

    //methods for setting the previous node
    public void setPrev(DLLNode node){
        this.prev = node;
    }

    public DLLNode getPrev(){
        return this.prev;
    }


    //methods for setting the next node
    public void setNext(DLLNode node){
        this.next = node;
    }

    public DLLNode getNext(){
        return this.next;
    }

}
