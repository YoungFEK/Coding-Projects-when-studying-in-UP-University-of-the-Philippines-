import java.util.*;

class HuffmanNode {
    char character;
    int frequency;
    HuffmanNode leftChild;
    HuffmanNode rightChild;

    HuffmanNode(char character, int frequency) {
        this.character = character;
        this.frequency = frequency;
        this.leftChild = null;
        this.rightChild = null;
    }
}

class HuffmanCoding {

    public static int[][] calculateFrequencies(String inputText) {
        int[][] frequencies = new int[256][2];
        for (char c : inputText.toCharArray()) {
            frequencies[c][0] = c;
            frequencies[c][1]++;
        }
        return frequencies;
    }

    public static HuffmanNode buildHuffmanTree(int[][] frequencies) {
        List<HuffmanNode> nodes = new ArrayList<>();
        for (int[] freq : frequencies) {
            if (freq[1] > 0) {
                nodes.add(new HuffmanNode((char) freq[0], freq[1]));
            }
        }

        while (nodes.size() > 1) {
            nodes.sort(Comparator.comparingInt(n -> n.frequency));

            HuffmanNode leftNode = nodes.remove(0);
            HuffmanNode rightNode = nodes.remove(0);

            HuffmanNode combinedNode = new HuffmanNode('\0', leftNode.frequency + rightNode.frequency);
            combinedNode.leftChild = leftNode;
            combinedNode.rightChild = rightNode;

            nodes.add(combinedNode);
        }

        return nodes.get(0);
    }

    public static void generateHuffmanCodes(HuffmanNode node, String code, String[] codes) {
        if (node == null) return;

        if (node.character != '\0') {
            codes[node.character] = code;
        }

        generateHuffmanCodes(node.leftChild, code + "0", codes);
        generateHuffmanCodes(node.rightChild, code + "1", codes);
    }

    public static String encodeText(String text, String[] codes) {
        StringBuilder encodedText = new StringBuilder();
        for (char c : text.toCharArray()) {
            encodedText.append(codes[c]);
        }
        return encodedText.toString();
    }

    public static String decodeText(String encodedText, HuffmanNode root) {
        StringBuilder decodedText = new StringBuilder();
        HuffmanNode currentNode = root;

        for (char bit : encodedText.toCharArray()) {
            currentNode = (bit == '0') ? currentNode.leftChild : currentNode.rightChild;

            if (currentNode.character != '\0') {
                decodedText.append(currentNode.character);
                currentNode = root;
            }
        }

        return decodedText.toString();
    }

    public static void visualizeHuffmanTree(HuffmanNode node, int level, String prefix) {
        if (node == null) return;

        for (int i = 0; i < level * 4; i++) {
            System.out.print(" ");
        }
        System.out.println(prefix + (node.character != '\0' ? "(" + node.character + ", " : "(") + node.frequency + ")");
        visualizeHuffmanTree(node.leftChild, level + 1, "L--- ");
        visualizeHuffmanTree(node.rightChild, level + 1, "R--- ");
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String userInput = scanner.nextLine();

        int[][] frequencies = calculateFrequencies(userInput);
        HuffmanNode tree = buildHuffmanTree(frequencies);

        String[] codes = new String[256];
        generateHuffmanCodes(tree, "", codes);

        String encodedText = encodeText(userInput, codes);
        String decodedText = decodeText(encodedText, tree);

        int originalBits = userInput.length() * 8;
        int encodedBits = encodedText.length();

        System.out.println("\nHuffman Tree Visualization:");
        visualizeHuffmanTree(tree, 0, "Root: ");

        System.out.println("\nHuffman Codes:");
        System.out.printf("%-10s | %-13s | %-10s | %-10s\n", "Character", "Frequency", "Huffman Code", "Total Size");
        for (int[] freq : frequencies) {
            if (freq[1] > 0) {
                char character = (char) freq[0];
                String code = codes[character];
                int frequency = freq[1];
                int codeSize = code.length();
                int characterTotalBits = frequency * codeSize;

                System.out.printf("%-10s | %-13d | %-10s | %-10d\n", character, frequency, code, characterTotalBits);
            }
        }

        int compressedSize = encodedBits;

        System.out.println("\nOriginal Number of Bits Without Encoding: " + originalBits + " bits");
        System.out.println("Number of Bits After Huffman Encoding: " + compressedSize + " bits");

        System.out.println("\nEncoded Text:");
        System.out.println(encodedText);

        System.out.println("\nDecoded Text:");
        System.out.println(decodedText);

        if (userInput.equals(decodedText)) {
            System.out.println("\nDecoding Successful: Original text matches decoded text.");
        } else {
            System.out.println("\nDecoding Failed: Original text does not match decoded text.");
        }
    }
}
