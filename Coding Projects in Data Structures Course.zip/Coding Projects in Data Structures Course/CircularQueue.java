public class CircularQueue extends Array{
	// Note that class "CircularQueue" inherits the class "Array" attributes and methods

	// insert attributes (if any)
	private int frontIndex;
	private int rearIndex;

	public CircularQueue (int capacity){
		// constructor
		super(capacity);
		this.frontIndex = 0;
		this.rearIndex = -1;
	}

	public Element front(){
		// The front() operation returns a reference value to the front element of the queue, but doesn’t remove it
		return getContents()[this.frontIndex];
	}

	public Element rear(){
		// The rear() operation returns a reference value to the last element of the queue, but doesn’t remove it
		return getContents()[this.rearIndex];
	}

	public void enqueue(String value){
		// The enqueue() operation inserts an item at the back of the queue
		// You are not allowed to enqueue() an item to the queue when full
		// If the capacity is full, prompt the expand() method and call the wrapAround() method before enqueueing

		if(getSize() == getCapacity()){
			System.out.println("Prompt: queue is full, calling expand() and wrapAround()");
			expand();
			wrapAround();
		}

		this.rearIndex = (this.rearIndex + 1) % getCapacity();
		getContents()[this.rearIndex] = new Element(this.rearIndex, value);
		incrementSize();

	}

	public Element dequeue(){
		// The dequeue() operation removes the item at the front of the queue
		// This should also return the 'Element' that was removed

		// if(isEmpty()){
		// 	System.out.println("Array is empty. Nothing to remove.");
		// 	return null;
		// }

		Element frontEl = getContents()[this.frontIndex];
		getContents()[this.frontIndex] = null;
		this.frontIndex = (this.frontIndex + 1) % getCapacity();

		if(frontEl != null){
			decrementSize();
		}

		// Reset indices if the queue is now empty
        // if (isEmpty()) {
        //     this.frontIndex = 0;
        //     this.rearIndex = -1;
        // }

		return frontEl;
	}

	public void wrapAround(){
		// The wrapAround() operation resets the Array back where the front element is at index 0
		// NOTE: You will only use this function when capacity is full and you wish to enqueue()

		Element[] contents2 = new Element[getCapacity()]; //only correct arrangement
		Element[] contents = getContents();	//original array

		for(int i=0; i<getSize(); i++){
			contents2[i] = contents[this.frontIndex];
			this.frontIndex = (this.frontIndex+1) % getSize();
		}


		this.rearIndex = getSize()-1;
		this.frontIndex = 0;

		for(int i=0; i<getSize(); i++){
			getContents()[i] = contents2[i];
		}
	}
}
