public class SLLQueue extends SLL{
	// Note that class "SLLQueue" inherits the class "SLL" attributes and methods
	// Insert Attributes (if any) - must be private


	public SLLQueue(){
		// Constructor: create necessary parameters
		super();
	}

	public SLLNode front(){
		// The front() operation returns a reference value to the front node of the queue, but doesn’t remove it
		// SLLNode head = getHead()
		return getHead();
	}

	public void enqueue(String value){
		// The enqueue() operation inserts a node at the back of the queue
		SLLNode newNode = new SLLNode(value);
		SLLNode qTail = getTail();
		SLLNode qHead = getHead();

		if(isEmpty()){
			setHead(newNode);
            setTail(newNode);
		}else{
			// this.tail.setNext(newNode);          //code for adding the node at the tail if list is not empty
            // setTail(newNode);
            qTail.setNext(newNode);
            setTail(newNode);
		}
		incrementSize();
	}

	public SLLNode dequeue(){
		// The dequeue() operation removes the node at the front of the queue
		// This should also return the 'SLLNode' that was removed
		SLLNode qTail = getTail();
		SLLNode qHead = getHead();

		SLLNode rem = qHead;

		if(isEmpty()){
			return null;		//check if Empty
		}

		// if (rem == this.head) {
  //           this.head = rem.getNext();
  //           if (this.head == null) {
  //               this.tail = null;  // empty list after removal
  //           }
  //       }
		// qHead = qHead.getNext();
		setHead(qHead.getNext());
		if (qHead == null) {
			qTail = null;  // empty list after removal
		}
		rem.setNext(null);
		decrementSize();
		return rem;
	}















}
