// LABORATORY EXERCISE NO. 7 TESTER
// Created by: Jayvee B. Castañeda

// !!! W A R N I N G !!!
// DO NOT EDIT THE CONTENTS OF THIS FILE UNLESS PROMPTED TO DO SO
// ANY UNSOLICITED MODIFICATIONS TO THIS FILE WILL RESULT TO A SCORE OF '0' IN THIS EXERCISE

import java.util.*;

public class Lab7Tester {
    private static final int TOTAL = 50;
    private static double score = 0;

    public static String randomString(){
        Random rng = new Random();
        int length = 25;
        String allChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvwxyz" + "0123456789" + "!@#$%^&*+-/=?,.";
        char[] text = new char[length];
        for (int i = 0; i < length; i++){
            text[i] = allChars.charAt(rng.nextInt(allChars.length()));
        }
        return new String(text);
    }

    // Array Dictionary Test Method
    public static void ArrayDictionaryTest() {
        ArrayDictionary testAD = new ArrayDictionary(20);
        score = 0;

        // Initial Test for 'size'
        try {
            if (testAD.isEmpty()) {
                score += 2;
            }
        } catch (Exception e) {
            System.out.println("Error: Problem initializing Array Dictionary");
        }

        Map<Integer, Object> testDict = new HashMap<>();
        testDict.put(10, "wholly");
        testDict.put(1, new String[]{"eye", "wand", "four"});
        testDict.put(11, new String[]{"nice", "happee"});
        testDict.put(13, "knew");
        testDict.put(0, "all");
        testDict.put(15, "!!!");
        testDict.put(4, new String[]{"kurisumasu", "ease"});
        testDict.put(7, new String[]{"bay bee", "silent", "knight"});
        testDict.put(14, "here");
        testDict.put(6, "ewe");

        // Test for inserting values
        try {
            for (Map.Entry<Integer, Object> entry : testDict.entrySet()) {
                Integer testKey = entry.getKey();
                Object testValue = entry.getValue();
                if (testValue instanceof String[]) {
                    String[] valueList = (String[]) testValue;
                    for (Object value : valueList) {
                        testAD.insert(testKey, (String) value);
                        score += 1;
                    }
                } else {
                    testAD.insert(testKey, (String) testValue);
                    score += 1;
                }
            }

            // Size Test
            if (testAD.getSize() == 16) {
                score += 4;
            }
        } catch (Exception e) {
            System.out.println("Error: insert() and/or getSize() not working properly");
        }

        // Test for finding values
        try {
            for (Integer key : testDict.keySet()) {
                if (testDict.get(key) instanceof String[]){
                    if (((String[])(testDict.get(key)))[0].equals(testAD.find(key).getValue())) {
                        score += 1;
                    }
                } else {
                    if (testDict.get(key).equals(testAD.find(key).getValue())) {
                        score += 1;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Error: insert() and/or find() not working properly");
        }

        // Print Array Dictionary
        System.out.println("=== < Array Dictionary > ===");
        StringBuilder string = new StringBuilder();
        for (int i = 0; i < testAD.getSize(); i++) {
            string.append(" (").append(testAD.getEntryContents()[i].getKey()).append(" : ").append(testAD.getEntryContents()[i].getValue()).append(") ");
        }
        System.out.println(string);
        System.out.println("=== <$$$> ===\n");

        // Testing for Iterators
        System.out.println("=== ALL ENTRIES ===\n");
        testAD.entries();
        System.out.println("=== <$$$> ===\n");

        System.out.println("=== FIND_ALL(0) ===\n");
        testAD.find_all(0);
        System.out.println("=== FIND_ALL(1) ===\n");
        testAD.find_all(1);
        System.out.println("=== FIND_ALL(2) ===\n");
        testAD.find_all(2);
        System.out.println("=== FIND_ALL(4) ===\n");
        testAD.find_all(4);
        System.out.println("=== FIND_ALL(7) ===\n");
        testAD.find_all(7);
        System.out.println("=== FIND_ALL(8) ===\n");
        testAD.find_all(8);
        System.out.println("=== FIND_ALL(11) ===\n");
        testAD.find_all(11);
        System.out.println("=== FIND_ALL(15) ===\n");
        testAD.find_all(15);

        System.out.println("=== <$$$> ===\n");

        // Test for removing valuess
        try {
            for (Map.Entry<Integer, Object> entry : testDict.entrySet()) {
                Object value = entry.getValue();
                if (value instanceof String[]) {
                    String[] valueList = (String[]) value;
                    for (String testvalue : valueList) {
                        String removed = testAD.remove(testvalue).getValue();
                        System.out.println("Removed " + removed);
                        score += 1;
                    }
                    
                
                } else {
                    String removed = testAD.remove((String) value).getValue();
                    System.out.println("Removed " + removed);
                    score += 1;
                }
            }
            // Check if the dictionary is empty
            if (testAD.isEmpty()) {
                score += 2;

            }
        } catch (Exception e) {
            System.out.println(e + "Error: find() or remove() not working properly");
        }

        // Testing for Iterators after removal
        System.out.println("=== ALL ENTRIES ===\n");
        testAD.entries();
        System.out.println("=== <$$$> ===\n");

        System.out.println("Your TOTAL SCORE is " + score + "/" + TOTAL + ".");
        System.out.printf("Percentage: %.2f%%\n", (score / (double) TOTAL) * 100);
        if (score == TOTAL) {
            System.out.println("PERFECT SCORE!!!");
        } else {
            System.out.println("TRY AGAIN!!!");
        }
    }

    // DLL Map Test Method
    public static void DLLMapTest() {
        DLLMap testMap = new DLLMap();
        score = 0;

        // Initial Test for 'size'
        try {
            if (testMap.isEmpty()) {
                score += 1;
            }
        } catch (Exception e) {
            System.out.println("Error: Problem initializing DLL Map");
        }

        Map<Integer, String> testDict = new HashMap<>();
        testDict.put(10, "wholly");
        testDict.put(2, "wand");
        testDict.put(11, "nice");
        testDict.put(5, "ease");
        testDict.put(8, "silent");
        testDict.put(1, "eye");
        testDict.put(13, "knew");
        testDict.put(4, "kurisumasu");
        testDict.put(0, "all");
        testDict.put(15, "!!!");
        testDict.put(7, "bay bee");
        testDict.put(14, "here");
        testDict.put(3, "four");
        testDict.put(9, "knight");
        testDict.put(6, "ewe");
        testDict.put(12, "happee");

        // Test for 'put()'
        try {
            for (Map.Entry<Integer, String> entry : testDict.entrySet()) {
                testMap.put(entry.getKey(), entry.getValue());
                score += 1;
            }

            // Size Test
            if (testMap.getSize() == 16) {
                score += 2;
            }
        } catch (Exception e) {
            System.out.println("Error: put() not working properly");
        }

        // Test for get and finding values
        try {
            for (Map.Entry<Integer, String> entry : testDict.entrySet()) {
                if (testMap.get(entry.getKey()).getValue().equals(entry.getValue())) {
                    score += 1;
                }
            }
        } catch (Exception e) {
            System.out.println("Error: get() not working properly");
        }

        // Print DLL Map
        System.out.println("=== DLL Map ===");
        StringBuilder string = new StringBuilder();
        DLLEntryNode current = testMap.getEntryHead();
        while (current != null) {
            string.append(" (").append(current.getEntry().getKey()).append(" : ").append(current.getEntry().getValue()).append(") ");
            current = current.getNext();
        }
        System.out.println(string);
        System.out.println("=== <$$$> ===\n");

        // Testing for Iterators
        System.out.println("=== ALL KEYS ===\n");
        testMap.keys();
        System.out.println("=== ALL VALUES ===\n");
        testMap.values();
        System.out.println("=== ALL ENTRIES ===\n");
        testMap.entries();
        System.out.println("=== <$$$> ===\n");

        // Test for removing values
        try {
            while (testMap.getSize() > 4) {
                int minKey = Collections.min(testDict.keySet());
                if (minKey == testMap.find_node(minKey).getEntry().getKey()) {
                    score += 0.5;
                }
                int key2 = testMap.remove(minKey).getKey();
                if (minKey == key2) {
                    score += 0.5;
                }
                testDict.remove(minKey);
            }
        } catch (Exception e) {
            System.out.println("Error: findNode() or remove() not working properly");
        }

        // Testing for Iterators after removal
        System.out.println("=== ALL KEYS ===\n");
        testMap.keys();
        score += 1;
        System.out.println("=== ALL VALUES ===\n");
        testMap.values();
        score += 1;
        System.out.println("=== ALL ENTRIES ===\n");
        testMap.entries();
        score += 1;
        System.out.println("=== <$$$> ===\n");

        System.out.println("Your TOTAL SCORE is " + score + "/" + TOTAL + ".");
        System.out.printf("Percentage: %.2f%%\n", (score / (double) TOTAL) * 100);
        if (score == TOTAL) {
            System.out.println("PERFECT SCORE!!!");
        } else {
            System.out.println("TRY AGAIN!!!");
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("LABORATORY EXERCISE #7 TESTER\nOptions:\n1 - Array Dictionary\n2 - DLL Map\n* - Exit");
        int choice = scanner.nextInt();

        if (choice == 1) {
            ArrayDictionaryTest();
        } else if (choice == 2) {
            DLLMapTest();
        } else {
            System.exit(0);
        }
    }
}