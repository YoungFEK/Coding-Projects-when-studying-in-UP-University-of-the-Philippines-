public class SLLStack extends SLL{



	public SLLStack(){
		// constructor
		super();
	}

	public SLLNode top(){
		// The top() operation returns a reference value to the top node of the stack, but doesn’t remove it
		if (isEmpty()) {
            return null;  // list is empty
        }

		// SLLNode topNode = getTail();
		// return topNode;

		return getTail();
	}

	public void push(String value){
		// The push() operation inserts a node at the top of the stack
		addNode(value);
	}

	public SLLNode pop(){
		// The pop() operation removes the node at the top of the stack
		// This should also return the 'SLLNode' that was removed
		if (isEmpty()) {
            return null;  // list is empty
        }

		SLLNode topVal = getTail();
		removeNode(topVal.getValue());
		return topVal;
		//------------------

		// SLLNode topVal = getTail();
		// String topVal2 = topVal.getValue();
  //
		// SLLNode rem = getHead();
  //       SLLNode prev = null;
  //
  //       while (rem != null && !rem.getValue().equals(topVal2)) {  // correct access to value
  //           prev = rem;
  //           rem = rem.getNext();
  //       }
  //
  //       setTail(prev);
  //       prev.setNext(null);
  //
  //       rem.setNext(null);
  //       decrementSize();
  //       return rem;

		// SLLNode topVal = getTail();  // Get the current tail (top of the stack)
  //
		// if (getHead() == getTail()) {
		// 	// Case 1: Only one node in the list
		// 	setHead(null);
		// 	setTail(null);
		// } else {
		// 	// Case 2: More than one node
		// 	SLLNode current = getHead();
		// 	while (current.getNext() != getTail()) {
  //           current = current.getNext();  // Traverse to the second-to-last node
		// 	}
		// 	setTail(current);  // Update the tail to be the second-to-last node
		// 	current.setNext(null);  // Remove the old tail
		// }
  //
		// decrementSize();  // Decrease the size
		// return topVal;    // Return the removed node
	}
}
