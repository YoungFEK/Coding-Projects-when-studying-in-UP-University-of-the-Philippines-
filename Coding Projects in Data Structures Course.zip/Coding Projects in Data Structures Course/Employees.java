import java.util.ArrayList;
import java.util.List;

class Employee {
    private String fName;
    private String lName;
    private String addr;
    private int years;
    private String desc;
    private List<String> joblist;

    // Constructor with default values
    public Employee(String fName, String lName, String addr, int years, String desc, List<String> joblist) {
        this.fName = fName != null ? fName : "Juan";
        this.lName = lName != null ? lName : "Dela Cruz";
        this.addr = addr != null ? addr : "Iloilo City";
        this.years = years > 0 ? years : 1;
        this.desc = desc != null ? desc : "N/A";
        this.joblist = joblist != null ? joblist : new ArrayList<>();
    }

    // Method to get full name
    public String getFullName() {
        if (addr.contains("South Korea") || addr.contains("China")) {
            return lName + " " + fName;
        } else if (fName != null && lName != null) {
            return fName + " " + lName;
        } else {
            throw new RuntimeException("No First or Last Name");
        }
    }

    // Method to get first name
    public String getFName() {
        if (fName != null) {
            return fName;
        } else {
            throw new RuntimeException("No First Name");
        }
    }

    // Method to get last name
    public String getLName() {
        if (lName != null) {
            return lName;
        } else {
            throw new RuntimeException("No Last Name");
        }
    }

    // Method to get address
    public String getAddress() {
        if (addr != null) {
            return addr;
        } else {
            throw new RuntimeException("No Known Address");
        }
    }

    // Method to get years in industry
    public String getYears() {
        if (years > 0) {
            return String.valueOf(years);
        } else {
            throw new RuntimeException("No Known Number Of Years in Industry");
        }
    }

    // Method to get description
    public String getDesc() {
        if (desc != null) {
            return desc;
        } else {
            throw new RuntimeException("No Description Available");
        }
    }

    // Method to get jobs
    public String getJobs() {
        if (joblist != null && !joblist.isEmpty()) {
            StringBuilder jobs = new StringBuilder();
            int count = 1;
            for (String job : joblist) {
                jobs.append("\nJob ").append(count).append(": ").append(job);
                count++;
            }
            return jobs.toString();
        } else {
            throw new RuntimeException("No Jobs Assigned");
        }
    }
}

public class Employees {
    public List<Employee> employeeList = new ArrayList<>();
    public int size = 100;

    public static void displayEmployees(List<Employee> employeeList) {
        int count = 0;
        for (Employee employee : employeeList) {
            count++;
            System.out.println("\n===========| Employee No. " + count + " |===========");
            System.out.println("Name: " + employee.getFullName());
            System.out.println("Address: " + employee.getAddress());
            System.out.println("Years In Industry: " + employee.getYears());
            System.out.println("Description: " + employee.getDesc());
            System.out.println("\n--------| List Of Assigned Jobs |--------" + employee.getJobs());
            System.out.println("==========================================");
        }
    }

    public List<Employee> getEmployees(){
        return this.employeeList;
    }

    public int getSize(){
        return this.size;
    }

    public static void main(String[] args) {
        // Example employees
        employeeList.add(new Employee("Taylor Alison", "Swift", "Pennsylvania, USA", 18, "Thirteen Starbucks Lovers", List.of("Singer", "Songwriter", "Actor", "Producer")));
        employeeList.add(new Employee("Ariana", "Grande-Butera", "Florida, USA", 12, "High Pitched and High-Heeled", List.of("Singer", "Belter", "Songwriter", "Actor", "Dancer")));
        employeeList.add(new Employee("Adele Laurie", "Adkins", "London, UK", 10, "Hello, is it me you're looking for?", List.of("Singer", "Belter", "Songwriter", "Producer")));
        employeeList.add(new Employee("Dua", "Lipa", "London, UK", 4, "One-and-Only Dula Peep", List.of("Singer","Songwriter","Dancer")));
        employeeList.add(new Employee("Katherine Elizabeth", "Hudson", "California, USA", 7, "You and IIIIIIIIIII ayayayay!!!", List.of("Singer","Belter","Songwriter","Dancer","Producer")));
        employeeList.add(new Employee("Stefani Joanne Angelina", "Germanotta", "New York, USA", 15, "Meat Dress Aesthetics", List.of("Singer","Belter","Songwriter","Actor","Dancer")));
        employeeList.add(new Employee("Belcalis", "Almanzar", "New York, USA", 1, "Eeaaawwww!!!", List.of("Rapper","Dancer")));
        employeeList.add(new Employee("Robyn Rihanna", "Fenty", "Saint Michael, Barbados", 9, "Thou shall not date Chris Brown", List.of("Singer","Belter","Songwriter","Actor","Dancer")));
        employeeList.add(new Employee("Megan Jovon Ruth", "Pete", "Texas, USA", 8, "Stallion >>> Red Horse", List.of("Rapper","Songwriter","Dancer")));
        employeeList.add(new Employee("Meghan Elizabeth", "Trainor", "Massachusetts, USA", 12, "Shoobeedoobap Doobeedapdap", List.of("Singer","Belter","Songwriter","Dancer")));
        employeeList.add(new Employee("Selena Marie", "Gomez", "Texas, USA", 12, "Are you re-e-ea-dy?", List.of("Singer","Songwriter","Dancer","Actor")));
        employeeList.add(new Employee("Miley Ray", "Cyrus", "Tennessee, USA", 14, "Hannah Montana Lookalike", List.of("Singer","Songwriter","Belter","Dancer","Actor")));
        employeeList.add(new Employee("Karla Camila", "Cabello-Estrabao", "Cojimar, Cuba", 15, "Bam bam bam bam bam bam", List.of("Singer","Dancer","Belter","Producer","Actor","Band Member")));
        employeeList.add(new Employee("Ashley Nicolette", "Frangipane", "New Jersey, USA", 6, "Not so eazy", List.of("Singer","Belter","Songwriter")));
        employeeList.add(new Employee("Anne-Marie Rose", "Nicholson", "East Tilbury, UK", 6, "Born before 2002", List.of("Singer","Belter")));
        employeeList.add(new Employee("Sia Kate Isobelle", "Furler", "Adelaide, Australia", 8, "Chandelier swinger", List.of("Singer","Belter","Songwriter")));
        employeeList.add(new Employee("Victoria Loren", "Kelly", "California, USA", 10, "Underrated AF", List.of("Singer","Belter","Songwriter")));
        employeeList.add(new Employee("Onika Tanya", "Maraj", "Saint James, Trinidad and Tobago", 20, "Barbie without the Queue", List.of("Singer","Rapper","Songwriter")));
        employeeList.add(new Employee("Demetria Devonne", "Lovato", "New Mexico, USA", 17, "Sorry not sorry for your loss", List.of("Singer","Belter","Songwriter","Actor")));
        employeeList.add(new Employee("Rita Sahatciu", "Ora", "Pristina, Kosovo", 17, "That's how do you do?", List.of("Singer","Dancer")));
        employeeList.add(new Employee("Cheryl Ann", "Tweedy", "Newcastle upon Tyne, UK", 19, "Tweedy Birdie", List.of("Singer","Dancer")));
        employeeList.add(new Employee("Jessica", "Cornish", "London, UK", 11, "Putting price tags on expensive items", List.of("Singer","Belter","Songwriter","Dancer","Producer")));
        employeeList.add(new Employee("Alecia Beth", "Moore-Hart", "Pennsylvania, USA", 11, "Let's start the parttyyy", List.of("Singer","Songwriter")));
        employeeList.add(new Employee("Kesha Rose", "Sebert", "California, USA", 16, "#REBORN", List.of("Singer","Belter","Songwriter","Dancer")));
        employeeList.add(new Employee("Amala Ratna Zandile", "Dlamini", "California, USA", 2, "Snoop Dogg's Evil Counterpart", List.of("Singer","Rapper","Songwriter")));
        employeeList.add(new Employee("Billie Eilish", "Baird O'Connell", "California, USA", 8, "happier forever", List.of("Singer","Songwriter")));
        employeeList.add(new Employee("Amethyst Amelia", "Kelly", "Sydney, Australia", 1, "Extravaganza", List.of("Rapper","Songwriter")));
        employeeList.add(new Employee("Elizabeth", "Grant", "New York, USA", 3, "Mellow than yellow", List.of("Singer","Songwriter")));
        employeeList.add(new Employee("Ella Marija Lani", "Yelich-O'Connor", "Auckland, New Zealand", 5, "Lorde and saviour", List.of("Singer","Songwriter","Producer")));
        employeeList.add(new Employee("Sabrina Annlynn", "Carpenter", "Pennsylvania, USA", 6, "You want me? No duh!", List.of("Singer","Songwriter","Dancer","Actor")));
        employeeList.add(new Employee("Elena Jane", "Goulding", "Hereford, UK", 11, "Raspy is everything!", List.of("Singer","Songwriter","Dancer")));
        employeeList.add(new Employee("Beyonce Giselle", "Knowles-Carter", "Texas, USA", 22, "Uh oh uh oh uh oh oh no no", List.of("Singer","Belter","Songwriter","Dancer","Producer","Band Member")));
        employeeList.add(new Employee("Christina Maria", "Aguilera", "New York, USA", 30, "Traps genies in bottles", List.of("Singer","Belter","Dancer")));
        employeeList.add(new Employee("Britney Jean", "Spears", "Mississippi, USA", 32, "Dancing Until The World End", List.of("Singer","Dancer")));
        employeeList.add(new Employee("Jennifer Lynn", "Lopez-Affleck", "New York, USA", 29, "Dancing Again And Again", List.of("Singer","Dancer","Actor")));
        employeeList.add(new Employee("Mariah", "Carey", "New York, USA", 25, "Queen Of Christmas", List.of("Singer","Belter")));
        employeeList.add(new Employee("Jessica Louise", "Nelson", "Romford, UK", 9, "Little Mix Member", List.of("Singer","Rapper","Songwriter","Dancer","Band Member")));
        employeeList.add(new Employee("Perrie Louise", "Edwards", "South Shields, UK", 9, "Little Mix Member", List.of("Singer","Belter","Dancer","Band Member")));
        employeeList.add(new Employee("Leigh-Anne", "Pinnock", "High Wycombe, UK", 9, "Little Mix Member", List.of("Singer","Belter","Dancer","Band Member")));
        employeeList.add(new Employee("Jade Amelia", "Thirlwall", "South Shields, UK", 9, "Little Mix Member", List.of("Singer","Belter","Songwriter","Band Member")));
        employeeList.add(new Employee("Cher", "Lloyd", "Malvern, UK", 4, "X Factor winner winner chicken zayner", List.of("Singer","Songwriter")));
        employeeList.add(new Employee("Bridgit Claire", "Mendler", "Washington, USA", 1, "Lemonade Disney", List.of("Singer","Songwriter")));
        employeeList.add(new Employee("Olivia Isabel", "Rodrigo", "California, USA", 3, "failed the driver's test", List.of("Singer","Belter","Songwriter","Producer")));
        employeeList.add(new Employee("Phoebe Lucille", "Bridgers", "California, USA", 5, "Bo Burnham's wife", List.of("Singer","Belter","Songwriter")));
        employeeList.add(new Employee("Nicole", "Zefanya", "Jakarta, Indonesia", 7, "A little spunk, a little gumption", List.of("Singer","Songwriter")));
        employeeList.add(new Employee("John Roger", "Stephens", "Ohio, USA", 10, "The Legend of Weddings", List.of("Singer","Belter","Songwriter")));
        employeeList.add(new Employee("Edward Christopher", "Sheeran", "Halifax, UK", 13, "Ginger Rapper", List.of("Singer","Rapper","Belter","Songwriter")));
        employeeList.add(new Employee("Shawn Peter Raul", "Mendes", "Pickering, Canada", 8, "Bieber Wannabe", List.of("Singer","Belter","Songwriter")));
        employeeList.add(new Employee("Charlie Otto", "Puth", "New Jersey, USA", 8, "Won't see you again", List.of("Singer","Belter","Rapper","Songwriter","Producer")));
        employeeList.add(new Employee("Justin Drew", "Bieber", "London, Canada", 16, "Mendes Wannabe", List.of("Singer","Songwriter","Producer")));
        employeeList.add(new Employee("Adam Richard", "Wiles", "Dumfries, UK", 6, "Swift's Less Famous Ex", List.of("Songwriter","Producer")));
        employeeList.add(new Employee("Peter Gene", "Hernandez", "Hawaii, USA", 14, "If you ever leave me baby...", List.of("Singer","Belter","Songwriter","Producer")));
        employeeList.add(new Employee("Pierre David", "Guetta", "Paris, France", 20, "Tugs tugs tugs", List.of("Songwriter","Producer")));
        employeeList.add(new Employee("Tim", "Bergling", "Stockholm, Sweden", 8, "Rest In Peace", List.of("Songwriter","Producer")));
        employeeList.add(new Employee("Jason Joel", "Desrouleaux", "Florida, USA", 11, "JSon Format Deroooohlooooo", List.of("Singer","Belter","Songwriter","Producer")));
        employeeList.add(new Employee("Usher Terry", "Raymond", "Texas, USA", 11, "My last name is Raymond", List.of("Singer","Belter")));
        employeeList.add(new Employee("William James", "Adams", "California, USA", 23, "Black Eyed Peas Member", List.of("Songwriter","Rapper","Producer")));
        employeeList.add(new Employee("Shawn Corey", "Carter", "New York, USA", 24, "Jay-Z", List.of("Rapper","Songwriter","Producer")));
        employeeList.add(new Employee("Marshall Bruce", "Mathers", "Missouri, USA", 29, "Better than the chocolate candy", List.of("Rapper","Songwriter","Producer")));
        employeeList.add(new Employee("Tramar", "Dillard", "Florida, USA", 17, "Here we go!", List.of("Rapper","Producer")));
        employeeList.add(new Employee("Benjamin", "Haggerty", "Washington, USA", 3, "Buying cheap clothes", List.of("Rapper","Producer")));
        employeeList.add(new Employee("Michael Ray", "Nguyen-Stevenson", "California, USA", 14, "Thank You God Always", List.of("Rapper","Songwriter","Producer")));
        employeeList.add(new Employee("Timothy", "McKenzie", "London, England", 6, "The Maze Runner", List.of("Singer","Rapper")));
        employeeList.add(new Employee("Shaffer Chimere", "Smith", "Arkansas, USA", 18, "Yo yo yo", List.of("Singer","Belter","Producer","Actor")));
        employeeList.add(new Employee("Troye Sivan", "Mellet", "Johannesburg, South Africa", 7, "Timothee Chalamet Lookalike", List.of("Singer","Songwriter","Actor")));
        employeeList.add(new Employee("Aubrey Drake", "Graham", "Toronto, Canada", 9, "I am God's Plan", List.of("Rapper","Songwriter")));
        employeeList.add(new Employee("Oliver Stanley", "Murs", "Witham, UK", 4, "Nowhere to go but UP", List.of("Singer","Belter","Songwriter")));
        employeeList.add(new Employee("Samuel Frederick", "Smith", "London, UK", 7, "Mummie don't know daddy's getting HOT", List.of("Singer","Belter","Songwriter","Producer")));
        employeeList.add(new Employee("Faheem Rasheed", "Najm", "Florida, USA", 16, "T-PAIN", List.of("Singer","Belter","Songwriter","Producer")));
        employeeList.add(new Employee("Calvin Cordozar", "Broadus", "California, USA", 19, "Doja Cat's Male Counterpart", List.of("Rapper","Producer")));
        employeeList.add(new Employee("Harry Edward", "Styles", "Redditch, UK", 12, "That One Direction Member Who Dresses Differently", List.of("Singer","Belter","Songwriter","Band Member")));
        employeeList.add(new Employee("Zain Javadd", "Malik", "Bradford, UK", 12, "That One Direction Member Who Left Earlier Than Everyone Else", List.of("Singer","Belter","Songwriter","Band Member")));
        employeeList.add(new Employee("Niall James", "Horan", "Mullingar, Ireland", 12, "That One Direction Member Who Writes Better Songs", List.of("Singer","Songwriter","Band Member")));
        employeeList.add(new Employee("Louis William", "Tomlinson", "Doncaster, UK", 12, "That One Direction Member Who Went EDM", List.of("Singer","Songwriter","Band Member")));
        employeeList.add(new Employee("Liam James", "Payne", "Wolverhampton, UK", 12, "That One Direction Member R.I.P.", List.of("Singer","Songwriter","Band Member")));
        employeeList.add(new Employee("Jung-kook", "Jeon", "Busan, South Korea", 10, "Behind The Scenes Member", List.of("Singer","Belter","Dancer","Band Member")));
        employeeList.add(new Employee("Tae-hyung", "Kim", "Daegu, South Korea", 10, "Behind The Scenes Member", List.of("Singer","Dancer","Band Member")));
        employeeList.add(new Employee("Ji-min", "Park", "Busan, South Korea", 10, "Behind The Scenes Member", List.of("Singer","Dancer","Band Member")));
        employeeList.add(new Employee("Yoon-gi", "Min", "Daegu, South Korea", 10, "Behind The Scenes Member", List.of("Rapper","Dancer","Band Member")));
        employeeList.add(new Employee("Seok-jin", "Kim", "Anyang-si, South Korea", 10, "Behind The Scenes Member", List.of("Singer","Dancer","Band Member")));
        employeeList.add(new Employee("Nam-joon", "Kim", "Seoul, South Korea", 10, "Behind The Scenes Member", List.of("Rapper","Dancer","Band Member")));
        employeeList.add(new Employee("Ho-seok", "Jung", "Gwangju, South Korea", 10, "Behind The Scenes Member", List.of("Rapper","Dancer","Band Member")));
        employeeList.add(new Employee("Sunwoo", "Kim", "South Korea", 8, "The Boyz Member", List.of("Singer","Songwriter","Rapper","Dancer","Band Member")));
        employeeList.add(new Employee("Juyeon", "Lee", "Gwangju-si, South Korea", 8, "The Boyz Member", List.of("Dancer","Singer","Rapper","Band Member")));
        employeeList.add(new Employee("Jaehyun", "Lee", "Incheon, South Korea", 8, "The Boyz Member", List.of("Singer","Dancer","Band Member")));
        employeeList.add(new Employee("Younghoon", "Kim", "Seoul, South Korea", 8, "The Boyz Member", List.of("Singer","Dancer","Band Member")));
        employeeList.add(new Employee("Sangyeon", "Lee", "Seoul, South Korea", 8, "The Boyz Member", List.of("Singer","Belter","Band Member")));
        employeeList.add(new Employee("Hak-Nyeon", "Ju", "Seogwipo-si, South Korea", 8, "The Boyz Member", List.of("Singer","Dancer","Band Member")));
        employeeList.add(new Employee("Young Jae (Eric)", "Son", "Seoul, South Korea", 8, "The Boyz Member", List.of("Rapper","Dancer","Band Member")));
        employeeList.add(new Employee("Chang Min", "Ji", "Cheongju-si, South Korea", 8, "The Boyz Member", List.of("Singer","Dancer","Band Member")));
        employeeList.add(new Employee("Chan-hee", "Choi", "Jeonju-si, South Korea", 8, "The Boyz Member", List.of("Singer","Belter","Band Member")));
        employeeList.add(new Employee("Hyung-seo (Kevin)", "Moon", "Gwangju, South Korea", 8, "The Boyz Member", List.of("Singer","Dancer","Band Member")));
        employeeList.add(new Employee("Joon Young (Jacob)", "Bae", "Toronto, Canada", 8, "The Boyz Member", List.of("Singer","Belter","Dancer","Band Member")));
        employeeList.add(new Employee("Jae-min", "Na", "Jeonju-si, South Korea", 7, "NCT Dream Member", List.of("Singer","Rapper","Dancer","Band Member")));
        employeeList.add(new Employee("Je-no", "Lee", "Incheon, South Korea", 7, "NCT Dream Member", List.of("Singer","Rapper","Dancer","Band Member")));
        employeeList.add(new Employee("Ren Jun", "Huang", "Jilin City, China", 7, "NCT Dream Member", List.of("Singer","Belter","Dancer","Band Member")));
        employeeList.add(new Employee("Chenle", "Zhong", "Shanghai, China", 7, "NCT Dream Member", List.of("Singer","Belter","Dancer","Band Member")));
        employeeList.add(new Employee("Dong-hyuck", "Lee", "Seoul, South Korea", 7, "NCT Dream Member", List.of("Singer","Belter","Dancer","Band Member")));
        employeeList.add(new Employee("Mark", "Lee", "Toronto, Canada", 7, "NCT Dream Member", List.of("Singer","Rapper","Dancer","Band Member")));
        employeeList.add(new Employee("Ji-sung", "Park", "Seoul, South Korea", 7, "NCT Dream Member", List.of("Singer","Dancer","Band Member")));

        // Call the display method
        displayEmployees(employeeList);
    }
}
