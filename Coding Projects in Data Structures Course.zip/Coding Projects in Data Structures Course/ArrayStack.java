public class ArrayStack extends Array{


	public ArrayStack (int capacity){
		// constructor
		super(capacity);
	}

	public Element top(){
		// The top() operation returns a reference value to the top element of the stack, but doesn’t remove it
		if(isEmpty()){
			System.out.println("Array is empty. Nothing to return.");
			return null;
		}

		Element[] contents = getContents();
		return contents[getSize()-1];
	}

	public void push(String value){
		// You are not allowed to push() an item to the stack when full
		// If the capacity is full, prompt the expand() method before pushing.
		if(getSize() == getCapacity()){
			System.out.println("Prompt: stack is full, expanding stack...");
			expand();
		}
		// The push() operation inserts an item at the top of the stack
		addElement(value);
	}

	public Element pop(){
		// The pop() operation removes the item at the top of the stack
		// This should also return the 'Element' that was removed

		if(isEmpty()){
			System.out.println("Array is empty. Nothing to remove.");
			return null;
		}

		decrementSize();
		int indexEl = getSize();
		Element[] contents = getContents();
		Element removedValue = contents[indexEl];
		contents[indexEl] = null;
		return removedValue;
	}
}















