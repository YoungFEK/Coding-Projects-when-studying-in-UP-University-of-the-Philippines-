public class SLLStack extends SLL{
	SLLNode topNode;	//still needed?

	public SLLStack(){
		// constructor
		super();
	}

	public SLLNode top(){
		// The top() operation returns a reference value to the top node of the stack, but doesn’t remove it
		if (isEmpty()) {
            return null;  // list is empty
        }

        this.topNode = getHead();
		return this.topNode;
	}

	public void push(String value){
		// The push() operation inserts a node at the top of the stack
		addNode(value);
		this.topNode = getHead();
	}

	public SLLNode pop(){
		// The pop() operation removes the node at the top of the stack
		// This should also return the 'SLLNode' that was removed
		if (isEmpty()) {
            return null;  // list is empty
        }

		SLLNode topVal = removeNode(getHead().getValue());
		this.topNode = getHead();
		return topVal;
	}
}
