public class DLLDeque extends DLL{
	// Note that class "DLLQueue" inherits the class "DLL" attributes and methods
	// insert attributes (if any)
	public DLLDeque(){
		// insert constructor
		super();
	}

	public DLLNode first(){
		// The first() operation returns a reference value to the first element of the deque, but doesn’t remove it
		return getHead();
	}

	public DLLNode last(){
		// The last() operation returns a reference value to the last element of the deque, but doesn’t remove it
		return getTail();
	}

	public void insertFirst(String value){
		// The insertFirst() operation inserts an element at the front of the deque
		DLLNode newNode = new DLLNode(value);

		if(isEmpty()){
			setHead(newNode);
            setTail(newNode);
		}else{
            getHead().setPrev(newNode);
            newNode.setNext(getHead());
            setHead(newNode);
		}
		incrementSize();
	}	

	public void insertLast(String value){
		// The insertLast() operation inserts an element at the end of the deque
		DLLNode newNode = new DLLNode(value);

		if(isEmpty()){
			setHead(newNode);
            setTail(newNode);
		}else{
            getTail().setNext(newNode);
            newNode.setPrev(getTail());
            setTail(newNode);
		}
		incrementSize();
	}

	public DLLNode removeFirst(){
		// The removeFirst() operation removes the element at the front of the deque
		// This should also return the 'DLLNode' that was removed
		// if (isEmpty()) {
		// 	return null; // or throw an exception if you prefer
		// }

		DLLNode rem = getHead();

		setHead(getHead().getNext());
		if(getHead() == null){
			setTail(null);
		} else {
			getHead().setPrev(null);
		}

		rem.setNext(null);
		if(rem != null){
			decrementSize();
		}

		return rem;
	}

	public DLLNode removeLast(){
		// The removeLast() operation removes the element at the end of the deque
		// This should also return the 'DLLNode' that was removed
		// if (isEmpty()) {
		// 	return null; // or throw an exception if you prefer
		// }

		DLLNode rem = getTail();

		setTail(getTail().getPrev());

		if(getTail() == null){
			setHead(null);
		} else {
			getTail().setNext(null);
		}

		rem.setPrev(null);
		if(rem != null){
			decrementSize();
		}
		return rem;
	}
}
