public class DLL {
    // Attributes
    private int size;
    private DLLNode head;
    private DLLNode tail;

    public DLL() {
        this.size = 0;
        this.head = null;
        this.tail = null;
    }


    // Getters
    public int getSize() {
        return this.size;
    }

    public boolean isEmpty() {
        return this.size == 0;
    }

    //optional getters
    public DLLNode getHead() {
        return this.head;
    }

    public DLLNode getTail() {
        return this.tail;
    }


    // Set head method
    public void setHead(DLLNode node) {
        this.head = node;
    }

    // Set tail method
    public void setTail(DLLNode node) {
        this.tail = node;
    }


    //incrementSize() and decrementSize() methods for "DLL" class
    public void incrementSize(){
        this.size +=1;
    }

    public void decrementSize(){
        this.size -=1;
    }
}
