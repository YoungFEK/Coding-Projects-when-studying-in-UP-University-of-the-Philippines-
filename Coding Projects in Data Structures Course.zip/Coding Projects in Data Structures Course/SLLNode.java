public class SLLNode {
    // Attributes
    private String value;
    private SLLNode next;

    public SLLNode(String value) {
        this.value = value;
        this.next = null;   // correct initialization
    }

    // Getters and setters
    public void setValue(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }

    public void setNext(SLLNode node) {
        this.next = node;
    }

    public SLLNode getNext() {
        return this.next;
    }
}
