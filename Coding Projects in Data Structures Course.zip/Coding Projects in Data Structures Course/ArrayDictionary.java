public class ArrayDictionary extends Array{
	// Note: Class "ArrayDictionary" inherits the class "Array" attributes and methods
	// Note: Elements in the Array are Entries (use the 'Entry' class)

	//for lab 7
	private Entry[] contentEntry;
	private int capacityEntry;

	public ArrayDictionary(int capacity){
		super(capacity);
		this.contentEntry = new Entry[capacity];
		this.capacityEntry = capacity;
	}

	public Entry[] getEntryContents(){
		return this.contentEntry;
	}
	
	public void insert(int key, String value){
		// inserts an entry with the specified key and value in the dictionary such that entries with the same key are grouped together
		if(getSize() == this.capacityEntry){
			System.out.println("Prompt: stack is full, expanding stack...");
			expandEntries();
		}

		for(int i = getSize()-1; i>=0; i--){		//to check if there exists an index with the same key
			if(this.contentEntry[i].getKey() == key){
				for(int j = getSize(); j>i+1; j--){
					this.contentEntry[j] = this.contentEntry[j-1];
				}
				this.contentEntry[i+1] = new Entry(key, value);
				incrementSize();
				return;
			}
		}

		this.contentEntry[getSize()] = new Entry(key, value);
		incrementSize();
		return;
	}
/*
	public Entry remove(Entry entry){
		// removes the specified entry, and returns the entry that was removed; move elements forward/backward when necessary
		Entry removedEntry;

		for(int i = 0; i<getSize(); i++){
			if((this.contentEntry[i].getKey() == entry.getKey()) && (this.contentEntry[i].getValue().equals(entry.getValue()))){
				removedEntry = this.contentEntry[i];
				if(i != (getSize()-1)){
					for(int j = i; j<(getSize()-1); j++){
						this.contentEntry[j] = this.contentEntry[j+1];
					}
					this.contentEntry[getSize()-1]=null;
				}
				else{
					this.contentEntry[i]=null;
				}
				decrementSize();		//bring to top later
				return removedEntry;
			}
		}
		System.out.println("Entry cannot be found");
		return null;
	}
	*/

	//if there are keys with same value how would we be able to know which pair?
	public Entry remove(String value){
		// removes the specified entry, and returns the entry that was removed; move elements forward/backward when necessary
		Entry removedEntry;

		for(int i = 0; i<getSize(); i++){
			if(this.contentEntry[i].getValue().equals(value)){
				removedEntry = this.contentEntry[i];
				if(i != (getSize()-1)){
					for(int j = i; j<(getSize()-1); j++){
						this.contentEntry[j] = this.contentEntry[j+1];
					}
					this.contentEntry[getSize()-1]=null;
				}
				else{
					this.contentEntry[i]=null;
				}
				decrementSize();
				return removedEntry;
			}
		}
		System.out.println("Entry cannot be found");
		return null;
	}


	public Entry find(int key){
		// finds and returns the entry that matches the specified key (there could be multiple matches)
		for(int i = 0; i<getSize(); i++){
			if(this.contentEntry[i].getKey() == key){
				return this.contentEntry[i];
			}
		}

		return null;
	}

	// Iterator Methods
	public void find_all(int key){
		// iterates through the existing entries in the dictionary and prints all the entries (in the format "key:value") with the specified key in order
		for(int i = 0; i<getSize(); i++){
			if(this.contentEntry[i].getKey() == key){
				System.out.println(this.contentEntry[i].getKey() + ":" + this.contentEntry[i].getValue());
			}
		}
	}

	public void entries(){
		// iterates through the existing entries in the dictionary and prints all the entries (in the format "key:value") in order
		for(int i = 0; i<getSize(); i++){
			System.out.println(this.contentEntry[i].getKey() + ":" + this.contentEntry[i].getValue());
		}
	}



	//expand() for LAB 7
	public void expandEntries() {
		// The expand() method expands the array by increasing its capacity by 5;
		this.capacityEntry +=5;
		Entry[] contentEntry2 = new Entry[this.capacityEntry];
		for(int i=0; i<getSize(); i++){
			contentEntry2[i] = this.contentEntry[i];
		}
		this.contentEntry = contentEntry2;
	}
}


//code for if both key and value existing(for and 2 if loops)
