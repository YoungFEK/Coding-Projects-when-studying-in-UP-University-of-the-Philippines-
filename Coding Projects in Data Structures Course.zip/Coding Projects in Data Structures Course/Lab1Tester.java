// LABORATORY EXERCISE NO. 1 TESTER
// Created by: Jayvee B. Castañeda

// !!! W A R N I N G !!!
// DO NOT EDIT THE CONTENTS OF THIS FILE UNLESS PROMPTED TO DO SO
// ANY UNSOLICITED MODIFICATIONS TO THIS FILE WILL RESULT TO A SCORE OF '0' IN THIS EXERCISE

import java.util.Scanner;
import java.util.Random;

public class Lab1Tester{

	public static String randomString(){
		Random rng = new Random();
		int length = 10;
		String allChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvwxyz" + "0123456789" + "!@#$%^&*+-/=?,.";
	    char[] text = new char[length];
	    for (int i = 0; i < length; i++){
	        text[i] = allChars.charAt(rng.nextInt(allChars.length()));
	    }
	    return new String(text);
	}

	// Array Tester
	public static void ArrayTest() throws NullPointerException{
		int score = 0;
		int TOTAL = 50;
		Array testArray = new Array(20);
		
		if (testArray.isEmpty()){
			score+=2;
		}

		String[] randStrings = new String[10];
		for (int i=0; i<10; i++){
			randStrings[i] = randomString();
			testArray.addElement(randStrings[i]);
		}

		if (testArray.getSize() == 10){
			score+=2;
		}

		for (int i=0; i<testArray.getSize(); i++){
			if ((testArray.getContents()[i]).getValue() == randStrings[i]){
				score+=1;
			}
		}

		randStrings = new String[10];
		for (int i=0; i<10; i++){
			randStrings[i] = randomString();
			(testArray.getContents()[i]).setValue(randStrings[i]);
		}

		for (int i=0; i<testArray.getSize(); i++){
			if ((testArray.getContents()[i]).getValue() == randStrings[i]){
				score+=1;
			}
		}

		for (int i=0; i<testArray.getSize(); i++){
			if ((testArray.getContents()[i]).getIndex() == i){
				score+=1;
			}
		}

		for (int i=0; i<5; i++){
			int prevSize = testArray.getSize();
			String removed = testArray.removeElement(i);
			try {
				String nothing = (testArray.getContents()[i]).getValue();
			}catch(NullPointerException exception){
				score+=1;
			}
			if (testArray.getSize() == (prevSize - 1)){
				score+=1;
			}
			if (randStrings[i] == removed){
				score+=1;
			}
		}

		for (int i=5; i<10; i++){
			testArray.removeElement(i);
		}

		if (testArray.isEmpty()){
			score+=1;
		}

		System.out.println("Your TOTAL SCORE is " + score + "/" + TOTAL + ".");
		System.out.println("Percentage: " + (score*100/TOTAL) + "%");
		if (score == TOTAL){
			System.out.println("PERFECT SCORE!!!");
		}	
	}

	// SLL Tester
	public static void SLLTest() throws NullPointerException{
		float score = 0;
		int TOTAL = 50;
		SLL testSLL = new SLL();
		
		if (testSLL.isEmpty()){
			score+=2;
		}
		try {
			String head = testSLL.getHead().getValue();
			String tail = testSLL.getTail().getValue();
		} catch (NullPointerException exception){
			score+=4;
		}

		String[] randStrings1 = new String[10];
		for (int i=0; i<10; i++){
			randStrings1[i] = randomString();
			testSLL.addNode(randStrings1[i]);
		}

		if (testSLL.getSize() == 10){
			score+=3;
		}

		int i = 0;
		SLLNode current = testSLL.getHead();
		if (current.getValue() == randStrings1[i]){
			while (current != null){
				if (current.getValue() == randStrings1[i]){
					score+=1;
					current = current.getNext();
					i+=1;
				}
			}
		} else if (current.getValue() == randStrings1[9]){
			while (current != null){
				if (current.getValue() == randStrings1[10-i-1]){
					score+=1;
					current = current.getNext();
					i+=1;
				}
			}
		}
		
		i = 0;
		randStrings1 = new String[10];
		current = testSLL.getHead();

		while (current != null){
			randStrings1[i] = randomString();
			current.setValue(randStrings1[i]);
			current = current.getNext();
			i+=1;
		}

		i = 0;
		current = testSLL.getHead();
		while (current != null){
			if (current.getValue() == randStrings1[i]){
				score+=1;
				current = current.getNext();
				i+=1;
			}
		}

		for (i=0; i<5; i++){
			int prevSize = testSLL.getSize();
			SLLNode removed = testSLL.removeNode(randStrings1[i]);
			if (testSLL.getHead() != null){
				if (removed.getValue() == randStrings1[i]){
					score+=1;
				}
				if (removed.getNext() == null){
					score+=0.5;
				}
				if (testSLL.getHead().getValue() != randStrings1[i]){
					score+=1;
				}
				if (testSLL.getSize() == (prevSize - 1)){
					score+=0.5;
				}
			}
		}

		for (i=5; i<10; i++){
			testSLL.removeNode(randStrings1[i]);
		}

		if (testSLL.isEmpty()){
			score+=2;
		}

		try {
			String head = testSLL.getHead().getValue();
			String tail = testSLL.getTail().getValue();
		} catch (NullPointerException exception){
			score+=4;
		}

		System.out.println("Your TOTAL SCORE is " + score + "/" + TOTAL + ".");
		System.out.println("Percentage: " + (score*100/TOTAL) + "%");
		if (score == TOTAL){
			System.out.println("PERFECT SCORE!!!");
		}
	}


	// Main
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("LABORATORY EXERCISE #1 TESTER\nOptions:\n1 - Array\n2 - Singly Linked List\n* - Exit");
		System.out.print("Choice:");
		int choice = scanner.nextInt();

		if (choice == 1){
			ArrayTest();
		}
		else if (choice == 2){
			SLLTest();
		}
		else{
			System.exit(0);
		}
	}
}