public class Entry{
	// Entry() class attributes: key, value
	private int key;
	private BTNode value;

	public Entry(int key, BTNode value){
		this.key = key;
		this.value = value;
	}

	public void setKey(int key){
		this.key = key;
	}

	public int getKey(){
		return this.key;
	}

	public void setValue(BTNode value){
		this.value = value;
	}

	public BTNode getValue(){
		return this.value;
	}
}
