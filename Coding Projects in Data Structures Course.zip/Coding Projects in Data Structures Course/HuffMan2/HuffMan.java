import java.util.Scanner;

public class HuffMan{
    public static void main(String[] args){

        Scanner scanner = new Scanner(System.in);
        String userInput;

        do{
            SortedPQ charQueue = new SortedPQ();
            SortedPQ charQueue2 = new SortedPQ();
            LinkedBT treeBt = new LinkedBT();

            Entry entry1 = null;

            System.out.println("Please enter something, enter exit to stop program.");
            System.out.print("Enter Input: ");
            userInput = scanner.nextLine();

            //HuffMan encoding logic

            //adding letters to priority queue with frequency as key
            for(int i = 0; i< userInput.length(); i++){
                entry1 = null;
                if(HuffMan.findNode(userInput.charAt(i), charQueue) == null){
                    charQueue.insert(new Entry(1, new BTNode(userInput.charAt(i))));

                }else{
                    //needs to be reinserted for sorting
                    //remove node and add it for resorting
                    //public Entry removeNode(char c, SortedPQ charQueue){
                    entry1 = HuffMan.removeNode(userInput.charAt(i), charQueue);
                    entry1.setKey(entry1.getKey() + 1);
                    charQueue.insert(entry1);
                }
            }

            //testing
            // DLLEntryNode headNode = charQueue.getHead();
            // while(headNode != null){
            //     System.out.println(headNode.getEntry().getValue().getValue() + " : " + headNode.getEntry().getKey());
            //     headNode = headNode.getNext();
            // }



            while(charQueue.getSize() > 1){
                Entry attachedEntry1 =  charQueue.remove_min();
                Entry attachedEntry2 =  charQueue.remove_min();

                //charQueue2 will be used for displaying
                if(attachedEntry1.getValue().getValue() != '\u0000'){
                    charQueue2.insert(attachedEntry1);
                }

                if(attachedEntry2.getValue().getValue() != '\u0000'){
                    charQueue2.insert(attachedEntry2);
                }


                Entry sumEntry = new Entry(attachedEntry1.getKey() + attachedEntry2.getKey(),  new BTNode('\u0000'));

                sumEntry.getValue().setLeft(attachedEntry1.getValue());
                sumEntry.getValue().setRight(attachedEntry2.getValue());

                charQueue.insert(sumEntry);
            }

            treeBt.setRoot(charQueue.remove_min().getValue());

            //testing
            // String code1 = HuffMan.codeString('a', treeBt.getRoot());
            // System.out.println(code1);


            DLLEntryNode travelNode = charQueue2.getHead();
            Entry travelEntry;

            int numDigits;
            int characterBits;
            int frequencyBits;
            int totalBits=0;
            String genCode;

            //PRINTING TABLE
            System.out.printf("%-15s%-15s%-15s%-15s%n", "Character", "Frequency", "Code", "Size");

            while(travelNode != null){
                travelEntry = travelNode.getEntry();
                genCode = HuffMan.codeString(travelEntry.getValue().getValue(), treeBt.getRoot());
                numDigits = HuffMan.numCodeDigits(travelEntry.getValue().getValue(), treeBt.getRoot());
                totalBits += (8 + travelEntry.getKey() + (travelEntry.getKey() * numDigits));

                System.out.printf("%-15c%-15d%-15s%-15d%n", travelEntry.getValue().getValue(), travelEntry.getKey(), genCode, numDigits);
                travelNode = travelNode.getNext();
            }

            System.out.println("Total bits after: " + totalBits);
            System.out.println("Total bits before: " + (userInput.length() * 8));



        }while(!userInput.equalsIgnoreCase("exit"));
    }


    public static boolean makeCode(char c, BTNode rootNode, StringBuilder charCode) {
    // Base case for recursion
        if (rootNode == null) {
            return false;
        }

        // If the node's value matches the target character, we've found it
        if (rootNode.getValue() == c) {
            return true;
        }

        // Traverse left child
        if (rootNode.getLeft() != null) {
            charCode.append("0"); // Append 0 for left traversal
            if (makeCode(c, rootNode.getLeft(), charCode)) {
                return true;
            }
            charCode.deleteCharAt(charCode.length() - 1); // Backtrack
        }

        // Traverse right child
        if (rootNode.getRight() != null) {
            charCode.append("1"); // Append 1 for right traversal
            if (makeCode(c, rootNode.getRight(), charCode)) {
                return true;
            }
            charCode.deleteCharAt(charCode.length() - 1); // Backtrack
        }

        return false;
    }



    //returns code string
    public static String codeString(char c, BTNode rootNode){
        // String charCode = "";
        StringBuilder charCode = new StringBuilder();
        HuffMan.makeCode(c,rootNode,charCode);
        return charCode.toString();
    }

    //number of digits in code
    public static int numCodeDigits(char c, BTNode rootNode){
        String charCode = HuffMan.codeString(c, rootNode);
        int numDigits = 0;
        for(int i=0; i<charCode.length(); i++){
            numDigits += 1;
        }

        return numDigits;
    }


    public static DLLEntryNode findNode(char c, SortedPQ charQueue){
		DLLEntryNode targetNode = charQueue.getHead();

		while(targetNode!=null  && targetNode.getEntry().getValue().getValue() != c){
			targetNode = targetNode.getNext();
		}
		return targetNode; //null if empty or node does not exist
	}

	public static Entry removeNode(char c, SortedPQ charQueue){
        if(charQueue.getHead() == null){	//for checking if list is empty
			return null;
		}
		DLLEntryNode entryNode1 = HuffMan.findNode(c, charQueue);

		if(charQueue.getHead() == entryNode1){    //if head
			charQueue.setHead(entryNode1.getNext());

			if (charQueue.getHead() != null) {
				charQueue.getHead().setPrev(null);
			} else {
				charQueue.setTail(null); // If queue becomes empty
			}
		}else if (charQueue.getTail() == entryNode1){ //if tail
			charQueue.setTail(entryNode1.getPrev());
			charQueue.getTail().setNext(null);
		}else{
			entryNode1.getPrev().setNext(entryNode1.getNext());
			entryNode1.getNext().setPrev(entryNode1.getPrev());
		}
		charQueue.decrementSize();
		return entryNode1.getEntry();
    }
}










