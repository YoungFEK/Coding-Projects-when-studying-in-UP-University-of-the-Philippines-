public class SortedPQ extends DLL{
	// insert Sorted PQ attributes (if any)

	public SortedPQ(){
		super();
	}

	public void insert(Entry e){
		// make sure that the priority queue is always sorted when inserting an entry

		//create DLLNode
		DLLEntryNode node1 = new DLLEntryNode(e);
		DLLEntryNode nodeBefore = getHead();		//head node

		//case 1-node inserted is the first node
		if(getHead() == null){
			setHead(node1);
			setTail(node1);
		}else if(e.getKey() <= getHead().getEntry().getKey()){	//case 2-Font
			getHead().setPrev(node1);
			node1.setNext(getHead());
			setHead(node1);
		}else if(e.getKey() >= getTail().getEntry().getKey()){	//case 3-back
			getTail().setNext(node1);
			node1.setPrev(getTail());
			setTail(node1);
		}else {
			while(e.getKey() > nodeBefore.getEntry().getKey()){		//case 4-overwride key or place node in between
				nodeBefore = nodeBefore.getNext();
			}

			if(e.getKey() == nodeBefore.getEntry().getKey()){
				nodeBefore.getEntry().setValue(e.getValue());
			}else{
				node1.setPrev(nodeBefore.getPrev());
				node1.setNext(nodeBefore);
				nodeBefore.getPrev().setNext(node1);
				nodeBefore.setPrev(node1);
			}
		}

		incrementSize(); 	//add 1 to size
		return;
	}

	public Entry remove_min(){
		// removes the minimum entry of the priority queue, and returns the entry that was removed
		if(getHead() == null){	//for checking if null
			return null;
		}

		DLLEntryNode node1 = getHead();
		setHead(node1.getNext());


		if (getHead() != null) {
			getHead().setPrev(null);
		} else {
			setTail(null); // If queue becomes empty
		}

		decrementSize();
		return node1.getEntry();
	}

	public Entry min(){
		// returns a reference value to the minimum entry of the priority queue, but doesn’t remove it
		if(getHead() == null){	//for checking if null
			return null;
		}

		return getHead().getEntry();
	}


	//override getters and setters for tail and head
    public DLLEntryNode getHead() {
        return (DLLEntryNode) super.getHead();
    }

    public DLLEntryNode getTail() {
        return (DLLEntryNode) super.getTail();
    }

	public void setHead(DLLEntryNode node) {
		super.setHead(node); // Calls the base DLL method with DLLEntryNode
	}


	public void setTail(DLLEntryNode node) {
		super.setTail(node); // Calls the base DLL method with DLLEntryNode
	}
}


















