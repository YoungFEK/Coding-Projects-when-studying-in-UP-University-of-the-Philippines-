public class DLLEntryNode extends DLLNode{
	// insert attributes
	private Entry entry;
	private DLLEntryNode prev;
	private DLLEntryNode next;

	public DLLEntryNode(Entry entry){
		// constructor
		super(entry.getValue());
		this.entry = entry;
		this.prev = null;
		this.next = null;
	}

	public void setEntry(Entry entry){
		this.entry = entry;
	}

	public Entry getEntry(){
		return this.entry;
	}

	public void setNext(DLLEntryNode node){
		this.next = node;
	}

	public DLLEntryNode getNext(){
		return this.next;
	}

	public void setPrev(DLLEntryNode node){
		this.prev = node;
	}

	public DLLEntryNode getPrev(){
		return this.prev;
	}
}


//add super with string value in constructor??
