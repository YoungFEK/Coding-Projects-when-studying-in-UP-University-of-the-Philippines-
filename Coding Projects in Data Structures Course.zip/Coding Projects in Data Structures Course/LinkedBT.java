public class LinkedBT{
	// insert "LinkedBT" attributes
	// private int rootNode;
	private int size;
	private BTNode rootNode;
	
	public LinkedBT(){
		this.rootNode = null;
		this.size = 0;
	}

	public int getSize(){
		return this.size;
	}

	public boolean isEmpty(){
		return getSize()==0;
	}
		
	public void setRoot(BTNode rootNode){
	//assigns a new value for the root

		if(this.rootNode == null){
			this.size++;
		}else{
			rootNode.setLeft(this.rootNode.getLeft());
			rootNode.setRight(this.rootNode.getRight());
		}

		this.rootNode = rootNode;

		//add size??

	}

	public BTNode getRoot(){
		//retrieves the value of the root
		return this.rootNode;
	}

	public void setLeft(BTNode parentNode, String value){
		//assign the left child of the node at the parent index with a certain value

		if(parentNode.getLeft() != null){
			System.out.println("left child already exists");		//check if child exists
			return;
		}

		//actual assignment
		BTNode newNode = new BTNode(value);
		parentNode.setLeft(newNode);
		newNode.setParent(parentNode);

		this.size++;
	}

	public void setRight(BTNode parentNode, String value){
		//assign the right child of the node at the parent index with a certain value

		if(parentNode.getRight() != null){
			System.out.println("Right child already exists");		//check if child exists
			return;
		}

		//actual assignment
		BTNode newNode = new BTNode(value);
		parentNode.setRight(newNode);
		newNode.setParent(parentNode);

		this.size++;
	}

	// Tree Traversals
	public void inorder(BTNode rootNode){
		// left -> root -> right
		// This will print the values of the LinkedBT using the inorder traversal

		if(rootNode == null){
			return;
		}

		//check if left child exists
		if(rootNode.getLeft() != null){
			inorder(rootNode.getLeft());
		}

		System.out.println(rootNode.getValue() + " ");

		//check if right child exists
		if(rootNode.getRight() != null){
			inorder(rootNode.getRight());
		}
	}

	public void preorder(BTNode rootNode){
		// root -> left -> right
		// This will print the values of the LinkedBT using the preorder traversal
		if(rootNode == null){
			return;
		}

		System.out.println(rootNode.getValue() + " ");

		//check if left child exists
		if(rootNode.getLeft() != null){
			preorder(rootNode.getLeft());
		}

		//check if right child exists
		if(rootNode.getRight() != null){
			preorder(rootNode.getRight());
		}
	}

	public void postorder(BTNode rootNode){
		// left -> right -> root
		// This will print the values of the LinkedBT using the postorder traversal
		if(rootNode == null){
			return;
		}

		//check if left child exists
		if(rootNode.getLeft() != null){
			postorder(rootNode.getLeft());
		}

		//check if right child exists
		if(rootNode.getRight() != null){
			postorder(rootNode.getRight());
		}

		System.out.println(rootNode.getValue() + " ");
	}
}






