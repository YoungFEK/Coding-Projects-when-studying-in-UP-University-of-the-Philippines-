public class ArrayQueue extends Array{
	// Note that class "ArrayQueue" inherits the class "Array" attributes and methods
	// Insert Attributes (if any) - must be private

	public ArrayQueue (int capacity){
		// Constructor: create necessary parameters
		super(capacity);
	}

	public Element front(){
		// The front() operation returns a reference value to the front element of the queue, but doesn’t remove it
		if(isEmpty()){
			System.out.println("Array is empty. Nothing to return.");
			return null;
		}

		Element[] contents = getContents();
		return contents[0];
	}

	public void enqueue(String value){
		// You are not allowed to enqueue() an 'Element' to the queue when full
		// If the capacity is full, prompt the expand() method before enqueueing
		if(getSize() == getCapacity()){
			System.out.println("Prompt: stack is full, expanding stack...");
			expand();
		}

		// The enqueue() operation inserts an 'Element' at the back of the queue
		addElement(value);		//check if you can use last index directly????????
	}

	public Element dequeue(){
		// The dequeue() operation removes the 'Element' at the front of the queue
		// This should also return the 'Element' that was removed
		if(isEmpty()){
			System.out.println("Array is empty. Nothing to remove.");
			return null;
		}

		Element[] contents2 = getContents();
		Element frontEl = contents2[0];

		int size1 = getSize()-1;
		for(int i=0; i<size1; i++){
			contents2[i] = contents2[i+1];
		}
		contents2[size1] = null;
		decrementSize();
		return frontEl;
	}
}
