public class DLLMap extends DLL{
	// Note: Class "DLLMap" inherits the class "DLL" attributes and methods
	// Note: Nodes in the DLL contains Entries as values (Use 'DLLEntryNode' in Lab #6)
	public DLLMap(){
		super();
	}

	public DLLEntryNode find_node(int key){		//(self, key)
		// Use 'DLLEntryNode' in Lab #6
		// finds and returns the node with the specified key
		DLLEntryNode nodeFinder = getEntryHead();

		while(nodeFinder != null && nodeFinder.getEntry().getKey() != key){
			nodeFinder = nodeFinder.getNext();
		}

		return nodeFinder;	//returns null if key does not exist or dll is empty
	}

	public Entry get(int key){
		// finds and returns the value of the entry with the specified key
		// REQUIRED: Implement 'find_node(key)'
		if(find_node(key) == null){
			return null;
		}

		return find_node(key).getEntry();
	}

	public void put(int key, String value){
		// inserts an entry with the specified key and value in the map; overwrites existing entry if key already exists
		// REQUIRED: Implement 'find_node(key)'

		//if entry doesn't exist, insert at the back
		if(find_node(key) == null){
			Entry insertedEntry = new Entry(key, value);
			DLLEntryNode insertedNode = new DLLEntryNode(insertedEntry);

			//if dll is initially empty
			if(getEntryHead() == null){
				setHead(insertedNode);
				setTail(insertedNode);
			}else{
				getEntryTail().setNext(insertedNode);
				insertedNode.setPrev(getEntryTail());
				setTail(insertedNode);
			}

			incrementSize();
			return;
		}

		//if its not null then it did find existing entry
		find_node(key).getEntry().setValue(value);	//no need to increment
		return;
	}

	public Entry remove(int key){
		// removes the entry with the specified key, and returns the entry that was removed
		// REQUIRED: Implement 'find_node(key)'
		if(find_node(key) == null){		//if DLL empty or key does not exist
			return null;
		}

		DLLEntryNode removedNode = find_node(key);

		//if it exists

		//if its the only node
		//if its the last node
		//if its the first node
		//if its the middle node
		if(getSize()==1){
			setHead(null);
			setTail(null);
		}else if(removedNode == getEntryTail()){
			setTail(getEntryTail().getPrev());
			getEntryTail().setNext(null);
		}else if (removedNode == getEntryHead()){
			setHead(getEntryHead().getNext());
			getEntryHead().setPrev(null);
		}else{
			removedNode.getPrev().setNext(removedNode.getNext());
			removedNode.getNext().setPrev(removedNode.getPrev());
		}

		decrementSize();
		return removedNode.getEntry();
	}

	// Iterator Methods
	public void keys(){
		// iterates through the existing entries in the map and prints all the keys in order
		DLLEntryNode nodeFinder = getEntryHead();

		//only one node or empty node
		if(getSize()==0){
			System.out.println("DLL empty");
			return;
		}else if(getSize()==1){
			System.out.println(nodeFinder.getEntry().getKey());
			return;
		}

		while(nodeFinder.getNext().getNext() != null){
			System.out.print(nodeFinder.getEntry().getKey() + ", ");
			nodeFinder = nodeFinder.getNext();
		}
		nodeFinder = nodeFinder.getNext();
		System.out.println(nodeFinder.getEntry().getKey());
	}

	public void values(){
		// iterates through the existing entries in the map and prints all the values in order
		DLLEntryNode nodeFinder = getEntryHead();

		//only one node or empty node
		if(getSize()==0){
			System.out.println("DLL empty");
			return;
		}else if(getSize()==1){
			System.out.println(nodeFinder.getEntry().getValue());
			return;
		}


		while(nodeFinder.getNext().getNext() != null){
			System.out.println(nodeFinder.getEntry().getValue() + ", ");
			nodeFinder = nodeFinder.getNext();
		}
		nodeFinder = nodeFinder.getNext();
		System.out.println(nodeFinder.getEntry().getValue());
	}

	public void entries(){
		// iterates through the existing entries in the map and prints all the entries (in the format "key:value") in order
		DLLEntryNode nodeFinder = getEntryHead();

		//only one node or empty node
		if(getSize()==0){
			System.out.println("DLL empty");
			return;
		}else if(getSize()==1){
			System.out.println(nodeFinder.getEntry().getKey() + ":" + nodeFinder.getEntry().getValue());
			return;
		}

		while(nodeFinder.getNext().getNext() != null){
			System.out.print(nodeFinder.getEntry().getKey() + ":" + nodeFinder.getEntry().getValue() + ", ");
			nodeFinder = nodeFinder.getNext();
		}
		nodeFinder = nodeFinder.getNext();
		System.out.println(nodeFinder.getEntry().getKey() + ":" + nodeFinder.getEntry().getValue());
	}






	//override getters and setters for tail and head
    public DLLEntryNode getEntryHead() {
        return (DLLEntryNode) super.getHead();
    }

    public DLLEntryNode getEntryTail() {
        return (DLLEntryNode) super.getTail();
    }

	public void setHead(DLLEntryNode node) {
		super.setHead(node); // Calls the base DLL method with DLLEntryNode
	}


	public void setTail(DLLEntryNode node) {
		super.setTail(node); // Calls the base DLL method with DLLEntryNode
	}
}











