public class BTNode{
	// BTNode attributes: value, parentNode, leftNode, rightNode

	//value is String??
	private String value;
	private BTNode parentNode;
	private BTNode leftNode;
	private BTNode rightNode;

	public BTNode(String value){
		this.value = value;
		this.parentNode = null;
		this.leftNode = null;
		this.rightNode = null;

	}

	public void setValue(String value){
		this.value = value;
	}

	public String getValue(){
		return this.value;
	}

	public void setParent(BTNode parentNode){
		this.parentNode = parentNode;
	}

	public BTNode getParent(){
		return this.parentNode;
	}

	public void setLeft(BTNode leftNode){
		this.leftNode = leftNode;
	}

	public BTNode getLeft(){
		return this.leftNode;
	}

	public void setRight(BTNode rightNode){
		this.rightNode = rightNode;
	}

	public BTNode getRight(){
		return this.rightNode;
	}
}
