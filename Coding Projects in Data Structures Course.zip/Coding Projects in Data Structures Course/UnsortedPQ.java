public class UnsortedPQ extends DLL{
	// insert Unsorted PQ attributes (if any)

	public UnsortedPQ(){
		super();
	}

	public DLLEntryNode find_min(){
		// finds and returns the node with the minimum key
		DLLEntryNode node1 = getHead();
		DLLEntryNode minNode = getHead();
		while(node1 != null){
			if(node1.getEntry().getKey() < minNode.getEntry().getKey()){
				 minNode = node1; // Update the minNode reference
			}
			node1 = node1.getNext();
		}

		return minNode;
	}

	public void insert(Entry e){
		// inserts an entry in the priority queue
		DLLEntryNode node1 = new DLLEntryNode(e);
		DLLEntryNode nodeBefore = getHead();		//head node

		//case 1-node inserted is the first node
		if(getHead() == null){
			setHead(node1);
			setTail(node1);
		}else {	//case 2-back or override key
			while((nodeBefore != null) && (e.getKey() != nodeBefore.getEntry().getKey())){		//case 4-overwride key or place node in between
				nodeBefore = nodeBefore.getNext();
			}
			if(/*e.getKey() == nodeBefore.getEntry().getKey() && */(nodeBefore != null)){
				nodeBefore.getEntry().setValue(e.getValue());
			}else{
				getTail().setNext(node1);
				node1.setPrev(getTail());
				setTail(node1);
			}
		}

		incrementSize(); 	//add 1 to size
		return;
	}

	public Entry remove_min(){
		// removes the minimum entry of the priority queue, and returns the entry that was removed
		// use the find_min() method
		if(getHead() == null){	//for checking if list is empty
			return null;
		}

		DLLEntryNode node1 = find_min();

		if(getHead() == node1){
			setHead(node1.getNext());

			if (getHead() != null) {
				getHead().setPrev(null);
			} else {
				setTail(null); // If queue becomes empty
			}
		}else if (getTail() == node1){
			setTail(node1.getPrev());
			getTail().setNext(null);
		}else{
			node1.getPrev().setNext(node1.getNext());
			node1.getNext().setPrev(node1.getPrev());
		}

		decrementSize();
		return node1.getEntry();
	}

	public Entry min(){
		// returns a reference value to the minimum entry of the priority queue, but doesn’t remove it
		// use the find_min() method
		return find_min().getEntry();
	}



	//override getters and setters for tail and head
    public DLLEntryNode getHead() {
        return (DLLEntryNode) super.getHead();
    }

    public DLLEntryNode getTail() {
        return (DLLEntryNode) super.getTail();
    }

	public void setHead(DLLEntryNode node) {
		super.setHead(node); // Calls the base DLL method with DLLEntryNode
	}


	public void setTail(DLLEntryNode node) {
		super.setTail(node); // Calls the base DLL method with DLLEntryNode
	}
}
