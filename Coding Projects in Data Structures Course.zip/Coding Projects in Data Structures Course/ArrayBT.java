public class ArrayBT extends Array{
	// Note that class "ArrayBT" inherits the class "Array" attributes and methods
	// The root of the Array Binary Tree is stored at index 1
	int rootIndex;
	
	public ArrayBT(int capacity){
		super(capacity);
		this.rootIndex = 1;//--------------------
	}
		
	public void setRoot(Element e){
		getContents()[this.rootIndex] = e;
		incrementSize();

	}

	public Element getRoot(){
		return getContents()[this.rootIndex];
	}

	public void setLeft(int parentIndex, Element e){
		// Note that the left child of a node is stored at INDEX: (2*index)

		int leftIndex = parentIndex * 2;

		//for checking if leftchild exists
		if(getContents()[leftIndex] != null){
			System.out.println("parent already has child");
			return;
		}

		getContents()[leftIndex] = e;
		incrementSize();


	}
	
	public void setRight(int parentIndex, Element e){
		// Note that the right child of a node is stored at INDEX: (2*index) + 1

		int rightIndex = (parentIndex * 2) + 1;

		//checking if rightchild exists
		if(getContents()[rightIndex] != null){
			System.out.println("parent already has child");
			return;
		}

		getContents()[rightIndex] = e;
		incrementSize();
	}


	// Tree Traversals
	public void inorder(int rootIndex){
		// left -> root -> right
		// This will print the values of the ArrayBT using the inorder traversal

		//use this.rootIndex??
		//consider when left child is missing??
		//add return statements??

		if(rootIndex<1 || rootIndex>(getCapacity()-1)){
			return;
		}


		if(getContents()[rootIndex] == null){
			return;
		}

		int leftIndex = rootIndex * 2;							//-------------------
		int rightIndex = (rootIndex * 2) + 1;

		//check if left child exists getContents()[rootIndex * 2] != null && (leftIndex>0 && leftIndex<=(getCapacity()-1))
		if((leftIndex>0 && leftIndex<=(getCapacity()-1)) && getContents()[rootIndex * 2] != null){
			inorder(rootIndex * 2);
		}

		System.out.print(getContents()[rootIndex].getValue() + " ");

		//check if right child exists getContents()[(rootIndex * 2) + 1] != null && (rightIndex>0 && rightIndex<=(getCapacity()-1))
		if((rightIndex>0 && rightIndex<=(getCapacity()-1)) && getContents()[(rootIndex * 2) + 1] != null){
			inorder((rootIndex * 2) + 1);
		}
	}

	public void preorder(int rootIndex){
		// root -> left -> right
		// This will print the values of the ArrayBT using the preorder traversal
		if(rootIndex<1 || rootIndex>(getCapacity()-1)){
			return;
		}

		if(getContents()[rootIndex] == null){
			return;
		}

		int leftIndex = rootIndex * 2;							//-------------------
		int rightIndex = (rootIndex * 2) + 1;

		System.out.print(getContents()[rootIndex].getValue() + " ");

		if((leftIndex>0 && leftIndex<=(getCapacity()-1)) && getContents()[rootIndex * 2] != null){
			preorder(rootIndex * 2);
		}

		if((rightIndex>0 && rightIndex<=(getCapacity()-1)) && getContents()[(rootIndex * 2) + 1] != null){
			preorder((rootIndex * 2) + 1);
		}
	}

	public void postorder(int rootIndex){
		// left -> right -> root
		// This will print the values of the ArrayBT using the postorder traversal

		if(rootIndex<1 || rootIndex>(getCapacity()-1)){		//------------
			return;
		}

		if(getContents()[rootIndex] == null){
			return;
		}

		int leftIndex = rootIndex * 2;							//-------------------
		int rightIndex = (rootIndex * 2) + 1;


		if((leftIndex>0 && leftIndex<=(getCapacity()-1)) && getContents()[rootIndex * 2] != null){
			postorder(rootIndex * 2);
		}

		if((rightIndex>0 && rightIndex<=(getCapacity()-1)) && getContents()[(rootIndex * 2) + 1] != null){
			postorder((rootIndex * 2) + 1);
		}

		System.out.print(getContents()[rootIndex].getValue() + " ");
	}
}




//do we still need to handle if array is full?
