public class Array{
	// insert attributes
	private int size;
	private int capacity;
	private Element[] contents;


	public Array (int capacity1){
		// constructor
		this.size = 0;
		this.capacity = capacity1;
		this.contents = new Element[capacity1];
	}

	public int getSize(){
		return this.size;
	}

	public Element[] getContents(){
		return this.contents;
	}

	public boolean isEmpty(){
		return this.size==0;
	}

	//adds new element
	public void addElement(String value){
		if(this.size == this.capacity){
			System.out.println("Array is full. Cannot add element.");
			return;
		}

		for(int i = 0; i<this.capacity; i++){
			if(this.contents[i]==null){
				// this.contents[i]= new Element(value,i);
				this.contents[i]= new Element(i,value);
				this.size += 1;
				break;
			}
		}
	}

	//removes element
	public String removeElement(int index){
		if(isEmpty()|| this.contents[index]== null){
			System.out.println("Failed to remove");
			return null;
		}
		String removedValue = this.contents[index].getValue();
        this.contents[index] = null;
        this.size -= 1;
        return removedValue;

		//ask sir??
  //       if(isEmpty()|| this.contents[index]== null || index < 0 || index >= this.size){
		// 	System.out.println("Failed to remove");
		// 	return null;
		// }
		// String removedValue = this.contents[index].getValue();
  //       this.contents[index] = null;
  //       this.size -= 1;
  //       return removedValue;
	}


	// NOTE: Add the expand() and getCapacity() methods to the "Array" class
	public int getCapacity(){
		return this.capacity;
	}

	//expand()
	public void expand() {
		// The expand() method expands the array by increasing its capacity by 5;
		this.capacity +=5;
		Element[] contents2 = new Element[this.capacity];
		for(int i=0; i<this.size; i++){
			contents2[i] = this.contents[i];
		}
		this.contents = contents2;
	}

	// NOTE: Add the incrementSize() and decrementSize() methods to the "Array" class
	public void incrementSize(){
		this.size += 1;
	}

	public void decrementSize(){
		this.size-=1;
	}
















}













