import java.util.Scanner;

//class for transfering location
class TransferLoc{
    public static void execute(){
        System.out.println("Pick a location:");
        System.out.println("Existing locations:");
        System.out.println("Lobby");
        System.out.println("Kitchen");
        System.out.println("Playground");
        System.out.println("Training Room");
    }

    public static Location execute2(Scanner scanner, Location currentLocation){
        Location pickedLocation= null;

        do{
            System.out.print("Enter Here: ");
            String chosenLocation = scanner.nextLine().toLowerCase().replace(" ", "");

            pickedLocation = LocationFactory.pickLocation(chosenLocation);

            if(pickedLocation == null){
                System.out.println("Invalid location. Please try again.");
            }else if (currentLocation != null && chosenLocation.equals(currentLocation.getClass().getSimpleName().toLowerCase())) {
                System.out.println("You are already in this location. Choose a different one.");
                /*pickedLocation = null;*/ // Reset to null to prompt again
            }else {
                break;
            }

        }while(true);

        return pickedLocation;
    }
}


public class TamagotchiGame{
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        Tamagotchipet.getPet();   //instantiate pet

        String commandIndicator = "transfer";
        Action currentAction;
        Location currentLocation = null;

        System.out.println("Welcome to Tamagotchi Game!");

        OUTER_LOOP: while(true){
            if(commandIndicator.equals("transfer")){
                TransferLoc.execute();

                currentLocation = TransferLoc.execute2(scanner, currentLocation);     //currentLocation = Lobby() or kitchen()....  //scanner

                currentLocation.greet();
                currentLocation.askAction();
                commandIndicator = currentLocation.petDo(scanner);     //scanner
            }else if(commandIndicator.equals("action")){
                currentLocation.askAction();
                commandIndicator = currentLocation.petDo(scanner);     //scanner
            }else if(commandIndicator.equals("exit")){
                break OUTER_LOOP;
            }

        }


    }
}
