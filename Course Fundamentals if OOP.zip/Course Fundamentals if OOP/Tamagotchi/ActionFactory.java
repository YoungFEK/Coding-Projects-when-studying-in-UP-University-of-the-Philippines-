import java.util.Scanner;

abstract class Action{
    protected int amount;

    public abstract void execute();

    public void placeAmount(String petLoc, int amount1, int amount2){
        if(petLoc.equals("lobby")){
            this.amount = amount1;
        }else{
            this.amount = amount2;
        }
    }

}

class Feed extends Action{
    public Feed(String petLoc) {
        placeAmount(petLoc, -15, -30);
    }

    public void execute(){
        Tamagotchipet.getPet().changeHunger(this.amount);
        System.out.println("\nYou are fed your pet!");
    }
}


class Play extends Action{
    public Play(String petLoc) {
        placeAmount(petLoc, 15, 30);
    }

    public void execute(){
        Tamagotchipet.getPet().changeHappiness(this.amount);
        System.out.println("\nYou are played with your pet!");
    }
}


class Train extends Action{
    public Train(String petLoc) {
        placeAmount(petLoc, 10, 20);
    }

    public void execute(){
        Tamagotchipet.getPet().changeTraining(this.amount);
        System.out.println("\nYou are trained your pet!");
    }
}


class DisplayStats extends Action{

    public void execute(){
        Tamagotchipet.getPet().showStats();
    }

}

public class ActionFactory{
    public static Action makeAction(String actionType, String petLoc){
        switch(actionType.toLowerCase().replace(" ", "")){
            case "feed":
                return new Feed(petLoc);
            case "play":
                return new Play(petLoc);
            case "train":
                return new Train(petLoc);
            case "displaystatus":
                return new DisplayStats();
            default:
                System.out.println("Invalid action");
                return null;
        }
    }
}




