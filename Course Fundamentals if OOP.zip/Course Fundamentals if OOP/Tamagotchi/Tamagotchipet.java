public class Tamagotchipet{
    private int hungerLev;
    private int trainLev;
    private int happinessLev;
    private static Tamagotchipet myPet = null;

    private Tamagotchipet(int hungerLev1, int trainLev1, int happinessLev1){
        this.hungerLev = hungerLev1;
        this.trainLev = trainLev1;
        this.happinessLev = happinessLev1;
    }

    public static Tamagotchipet getPet(){
        if(myPet == null){
            myPet = new Tamagotchipet(50, 50, 50);
        }
        return myPet;
    }



    //property operations
    public void changeHunger(int d){
        this.hungerLev += d;

        if (this.hungerLev > 100) this.hungerLev = 100;
        else if (this.hungerLev < 0) this.hungerLev = 0;
    }

    public void changeHappiness(int d){
        this.happinessLev += d;

        if (this.happinessLev > 100) this.happinessLev = 100;
        else if (this.happinessLev < 0) this.happinessLev = 0;
    }

    public void changeTraining(int d){
        this.trainLev += d;

        if (this.trainLev > 100) this.trainLev = 100;
        else if (this.trainLev < 0) this.trainLev = 0;
    }


    public void showStats(){
        System.out.println("=====================================");
        System.out.println("Stats:\n");
        System.out.println("Hunger Level: " + this.hungerLev);
        System.out.println("Happiness Level: " + this.happinessLev);
        System.out.println("Train Level: " + this.trainLev);
        System.out.println("=====================================");
    }

}
