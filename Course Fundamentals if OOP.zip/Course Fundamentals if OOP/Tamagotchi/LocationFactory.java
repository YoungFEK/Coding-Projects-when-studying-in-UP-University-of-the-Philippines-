import java.util.Scanner;

abstract class Location{

    public abstract void askAction();

    public abstract String petDo(Scanner scanner);

    public abstract void greet();

    public String petDo2(String action1, String action2, String location0, Scanner scanner){
        String chosenAction;

        do{
            System.out.print("Enter Here: ");
            chosenAction = scanner.nextLine().toLowerCase().replace(" ", "");

            if(chosenAction.equals("exit") || chosenAction.equals("transfer")){
                return chosenAction;
            }else if(chosenAction.equals(action1) || chosenAction.equals(action2)){  //(chosenAction, "displaystatus", "feed")
                Action chosenAct = ActionFactory.makeAction(chosenAction, location0);
                chosenAct.execute();
                break;
            }
        }while(true);
        return "action";


    }
}

class Lobby extends Location{

    public void askAction(){
        System.out.println("\nWhat action will you take?");
        System.out.println("Available actions: ");
        System.out.println(">Feed");
        System.out.println(">Train");
        System.out.println(">Play");
        System.out.println(">Display Status");
        System.out.println(">Transfer");
        System.out.println(">Exit");

    }

    public String petDo(Scanner scanner){
        String chosenAction;

        do{
            System.out.print("Enter Here: ");

            chosenAction = scanner.nextLine().toLowerCase().replace(" ", "");

            if(chosenAction.equals("exit") || chosenAction.equals("transfer")){
                return chosenAction;
            }

            Action chosenAct = ActionFactory.makeAction(chosenAction, "lobby");

            if(chosenAct != null){
                chosenAct.execute();
                break;
            }

        }while(true);
        return "action";
    }

    public void greet(){
        System.out.println("\nYou are currently in the Lobby");
    }
}

class Kitchen extends Location{

    public void askAction(){
        System.out.println("\nWhat action will you take?");
        System.out.println("Available actions: ");
        System.out.println(">Feed");
        System.out.println(">Display Status");
        System.out.println(">Transfer");
        System.out.println(">Exit");
    }

    public String petDo(Scanner scanner){
        String indicator = petDo2("displaystatus", "feed", "kitchen", scanner);
        return indicator;
    }

    public void greet(){
        System.out.println("\nYou are currently in the Kitchen");
    }

}

class Playground extends Location{

    public void askAction(){
        System.out.println("\nWhat action will you take?");
        System.out.println("Available actions: ");
        System.out.println(">Play");
        System.out.println(">Display Status");
        System.out.println(">Transfer");
        System.out.println(">Exit");
    }

    public String petDo(Scanner scanner){
        String indicator = petDo2("displaystatus", "play", "playground", scanner);
        return indicator;
    }

    public void greet(){
        System.out.println("\nYou are currently in the Playground");
    }
}

class TrainingRoom extends Location{

    public void askAction(){
        System.out.println("\nWhat action will you take?");
        System.out.println("Available actions: ");
        System.out.println(">Train");
        System.out.println(">Display Status");
        System.out.println(">Transfer");
        System.out.println(">Exit");
    }

    public String petDo(Scanner scanner){
        String indicator = petDo2("displaystatus", "train", "lobby", scanner);
        return indicator;
    }

    public void greet(){
        System.out.println("You are currently in the TrainingRoom");
    }
}


public class LocationFactory{
    public static Location pickLocation(String locName){
        switch(locName.toLowerCase().replace(" ", "")){     //nextLine will read until and exclude "\n"
            case "lobby":
                return new Lobby();
            case "kitchen":
                return new Kitchen();
            case "playground":
                return new Playground();
            case "trainingroom":
                return new TrainingRoom();
            default:
                return null;
        }
    }
}





