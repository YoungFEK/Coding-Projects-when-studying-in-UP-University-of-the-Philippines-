import java.util.Scanner;

public class Lab3{
    public static void main(String args[]){
        String guessWord = WordGenerator.generateWord();  //generates word, figure out meaning
        int count = guessWord.length();
        char[] userWord = new char[count];  //for storing the letter guessed
        Scanner scanner = new Scanner(System.in);
        int lives = 5;
        int correctGuess = 0;
        char letter= '\0';

        System.out.println("Welcome to HANG-MAN");

         OUTER_LOOP: while(lives>0){
            for(int i = 0; i<count; i++){  //for printing the word and adding elements to array
                char checker = guessWord.charAt(i);
                if(userWord[i]==checker){
                    System.out.print(checker);
                }else if(letter == checker){
                    System.out.print(checker);
                    userWord[i] = letter;
                    correctGuess++;
                }else{
                    System.out.print("_");
                }
            }

            if(correctGuess == count){
                System.out.println("\n------------------------------");
                System.out.println("Congratulations! ");
                System.out.println("------------------------------");
                break OUTER_LOOP;                   //checks if the user has completely guessed word
            }

            System.out.println("\nLives left: " + lives);
            System.out.print("Enter a letter: ");               //prompt the user for input
            letter = scanner.next().charAt(0);

            if(guessWord.indexOf(letter) == -1){
                lives-=1;                                   //check if the letter is in the word
                continue OUTER_LOOP;
            }
            for(char c: userWord){
                if(c == letter){
                    lives-=1;                               //check if letter has already been entered
                    break;
                }
            }
         }
         if(lives==0){
            System.out.println("\n------------------------------");
            System.out.println("HANGED, THE WORD WAS " + guessWord);
            System.out.println("------------------------------");
         }
    }
}
