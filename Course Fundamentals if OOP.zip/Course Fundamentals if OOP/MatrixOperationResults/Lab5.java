import java.io.File;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class Lab5{
    public static void main (String[] args) throws IOException{
        //variables for the matrices
        String fileDir1 = "MatrixSrc/MatrixA.csv";
        String fileDir2 = "MatrixSrc/MatrixB.csv";

//---------------------------------------------------First matrix
        int columnsA = columnGet(fileDir1);
        int rowsA = rowGet(fileDir1);
        int [][] arrayA = new int[rowsA][columnsA];
        arrayA = arrayget(fileDir1, arrayA, rowsA, columnsA);
//---------------------------------------------------


//---------------------------------------------------Second matrix
        int columnsB = columnGet(fileDir2);
        int rowsB = rowGet(fileDir2);
        int [][] arrayB = new int[rowsB][columnsB];
        arrayB = arrayget(fileDir2, arrayB, rowsB, columnsB);
//------------------------------------------------------------------

        System.out.println("Attempting Array Addition...");
        combine("MatrixSum.csv", arrayA, arrayB, rowsA, rowsB, columnsA, columnsB, 1);

        System.out.println("Attempting Array Subtraction...");
        combine("MatrixDifference.csv", arrayA, arrayB, rowsA, rowsB, columnsA, columnsB, 2);

        //scalar multiplication-- to be modified using methods
        System.out.println("Attempting Scalar Multiplication...\n");
        getScalar("MatrixScalarProduct.csv", 2, arrayB, rowsB, columnsB);

        //transpose-- to be modified using methods
        //public static void getTrans(String transFiledir, int[][] arrayA, int columnsA, int rowsA) throws IOException{
        System.out.println("Attempting to get transpose...\n");
        getTrans("MatrixATransposed.csv", arrayA, columnsA, rowsA);
        getTrans("MatrixBTransposed.csv", arrayB, columnsB, rowsB);

        //matrix multiplication
        System.out.println("Attempting to get MatrixProduct...");
        getProd("MatrixProduct.csv", arrayA, arrayB, rowsA, rowsB, columnsB, columnsA);
    }

    //REUSABLE METHOD CREATION

    //METHODS REQUIRING SIGNLE ARRAY
    //getting columns
    public static int columnGet(String fileDir)throws FileNotFoundException{
        Scanner scanner = new Scanner(new File(fileDir));
        int columnsA=0;
        if (scanner.hasNextLine()) {
            String firstLine = scanner.nextLine();
            columnsA = firstLine.split(",").length; // Count columns
            scanner.close();
        }
        return columnsA;
    }

    public static int rowGet(String fileDir) throws FileNotFoundException{
        Scanner scanner = new Scanner(new File(fileDir));
        int rowsA=0;
        while (scanner.hasNextLine()) {
                scanner.nextLine();
                rowsA+=1; //for every line add 1 to row
        }
        scanner.close();
        return rowsA;
    }

    //assigning values to array elements
    public static int[][] arrayget(String fileDir, int[][]arrayA, int rowsA, int columnsA) throws FileNotFoundException{
        Scanner scanner = new Scanner(new File(fileDir));
        for(int i=0; i<rowsA; i++){
            String line = scanner.nextLine();
            String[] values = line.split(",");
            for(int j=0; j<columnsA; j++){
                arrayA[i][j]=Integer.parseInt(values[j]);;
            }
        }
        scanner.close();
        return arrayA;
    }

    //getting transpose of array
    public static void getTrans(String transFiledir, int[][] arrayA, int columnsA, int rowsA) throws IOException{
        FileWriter transFile = new FileWriter(transFiledir);

        int spaceRem = columnsA-1;

        for(int i=0; i<columnsA; i++){
            //first element of row
            transFile.write(String.valueOf(arrayA[0][i]));     //write the first element to csv without comma
            for(int j=1; j<rowsA; j++){      //adjusting j to 1 since we'll print the first element
                transFile.write("," + String.valueOf(arrayA[j][i]));
            }
            if(i<spaceRem){
                transFile.write("\n");        //print new line at end of each line
            }
        }
        transFile.close();
    }

    //scalar product of array
    public static void getScalar(String scalFiledir, int n, int[][]arrayA, int rowsA, int columnsA) throws IOException{
        FileWriter scalFile = new FileWriter(scalFiledir);

        int spaceRem = rowsA-1;

        for(int i=0; i<rowsA; i++){

            //first element of row
            scalFile.write(String.valueOf(arrayA[i][0] * n));     //write the first element to csv without comma
            for(int j=1; j<columnsA; j++){      //adjusting j to 1 since we'll print the first element
                scalFile.write("," + String.valueOf(arrayA[i][j] * n));
            }
            if(i<spaceRem){
                scalFile.write("\n");        //print new line at end of each line
            }
        }
        scalFile.close();
    }

    //METHODS REQURING TWO ARRAYS
    //Matrix Addition or Subtraction
    public static void combine(String sumFiledir, int[][] arrayA, int[][] arrayB, int rowsA, int rowsB, int columnsA, int columnsB, int choice) throws IOException{
        FileWriter sumFile = new FileWriter(sumFiledir);
        if((rowsA == rowsB) && (columnsA == columnsB)){
            if(choice == 1){
                // public static void add(int[][] arrayA, int[][]arrayB, int rowsB, int columnsB, FileWriter sumFile) throws IOException{
                add(arrayA, arrayB, rowsB, columnsB, sumFile);
            }else if(choice==2){
                subtract(arrayA, arrayB, rowsB, columnsB, sumFile);
            }
        }else if((rowsA != rowsB) && (columnsA == columnsB)){
            System.out.println("rows are unequal");
            sumFile.write("rows are unequal");
        }else if((rowsA == rowsB) && (columnsA != columnsB)){
            System.out.println("columns are unequal");
            sumFile.write("columns are unequal");
        }else{
            System.out.println("both columns and rows are unequal");
            sumFile.write("both are unequal");
        }
        System.out.println();
        sumFile.close();
    }

    public static void add(int[][] arrayA, int[][]arrayB, int rowsB, int columnsB, FileWriter sumFile) throws IOException{

        int spaceRem = rowsB - 1;

        for(int i=0; i<rowsB; i++){
            //first element of row
            sumFile.write(String.valueOf(arrayA[i][0] + arrayB[i][0]));     //write the first element to csv without comma
            for(int j=1; j<columnsB; j++){      //adjusting j to 1 since we'll print the first element
                int elemSum = arrayA[i][j] + arrayB[i][j];
                sumFile.write("," + String.valueOf(elemSum));
            }
            if(i<spaceRem){
                sumFile.write("\n");        //print new line at end of each line
            }
        }
    }

    public static void subtract(int[][] arrayA, int[][]arrayB, int rowsB, int columnsB, FileWriter sumFile) throws IOException{
        int spaceRem = rowsB - 1;

        for(int i=0; i<rowsB; i++){
            //first element of row
            sumFile.write(String.valueOf(arrayA[i][0] - arrayB[i][0]));     //write the first element to csv without comma
            for(int j=1; j<columnsB; j++){      //adjusting j to 1 since we'll print the first element
                int elemSum = arrayA[i][j] - arrayB[i][j];
                sumFile.write("," + String.valueOf(elemSum));
            }
            if(i<spaceRem){
                sumFile.write("\n");        //print new line at end of each line
            }
        }
    }

    //getting product of array
    public static void getProd(String prodFiledir, int[][] arrayA, int[][] arrayB, int rowsA, int rowsB, int columnsB, int columnsA) throws IOException{
        FileWriter prodFile = new FileWriter(prodFiledir);
        int spaceRem = rowsA - 1;

        if(columnsA == rowsB){
            for (int i = 0; i < rowsA; i++) {
                for (int j = 0; j < columnsB; j++) {
                    int singleProd = 0;  // Reset product for each entry in the result matrix
                    for (int k = 0; k < columnsA; k++) {
                        singleProd += arrayA[i][k] * arrayB[k][j];
                    }
                    prodFile.write(String.valueOf(singleProd));  // Write product to file
                    if (j < columnsB - 1) {  // Avoid adding a comma after the last element
                        prodFile.write(",");
                    }
                }
                if(i<spaceRem){
                    prodFile.write("\n");  // Move to the next row
                }
            }
        }else{
            System.out.println("columns in Matrix A is not equal to rows in Matrix B");
            prodFile.write("columns in Matrix A is not equal to rows in Matrix B");

        }
        prodFile.close();
    }
}
