import java.util.Scanner; //import scanner class


public class Lab2{
    public static void main(String[] args){

        int userInput;
        Scanner scanner = new Scanner(System.in);

        //asking user for input
        System.out.print("Enter a number: ");
        userInput = scanner.nextInt();

        // OUTER_LOOP: while(true){
        //     if(userInput <= 1){
        //         System.out.println(userInput + " is not a prime number");
        //         break OUTER_LOOP;
        //     }else{
        //         for(int i = 2; i<userInput; i++){
        //             if(userInput%i==0){
        //                 System.out.println(userInput + " is not a prime number");
        //                 break OUTER_LOOP;
        //             }
        //         }
        //         System.out.println(userInput + " is a prime number");
        //         break OUTER_LOOP;
        //     }
        // }

        OUTER_LOOP:
        if(userInput <= 1){
            System.out.println(userInput + " is not a prime number");
        }else{
            for(int i = 2; i<Math.sqrt(userInput); i++){
                if(userInput%i==0){
                    System.out.println(userInput + " is not a prime number");
                    break OUTER_LOOP;
                }
            }
            System.out.println(userInput + " is a prime number");
        }
    }
}
