import mypackage.Student; //learnings=========
import java.util.Scanner;

public class Lab1{

    public static void main(String[] args){
        Student student1 = new Student();
        Student student2 = new Student();
        Student student3 = new Student();

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter First Name for student 1: ");
        student1.firstName = scanner.nextLine();                     //learnings====
        System.out.print("Enter Last Name for student 1: ");
        student1.lastName = scanner.nextLine();
        System.out.print("Enter number for student 1: ");
        student1.studentNumber = scanner.nextInt();
        scanner.nextLine();

        // System.out.println(student1.firstName);
        // System.out.println(student1.lastName);
        System.out.println(student1.studentNumber);

        System.out.print("Enter First Name for student 2: ");
        student2.firstName = scanner.nextLine();
        System.out.print("Enter Last Name for student 2: ");
        student2.lastName = scanner.nextLine();
        System.out.print("Enter number for student 2: ");
        student2.studentNumber = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter First Name for student 3: ");
        student3.firstName = scanner.nextLine();
        System.out.print("Enter Last Name for student 3: ");
        student3.lastName = scanner.nextLine();
        System.out.print("Enter number for student 3: ");
        student3.studentNumber = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Student number: " + student1.studentNumber + " is named " + student1.firstName + " " + student1.lastName);
        System.out.println("Static Variable: " + student1.studentObject);
        System.out.println("Student number: " + student2.studentNumber + " is named " + student2.firstName + " " + student2.lastName);
        System.out.println("Static Variable: " + student2.studentObject);
        System.out.println("Student number: " + student3.studentNumber + " is named " + student3.firstName + " " + student3.lastName);
        System.out.println("Static Variable: " + student3.studentObject);

    }

}
