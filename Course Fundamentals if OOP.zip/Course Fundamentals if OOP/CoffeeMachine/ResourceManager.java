public class ResourceManager{
    private int water;
    private int milk;
    private int beans;
    private int espresso;
    private double wallet;

    public ResourceManager(){
        this.water = 1000;
        this.milk = 1000;
        this.beans = 500;
        this.espresso = 600;
        this.wallet = 0.00;

        // this.water = 0;
        // this.milk = 0;
        // this.beans = 0;
        // this.espresso = 30;
        // this.wallet = 0.00;
    }

    //METHODS for water
    public int getWater(){
        return this.water;
    }

    public void decWater(int value){
        this.water -= value;
    }

    //METHODS for Millk
    public void decMilk(int value){
        this.milk -= value;
    }

    public int getMilk(){
        return this.milk;
    }

    //METHODS for beans
    public void decBeans(int value){
        this.beans -= value;
    }

    public int getBeans(){
        return this.beans;
    }

    //METHODS for Espresso
    public void decEspresso(int value){
        this.espresso -= value;
    }

    public int getEspresso(){
        return this.espresso;
    }

    //Methods for Wallet
    public double getWallet(){
        return this.wallet;
    }

    public void incWallet(double value){
        this.wallet += value;
    }


}
