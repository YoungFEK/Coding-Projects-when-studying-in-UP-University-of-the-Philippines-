import java.util.Scanner;

//may implement polymorphism through resource checking

abstract class Coffee{
    String name;
    int waterCost;
    int milkCost;
    int beansCost;
    int espressCost;
    double moneyCost;

    public Coffee(String name, int waterCost, int milkCost, int beansCost, int espressCost, double price) {//------------------------------------------
        this.name = name;
        this.waterCost = waterCost;
        this.milkCost = milkCost;
        this.beansCost = beansCost;
        this.espressCost = espressCost;
        this.moneyCost = price;
    }

    public abstract void makeCoffee(ResourceManager rM); //------------
}

class CoffeeExpresso extends Coffee{

    // public CoffeeExpresso(){
    //     this.name = "Expresso";
    //     this.waterCost = 30;
    //     this.milkCost = 0;
    //     this.beansCost = 9;
    //     this.espressCost = 0;
    //     this.moneyCost = 1.50;
    // }

    public CoffeeExpresso() {
        super("Expresso", 30, 0, 9, 0, 1.50);//---------------------------------------------
    }

    //---------------------------------------------------------------------
    public void makeCoffee(ResourceManager rM) {
        rM.decWater(this.waterCost);
        rM.decBeans(this.beansCost);
        rM.incWallet(this.moneyCost);
    }

}

class CoffeeLatte extends Coffee{

    public CoffeeLatte(){
        super("Latte", 30, 0, 9, 30, 3.00); //---------------------------
        // this.name = "Latte";
        // this.waterCost = 30;
        // this.milkCost = 0;
        // this.beansCost = 9;
        // this.espressCost = 30;
        // this.moneyCost = 3.00;
    }

    public void makeCoffee(ResourceManager rM) {
        rM.decWater(this.waterCost);
        rM.decBeans(this.beansCost);
        rM.decEspresso(this.espressCost);           //------------------------------------------
        rM.incWallet(this.moneyCost);
        // System.out.println("Making a " + this.name);
    }
}

class CoffeeCappucino extends Coffee{

    public CoffeeCappucino(){
        super("Cappucino", 0, 180, 0, 30, 2.50);//------------------------------------------------
        // this.name = "Cappucino";
        // this.waterCost = 0;
        // this.milkCost = 180;
        // this.beansCost = 0;
        // this.espressCost = 30;
        // this.moneyCost = 2.50;
    }

    public void makeCoffee(ResourceManager rM) {
        rM.decMilk(this.milkCost);
        rM.decEspresso(this.espressCost);           //-------------------------------------------------
        rM.incWallet(this.moneyCost);
        // System.out.println("Making a " + this.name);
    }
}


public class CoffeeMachine{

    public static void main(String args[]){

        Scanner scanner = new Scanner(System.in);
        CoffeeMachine myMachine = new CoffeeMachine();

        Coffee myLatte = new CoffeeLatte();
        Coffee myCappucino = new CoffeeCappucino();
        Coffee myExpresso = new CoffeeExpresso();

        ResourceManager rM = new ResourceManager();
        System.out.println("Greetings! Valued Customer");

        while(true){
            System.out.println("What would you like? (espresso/latte/cappuccino/):");
            System.out.println("\nAvailable items:");
            System.out.println(myLatte.name + " - $" + myLatte.moneyCost);
            System.out.println(myCappucino.name + " - $" + myCappucino.moneyCost);
            System.out.println(myExpresso.name + " - $" + myExpresso.moneyCost);

            // System.out.println("\nNOTE:");
            // System.out.println("Type off to close the machine");
            // System.out.println("Type report to see available items");

            String userInput = scanner.nextLine();

            if(userInput.contains("off")){
                System.out.println("Machine is shutting down");
                break;
            }else if (userInput.contains("report")){
                System.out.println("Water: " + rM.getWater() + "ml");
                System.out.println("Milk: " + rM.getMilk() + "ml");
                System.out.println("Beans: " + rM.getBeans() + "g");
                System.out.println("Espresso: " + rM.getEspresso() + "ml");
                System.out.println("Pocket Money: $" + rM.getWallet());
            }else if (userInput.contains("Latte")){
                myMachine.processOrder(myLatte, rM, myMachine);
            }else if (userInput.contains("Cappucino")){
                myMachine.processOrder(myCappucino, rM, myMachine);
            }else if (userInput.contains("Expresso")){
                myMachine.processOrder(myExpresso, rM, myMachine);
            }else{
                System.out.println("Option not recognized");
            }

        }

    }

    public boolean areResourcesSufficient(Coffee coffee, ResourceManager rM) {
        boolean checkRes= true;
        if (rM.getWater() < coffee.waterCost) {
            System.out.println("Sorry, there is not enough water.");
            checkRes = false;
        }
        if (rM.getMilk() < coffee.milkCost) {
            System.out.println("Sorry, there is not enough milk.");
            checkRes = false;
        }
        if (rM.getBeans() < coffee.beansCost) {
            System.out.println("Sorry, there is not enough coffee beans.");
            checkRes = false;
        }
        if (rM.getEspresso() < coffee.espressCost) {
            System.out.println("Sorry, there is not enough coffee Espresso.");
            checkRes = false;
        }
        return checkRes;
    }

    public double processCoins() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please insert coins.");
        System.out.println("How many quarters?");
        int quarters = numCheck();
        System.out.println("How many dimes?");
        int dimes = numCheck();
        System.out.println("How many nickels?");
        int nickels = numCheck();
        System.out.println("How many pennies?");
        int pennies = numCheck();

        double total = quarters * 0.25 + dimes * 0.10 + nickels * 0.05 + pennies * 0.01;
        System.out.printf("You inserted: $%.2f%n", total);
        return total;
    }

    //invalid number checking
    public int numCheck(){
        Scanner scanner = new Scanner(System.in);
        int quarters;
        do{
            // System.out.print("Enter valid input: ");
            quarters = scanner.nextInt();
            if(quarters < 0){
                System.out.print("Invalid input: ");
            }
        }while(quarters < 0);
        return quarters;
    }

    private void processOrder(Coffee coffee, ResourceManager rM, CoffeeMachine myMachine) {
        if (myMachine.areResourcesSufficient(coffee, rM)) {
            double moneyInserted = myMachine.processCoins();
            if (moneyInserted >= coffee.moneyCost) {
                double change = moneyInserted - coffee.moneyCost;
                if (change > 0) {
                    System.out.printf("Here is $%.2f in change.%n", change);
                }
                coffee.makeCoffee(rM);
                System.out.println("Here is your " + coffee.name + ". Enjoy!");
            } else {
                System.out.println("Sorry, that's not enough money. Money refunded.");
            }
        }
    }
}
