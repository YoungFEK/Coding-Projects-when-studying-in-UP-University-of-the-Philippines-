import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CsvReader{
    public static void main(String[] args) {
        String filePath = "example.csv"; // Path to your CSV file //"path/to/your/file.csv"

        try (Scanner scanner = new Scanner(new File(filePath))) {
            // Set custom delimiter to split on commas
            scanner.useDelimiter(",|\n"); // Use comma or newline as delimiter

            while (scanner.hasNext()) {
                // Read individual values
                String value = scanner.next();
                System.out.print(value + " ");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
