import java.util.Scanner;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.DayOfWeek;
import java.time.format.TextStyle;      //studyy

public class Labc4{

    Scanner scanner = new Scanner(System.in);
    enum Day {Sun, Mon, Tue, Wed, Thu, Fri, Sat}

    public static void main(String args[]){
        Scanner scanner = new Scanner(System.in);

        int userMonth;
        int userYear;

        //filtering user input for month and year
        while(true){
             System.out.print("Enter a month in number form 1-12: ");
             userMonth = scanner.nextInt();

             System.out.print("Enter a year in number from 1-10000: ");
             userYear = scanner.nextInt();

             if((userMonth <= 12 && userMonth >= 1) && (userYear <= 10000 && userYear >= 1)){
                break;
             }
        }

        //for printing the individual date-----------------------------------------
        LocalDate userDate = LocalDate.of(userYear, userMonth, 1);
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("MMMM, yyyy");

        String dateString = userDate.format(dateFormat);
        System.out.println(dateString);

        int daysInMonth = userDate.lengthOfMonth();

        //printing individual dates------------------------------------------------
        for (Day day : Day.values()) {
            System.out.print(day + " ");
        }
        System.out.print("\n");

        int dayFirst = userDate.getDayOfWeek().getValue() % 7;

            for (int i=0; i<dayFirst; i++) {
                System.out.print("    ");
            }

            for(int j=1; j<=daysInMonth; j++){
                LocalDate userDate2 = LocalDate.of(userYear, userMonth, j);
                System.out.printf("%-4d", j);
                if(userDate2.getDayOfWeek().getValue()== 6){
                    System.out.print("\n");
                }
            }
    }
}
