import time

start_time = time.perf_counter()

file = open("data/full_input", "r")  #open file, read, create file object and name it file (O(1). The OS knows where the file starts and it knows its size, so knowing where to start writing

try:
    num_lines_to_read = int(file.readline().strip())  #O(n), where n is the number of characters in the file

    for i in range(num_lines_to_read): #O(n)

        iterator = int(file.readline().strip()) + 1  #file.readline() is number in file - where you have to find the nearest palindrome, O(n)
        while True: #n+1
            dividedNumber = iterator  #n
            reverseNumber = 0    #for initializing the number

            while dividedNumber > 0:    #n
                reverseNumber = (reverseNumber * 10) + (dividedNumber % 10) #n
                dividedNumber //= 10 #n
            if reverseNumber == iterator: #n
                print(reverseNumber)
                break
            iterator += 1 #(n)

finally: #n
    file.close() #n


end_time = time.perf_counter() #get current time again

elapsed_time = end_time - start_time #difference between start_time and end_time
print(f"{elapsed_time:.6f} seconds")
