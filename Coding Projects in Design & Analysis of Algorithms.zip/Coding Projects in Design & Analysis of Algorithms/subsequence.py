def combinationFinder(row, numOfCombinations, mainArray, lastRow, prevRowPosition):
    for j in range(len(mainArray[row])):
        if row<lastRow and (mainArray[row][j]>(prevRowPosition)):
            numOfCombinations = combinationFinder(row+1, numOfCombinations, mainArray, lastRow, mainArray[row][j])
        elif (mainArray[row][j]>(prevRowPosition)):
            numOfCombinations += 1
    return numOfCombinations


num_of_problems = int(input("Input number of problems: "))
outputArray = []



for i in range(num_of_problems):
    word, subWord = input("Enter word and sub-word seperated by a space: ").split()
    mainArray = []
    numOfCombinations = 0

    for subWordInd, char in enumerate(subWord):
        row = []
        for wordInd, char2 in enumerate(word):
            if(char == char2):
                row.append(wordInd)
        mainArray.append(row)

    for i in range(len(mainArray[0])):
        numOfCombinations = combinationFinder(1, numOfCombinations, mainArray, (len(mainArray)) - 1, mainArray[0][i])
    outputArray.append(numOfCombinations)


for i in outputArray:
    print(i)
