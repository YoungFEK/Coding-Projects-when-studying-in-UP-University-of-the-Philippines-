def extractPaths(pathArray, mazeArray, successfullPaths, lastRow, lastColumn):
    if(len(pathArray) == 0):
        # return successfullPaths
        return
    
    combinationPath = pathArray.pop(0) #pathArray.append(element)
    pathWentLeft = combinationPath.copy()
    pathWentRight = combinationPath.copy()
    pathWentUp = combinationPath.copy()
    pathWentDown = combinationPath.copy()
    # combinationPath[-1][0]   row index of current space in a certain path     [(,) (,)  >>(,)<<]
    # combinationPath[-1][1]   column index of current space in a certain path

    lastRow = num_of_rows - 1
    lastColumn = num_of_columns - 1 

    #rightTile = mazeArray[combinationPath[-1][0]][combinationPath[-1][1] + 1]
    if((combinationPath[-1][1] + 1) <= lastColumn):   #check if path is out of bounds
        rightTile = mazeArray[combinationPath[-1][0]][combinationPath[-1][1] + 1]
        if(rightTile != 0 and ((combinationPath[-1][0] , combinationPath[-1][1] + 1, mazeArray[combinationPath[-1][0]][combinationPath[-1][1] + 1]) not in combinationPath)):
            pathWentRight.append((combinationPath[-1][0] , combinationPath[-1][1] + 1, mazeArray[combinationPath[-1][0]][combinationPath[-1][1] + 1]))

            if((combinationPath[-1][0] == (lastRow)) and (combinationPath[-1][1] + 1 == (lastColumn))):
                successfullPaths.append(pathWentRight)
            else:
                pathArray.append(pathWentRight)

    #lowerTile = mazeArray[combinationPath[-1][0] + 1][combinationPath[-1][1]]
    if((combinationPath[-1][0] + 1) <= lastRow):   #check if path is out of bounds
        lowerTile = mazeArray[combinationPath[-1][0] + 1][combinationPath[-1][1]]
        if(lowerTile != 0 and ((combinationPath[-1][0] + 1,combinationPath[-1][1], mazeArray[combinationPath[-1][0] + 1][combinationPath[-1][1]]) not in combinationPath)):
            pathWentDown.append((combinationPath[-1][0] + 1,combinationPath[-1][1], mazeArray[combinationPath[-1][0] + 1][combinationPath[-1][1]]))

            if((combinationPath[-1][0] + 1 == (lastRow)) and (combinationPath[-1][1] == (lastColumn))):
                successfullPaths.append(pathWentDown)
            else:
                pathArray.append(pathWentDown)


    # leftTile =  mazeArray[combinationPath[-1][0]][combinationPath[-1][1] - 1]
    if((combinationPath[-1][1] - 1) >= 0):   #check if path is out of bounds
        leftTile =  mazeArray[combinationPath[-1][0]][combinationPath[-1][1] - 1]
        if(leftTile != 0 and ((combinationPath[-1][0] , combinationPath[-1][1] - 1, mazeArray[combinationPath[-1][0]][combinationPath[-1][1] - 1]) not in combinationPath)):
            pathWentLeft.append((combinationPath[-1][0] , combinationPath[-1][1] - 1, mazeArray[combinationPath[-1][0]][combinationPath[-1][1] - 1]))
            pathArray.append(pathWentLeft)
    

    #upperTile = mazeArray[combinationPath[-1][0] - 1][combinationPath[-1][1]]
    if((combinationPath[-1][0] - 1) >= 0):   #check if path is out of bounds
        upperTile = mazeArray[combinationPath[-1][0] - 1][combinationPath[-1][1]]
        if(upperTile != 0 and ((combinationPath[-1][0] - 1,combinationPath[-1][1], mazeArray[combinationPath[-1][0] - 1][combinationPath[-1][1]]) not in combinationPath)):
            pathWentUp.append((combinationPath[-1][0] - 1,combinationPath[-1][1], mazeArray[combinationPath[-1][0] - 1][combinationPath[-1][1]]))
            pathArray.append(pathWentUp)

    
    extractPaths(pathArray, mazeArray, successfullPaths, lastRow, lastColumn)





# from collections import deque
# queue = deque()


mazeArray = []  #stores maze
successfullPaths = []  #stores paths that reached endpoint


#pathArray
# structure: [[(1,2)], [(2,1)]]

num_of_rows = int(input("How many rows do you want to input? "))

for i in range(num_of_rows):
    user_input = input(f"Enter elements for array #{i+1}, separated by spaces: ")
    array = list(map(int, user_input.strip().split()))
    mazeArray.append(array)

# print(mazeArray)
pathArray = [[(0,0, mazeArray[0][0])]]  #stores all paths until they terminate, stores combinationArray


num_of_columns = len(mazeArray[0]) # all arrays have uniform length


extractPaths(pathArray, mazeArray, successfullPaths, num_of_rows-1, num_of_columns-1)
shortestPath = min(successfullPaths, key=lambda arr: sum(t[2] for t in arr))


print(shortestPath)
print(sum(t[2] for t in shortestPath)-mazeArray[0][0])
# print(len(s4hortestPath))



for i in range(num_of_rows):
    for j in range(num_of_columns):
        if (i, j, mazeArray[i][j]) in shortestPath:
            print("*", end ="")
        elif mazeArray[i][j] == 1:
            print(" ", end ="")
        else:
            print("|", end ="")
    print()