import time

# start_time = time.perf_counter()

inputArray = []

user_input = input("How many inputs? ")

# edit for loop to read files instead of using inputs from command line
for i in range(int(user_input)):
    individual_input = input("Enter a number: ")
    inputArray.append(int(individual_input));

start_time = time.perf_counter()

for num in inputArray:
    iterator = num + 1
    while True:
        dividedNumber = iterator
        reverseNumber = 0    #for initializing the number

        while dividedNumber > 0:
            reverseNumber = (reverseNumber * 10) + (dividedNumber % 10)
            dividedNumber //= 10
        if reverseNumber == iterator:
            print(reverseNumber)
            break
        iterator += 1

end_time = time.perf_counter()

elapsed_time = end_time - start_time
print(f"{elapsed_time:.6f} seconds")








