numOfProblems = int(input("How many number of days to work out: "))
solutionArray = []


for i in range(numOfProblems): 
    numOfOrders = int(input("How many appointments for today: "))
    userAppointments = []
    computedPenalty = 0
    currentDay = 0

    for i in range(numOfOrders):
        orderOwner, numDays, orderPenalty = input("Enter name, number of days, and penalty: ").split()
        numDays = int(numDays)
        orderPenalty = int(orderPenalty)
        individualOrder = (orderOwner, numDays, orderPenalty) #might need changing for proper sorting
        userAppointments.append(individualOrder)

    # print(userAppointments)

    userAppointments.sort(key=lambda x: x[1]/x[2]) 

    for tuple in userAppointments:
        currentDay += tuple[1]
        computedPenalty += ((currentDay - tuple[1]) * tuple[2])

    solutionArray.append(str(computedPenalty) + " " + '-'.join(tuple[0] for tuple in userAppointments))

for string in solutionArray:
    print(string)



