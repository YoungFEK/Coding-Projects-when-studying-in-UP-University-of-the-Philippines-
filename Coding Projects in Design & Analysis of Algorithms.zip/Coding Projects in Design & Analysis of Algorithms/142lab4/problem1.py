def getGymTime(gymTime, time1, time2, chosenStartTime, chosenEndTime): 
    if((time2 - time1) > gymTime):
        return (time2 - time1), time1, time2
    return gymTime, chosenStartTime, chosenEndTime 


def getAppointment():
    appStart, appEnd = input("Please enter start and end time: ").split()
    return float(appStart), float(appEnd)


numOfDays = int(input("How many number of days to work out: "))
dayArray = []


for i in range(numOfDays):               
    numOfAppointments = int(input("How many appointments for today: "))
    appStart, appEnd = getAppointment()
    gymTime = appStart - 10
    chosenEndTime = chosenStartTime = None

    for i in range(numOfAppointments-1): #App MEANS appointment 
        prevAppEnd = appEnd
        appStart, appEnd = getAppointment()
        gymTime, chosenStartTime, chosenEndTime = getGymTime(gymTime, prevAppEnd, appStart, chosenStartTime, chosenEndTime)

    gymTime, chosenStartTime, chosenEndTime = getGymTime(gymTime, appEnd, 18, chosenStartTime, chosenEndTime)
    # print(gymTime, chosenStartTime, chosenEndTime)

    longestInterval =  (chosenStartTime, chosenEndTime)

    dayArray.append(longestInterval)


for tuple in dayArray:
    print(tuple[0], tuple[1])








