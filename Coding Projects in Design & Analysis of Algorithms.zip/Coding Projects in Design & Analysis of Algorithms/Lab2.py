#using j for taking note of the response order
def appendMission(listedMissions, j):
    missionName, arrivalDay, missionLength = input("Enter Quest name, day of Arrival, and mission length separated by space: ").split()
    arrivalDay = int(arrivalDay)
    missionLength = int(missionLength)
    singleMission = {
        "name": missionName,
        "arrival day": arrivalDay,
        "lengthOfMission": missionLength,
        "lengthOfMission2": missionLength,
        "TurnAround": None,
        "PounceTimes": None,
        "NapTimes": None,
    }
    missionAndPriority = (singleMission["arrival day"], singleMission["lengthOfMission"], singleMission, j)
    #0-arrival day, #1-length, #2-dictionary, #3-input order
    listedMissions.append(missionAndPriority)

def appendNames(names, dictionary, n):
    for i in range(n):
        names.append(dictionary["name"])



numOfProblems = int(input("How many problems to be solved? Please input them here: "))
currentDay = 0
names = []


for i in range(numOfProblems):
    numOfMissions = int(input("How many missions for this problem? Please input them here: "))
    reviewedMissions = []
    listedMissions = []

    for j in range(numOfMissions):
        appendMission(listedMissions, j)

    listedMissions.sort()


    # reviewing first mission
    reviewedMissions.append(listedMissions[0])
    listedMissions[0] = None #you've got to mark it with something either way
    fastestMission = reviewedMissions[0][2] #dictionary
    latestArrivalDate = reviewedMissions[0][0]
    reviewedMissions[0][2]["PounceTimes"] = 0

    for w in range(numOfMissions-1):


        if listedMissions[w+1][0] != latestArrivalDate:
            fastestMission["lengthOfMission"] -= (listedMissions[w+1][0] - latestArrivalDate)
            currentDay += (listedMissions[w+1][0] - latestArrivalDate)

            min_index2 = min(enumerate(reviewedMissions), key=lambda x: x[1][1])[0]

            if fastestMission["lengthOfMission"] > 0:
                fastestMissionTuple = reviewedMissions[min_index2]
                reviewedMissions[min_index2] = (fastestMissionTuple[0], fastestMission["lengthOfMission"], fastestMission, fastestMissionTuple[3])


            else:
                while fastestMission["lengthOfMission"] <= 0:
                    # enumerate() - raps an iterable and yields an index-value pair without performing any extra computation
                    extraDays = -fastestMission["lengthOfMission"]
                    fastestMission["lengthOfMission"] = float('inf') #update current fastest mission length to infinity

                    fastestMissionTuple = reviewedMissions[min_index2]
                    fastestMissionTuple[2]["TurnAround"] = (currentDay-extraDays) - fastestMissionTuple[2]["arrival Day"]
                    fastestMissionTuple[2]["NapTimes"] = fastestMissionTuple[2]["TurnAround"] - fastestMissionTuple[2]["lengthOfMission2"]

                    appendNames(names, fastestMissionTuple[2], (currentDay - extraDays) - latestArrivalDate)

                    reviewedMissions[min_index2] = (fastestMissionTuple[0], fastestMission["lengthOfMission"], fastestMission, fastestMissionTuple[3])



                    #getting the mission with the next shortest length
                    min_index = min(enumerate(reviewedMissions), key=lambda x: x[1][1])[0]
                    fastestMissionTuple = reviewedMissions[min_index]
                    fastestMissionTuple[2]["lengthOfMission"] -= extraDays #because 2 is index of dictionary
                    reviewedMissions[min_index] = (fastestMissionTuple[0], fastestMissionTuple[2]["lengthOfMission"], fastestMissionTuple[2], fastestMissionTuple[3])
                    fastestMission = fastestMissionTuple[2]

                    fastestMissionTuple[2]["PounceTimes"] = (currentDay -  fastestMissionTuple[2]["arrivalDay"])


        if listedMissions[w+1][2]["lengthOfMission"] < fastestMission["lengthOfMission"]:
            #both fastestMission & listedMissions[w+1] are already appended in reviewedMissions
            appendNames(names, fastestMission, listedMissions[w+1][0] - latestArrivalDate)
            fastestMission = listedMissions[w+1][2]
            listedMissions[w+1][2]["PounceTimes"] = 0


        #remove mission from listed transfer to reviewed
        reviewedMissions.append(listedMissions[w+1])


        latestArrivalDate = listedMissions[w+1][0]
        listedMissions[w+1] = None

    reviewedMissions.sort(key=lambda x: x[1])

    #for finishing the missions
    for tupple in reviewedMissions:
        if tupple[1] == float('inf'):
            break

        if tupple[2]["PounceTimes"] is None:
            tupple[2]["PounceTimes"] = currentDay - tupple[2]["arrival day"]

        currentDay += tupple[1] #1 is the index of length
        #you won't need the  length after this

        appendNames(names, tupple[2], tupple[1])

        tupple[2]["TurnAround"] = currentDay - tupple[2]["arrival day"]
        tupple[2]["NapTimes"] = tupple[2]["TurnAround"] - tupple[2]["lengthOfMission2"]


    reviewedMissions.sort(key=lambda x: x[3])

    for tupple in reviewedMissions:
        print(tupple[2]["TurnAround"], end = " ")
        print(tupple[2]["PounceTimes"], end = " ")
        print(tupple[2]["NapTimes"], end = " ")
        print()

    for i in names:
        print(i, end = " ")





